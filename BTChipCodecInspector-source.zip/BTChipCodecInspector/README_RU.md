# BT Chip & Codec Inspector 0.2.1

Диагностическое Android-приложение для Bluetooth-наушников.

## Новое в 0.2.1

- исправлена сборка с Shizuku/AndroidX в GitHub Actions;

## Новое в 0.2

- одна кнопка «ПОЛНАЯ ДИАГНОСТИКА»;
- интеграция с Shizuku 13.x;
- Shizuku UserService запускается от shell/root UID и читает `dumpsys bluetooth_manager` и `dumpsys media.audio_policy`;
- автоматический краткий вывод по текущему A2DP-кодеку и selectable capabilities;
- BLE scan, Apple manufacturer data, SDP и GATT остаются в отчёте;
- добавлена собственная иконка приложения;
- тёмная тема.

## Как пользоваться

1. Установить и запустить Shizuku.
2. На Android 11+ Shizuku можно запускать через Wireless debugging без компьютера.
3. Открыть приложение и нажать «SHIZUKU: ПОДКЛЮЧИТЬ / РАЗРЕШИТЬ»; подтвердить разрешение в Shizuku.
4. Подключить нужные Bluetooth-наушники.
5. Нажать «ПОЛНАЯ ДИАГНОСТИКА» и дождаться строки `FULL DIAGNOSTIC v0.2 FINISHED`.
6. Нажать «Копировать отчёт».

Приложение ничего не прошивает и не записывает в наушники. Оно только читает системную/BT диагностическую информацию.


## v0.4
- добавлен обязательный `rikka.shizuku.ShizukuProvider` в AndroidManifest;
- приложение теперь определяется Shizuku и может получать Binder/запрашивать разрешение;
- после появления Shizuku Binder приложение автоматически запрашивает доступ и подключает shell UserService.
