# BT Chip & Codec Inspector 0.2.1

Диагностическое Android-приложение для Bluetooth-наушников.

## Новое в 0.2.1

- исправлена сборка с Shizuku/AndroidX в GitHub Actions;

## Новое в 0.2

- одна кнопка «ПОЛНАЯ ДИАГНОСТИКА»;
- интеграция с Shizuku 13.x;
- Shizuku UserService запускается от shell/root UID и читает `dumpsys bluetooth_manager` и `dumpsys media.audio_policy`;
- автоматический краткий вывод по текущему A2DP-кодеку и selectable capabilities;
- BLE scan, Apple manufacturer data, SDP и GATT остаются в отчёте;
- добавлена собственная иконка приложения;
- тёмная тема.

## Как пользоваться

1. Установить и запустить Shizuku.
2. На Android 11+ Shizuku можно запускать через Wireless debugging без компьютера.
3. Открыть приложение и нажать «SHIZUKU: ПОДКЛЮЧИТЬ / РАЗРЕШИТЬ»; подтвердить разрешение в Shizuku.
4. Подключить нужные Bluetooth-наушники.
5. Нажать «ПОЛНАЯ ДИАГНОСТИКА» и дождаться строки `FULL DIAGNOSTIC v0.2 FINISHED`.
6. Нажать «Копировать отчёт».

Приложение ничего не прошивает и не записывает в наушники. Оно только читает системную/BT диагностическую информацию.


## v0.4
- добавлен обязательный `rikka.shizuku.ShizukuProvider` в AndroidManifest;
- приложение теперь определяется Shizuku и может получать Binder/запрашивать разрешение;
- после появления Shizuku Binder приложение автоматически запрашивает доступ и подключает shell UserService.

## v0.5
- Полный отчёт можно сохранить в `.txt`, поэтому размер буфера обмена больше не мешает.
- Кнопка «КОПИРОВАТЬ КРАТКИЙ ИТОГ» оставляет только ключевые строки A2DP/Shizuku/codec.
- bluetooth_manager dump сокращён и больше не размножает одинаковые блоки metadata.
- CODEC SUMMARY понимает Android `optional codec support=0/1`.

## v0.5.2
- «Краткий итог» теперь действительно короткий: без огромных metadata-блоков.
- Исправлены буквальные `\n` в тексте краткого отчёта.
- В итог отдельно выводится `optional codec support` выбранных AirPods и вывод по AAC.


## v0.6
- Исправлено определение имени/адреса активного A2DP-устройства в кратком итоге.
- Если AAC уже используется, итог пишет `AAC: АКТИВЕН СЕЙЧАС`.
- Текущий кодек выводится компактно: кодек, частота, битность, каналы.
- Добавлен пассивный fingerprint платформы/чипа:
  - Airoha Technology: Company ID `0x0094` / `0x07E3`;
  - Airoha RACE: vendor RFCOMM UUID `00000000-0000-0000-0099-AABBCCDDEEFF`;
  - Bestechnic/BES: Company ID `0x02B0`;
  - Zhuhai Jieli/JL: Company ID `0x05D6`;
  - Beken: Company ID `0x05F0`.
- Исправлена старая ошибка: `0x05D6` — это Jieli, а не Airoha.
- Apple `0x004C` и Apple AAP UUID сами по себе не считаются доказательством модели SoC: реплики их эмулируют.
- Если сильного vendor-признака нет, программа честно пишет, что точная модель SoC не определена.


## v0.7
- Добавлен `CONTROLLER / LMP`.
- Через Shizuku приложение пытается получить `LMP Version`, `Manufacturer` и `LMP Subversion`
  из `bt_config.conf` (если shell имеет доступ), Bluetooth stack logcat и `dumpsys bluetooth_manager`.
- В краткий итог добавлены `Controller manufacturer`, `Controller LMP`, `Chip model hint`.
- По LMP Manufacturer Code распознаются Airoha, Bestechnic/BES, Zhuhai Jieli/JL, Beken и Apple.
- `LMP Subversion` показывается в hex и decimal.
- Точную модель приложение не выдумывает: если subversion не имеет надёжного публичного соответствия
  конкретному AB/BES/JL-чипу, показывается семейство и сырой subversion.
- Добавлена кнопка `6. LMP / производитель контроллера`.


## v0.8
- Исправлена важная ошибка при двух одновременно подключённых A2DP-устройствах:
  программа больше не считает первое устройство в списке автоматически проверяемым.
- Сначала пытается определить устройство, на котором реально идёт A2DP-воспроизведение;
  затем Shizuku уточняет `mActiveDevice` из `dumpsys bluetooth_manager`.
- `CODEC SUMMARY` теперь разбирает только `A2dpStateMachine` выбранного/активного устройства.
  Локальные возможности телефона (`aptX/LDAC/...`) больше не должны попадать в `Selectable` наушников.
- Добавлена попытка чтения Bluetooth HCI snoop (`btsnoop_hci.log`) через Shizuku.
  Из события `Read Remote Version Information Complete` извлекаются настоящий remote
  LMP manufacturer code и LMP subversion, если лог доступен.
- HCI событие сопоставляется с текущим ACL connection handle выбранного устройства.
  Без сопоставления приложение не выдаёт чужой контроллер за чип наушников.
- Локальный блок `HCI Controller Dumpsys` телефона (например Qualcomm) не считается данными наушников.
- Если btsnoop недоступен, итог прямо просит включить `Bluetooth HCI snoop log`,
  перезапустить Bluetooth и переподключить проверяемые наушники.
