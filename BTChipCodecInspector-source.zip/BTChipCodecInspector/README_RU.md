# BT Chip & Codec Inspector 0.2.1

Диагностическое Android-приложение для Bluetooth-наушников.

## Новое в 0.2.1

- исправлена сборка с Shizuku/AndroidX в GitHub Actions;

## Новое в 0.2

- одна кнопка «ПОЛНАЯ ДИАГНОСТИКА»;
- интеграция с Shizuku 13.x;
- Shizuku UserService запускается от shell/root UID и читает `dumpsys bluetooth_manager` и `dumpsys media.audio_policy`;
- автоматический краткий вывод по текущему A2DP-кодеку и selectable capabilities;
- BLE scan, Apple manufacturer data, SDP и GATT остаются в отчёте;
- добавлена собственная иконка приложения;
- тёмная тема.

## Как пользоваться

1. Установить и запустить Shizuku.
2. На Android 11+ Shizuku можно запускать через Wireless debugging без компьютера.
3. Открыть приложение и нажать «SHIZUKU: ПОДКЛЮЧИТЬ / РАЗРЕШИТЬ»; подтвердить разрешение в Shizuku.
4. Подключить нужные Bluetooth-наушники.
5. Нажать «ПОЛНАЯ ДИАГНОСТИКА» и дождаться строки `FULL DIAGNOSTIC v0.2 FINISHED`.
6. Нажать «Копировать отчёт».

Приложение ничего не прошивает и не записывает в наушники. Оно только читает системную/BT диагностическую информацию.


## v0.4
- добавлен обязательный `rikka.shizuku.ShizukuProvider` в AndroidManifest;
- приложение теперь определяется Shizuku и может получать Binder/запрашивать разрешение;
- после появления Shizuku Binder приложение автоматически запрашивает доступ и подключает shell UserService.

## v0.5
- Полный отчёт можно сохранить в `.txt`, поэтому размер буфера обмена больше не мешает.
- Кнопка «КОПИРОВАТЬ КРАТКИЙ ИТОГ» оставляет только ключевые строки A2DP/Shizuku/codec.
- bluetooth_manager dump сокращён и больше не размножает одинаковые блоки metadata.
- CODEC SUMMARY понимает Android `optional codec support=0/1`.

## v0.5.2
- «Краткий итог» теперь действительно короткий: без огромных metadata-блоков.
- Исправлены буквальные `\n` в тексте краткого отчёта.
- В итог отдельно выводится `optional codec support` выбранных AirPods и вывод по AAC.


## v0.6
- Исправлено определение имени/адреса активного A2DP-устройства в кратком итоге.
- Если AAC уже используется, итог пишет `AAC: АКТИВЕН СЕЙЧАС`.
- Текущий кодек выводится компактно: кодек, частота, битность, каналы.
- Добавлен пассивный fingerprint платформы/чипа:
  - Airoha Technology: Company ID `0x0094` / `0x07E3`;
  - Airoha RACE: vendor RFCOMM UUID `00000000-0000-0000-0099-AABBCCDDEEFF`;
  - Bestechnic/BES: Company ID `0x02B0`;
  - Zhuhai Jieli/JL: Company ID `0x05D6`;
  - Beken: Company ID `0x05F0`.
- Исправлена старая ошибка: `0x05D6` — это Jieli, а не Airoha.
- Apple `0x004C` и Apple AAP UUID сами по себе не считаются доказательством модели SoC: реплики их эмулируют.
- Если сильного vendor-признака нет, программа честно пишет, что точная модель SoC не определена.


## v0.7
- Добавлен `CONTROLLER / LMP`.
- Через Shizuku приложение пытается получить `LMP Version`, `Manufacturer` и `LMP Subversion`
  из `bt_config.conf` (если shell имеет доступ), Bluetooth stack logcat и `dumpsys bluetooth_manager`.
- В краткий итог добавлены `Controller manufacturer`, `Controller LMP`, `Chip model hint`.
- По LMP Manufacturer Code распознаются Airoha, Bestechnic/BES, Zhuhai Jieli/JL, Beken и Apple.
- `LMP Subversion` показывается в hex и decimal.
- Точную модель приложение не выдумывает: если subversion не имеет надёжного публичного соответствия
  конкретному AB/BES/JL-чипу, показывается семейство и сырой subversion.
- Добавлена кнопка `6. LMP / производитель контроллера`.


## v0.8
- Исправлена важная ошибка при двух одновременно подключённых A2DP-устройствах:
  программа больше не считает первое устройство в списке автоматически проверяемым.
- Сначала пытается определить устройство, на котором реально идёт A2DP-воспроизведение;
  затем Shizuku уточняет `mActiveDevice` из `dumpsys bluetooth_manager`.
- `CODEC SUMMARY` теперь разбирает только `A2dpStateMachine` выбранного/активного устройства.
  Локальные возможности телефона (`aptX/LDAC/...`) больше не должны попадать в `Selectable` наушников.
- Добавлена попытка чтения Bluetooth HCI snoop (`btsnoop_hci.log`) через Shizuku.
  Из события `Read Remote Version Information Complete` извлекаются настоящий remote
  LMP manufacturer code и LMP subversion, если лог доступен.
- HCI событие сопоставляется с текущим ACL connection handle выбранного устройства.
  Без сопоставления приложение не выдаёт чужой контроллер за чип наушников.
- Локальный блок `HCI Controller Dumpsys` телефона (например Qualcomm) не считается данными наушников.
- Если btsnoop недоступен, итог прямо просит включить `Bluetooth HCI snoop log`,
  перезапустить Bluetooth и переподключить проверяемые наушники.


## v0.9
- Полная диагностика теперь автоматически ждёт Shizuku UserService примерно 5 секунд.
- Если binder появился с задержкой, приложение само продолжит CODEC/LMP dump — закрывать и открывать приложение не нужно.
- Если Shizuku не подключился, обычный `dumpsys` без прав больше не запускается как будто это полноценный результат:
  диагностика честно пишет, что CODEC/LMP часть пропущена.
- Кнопка `LMP / производитель контроллера` использует то же автоматическое ожидание.
- Увеличено окно полной диагностики до 21 секунды, чтобы Shizuku и HCI-проверка успели завершиться.
- SDP UUID `fe010000-1234-5678-abcd-00805f9b34fb` теперь распознаётся как сильный fingerprint `JL_SPP`;
  программа пишет `Jieli/JL family — высокая вероятность`, но не придумывает точную AC/JL-модель.


## v1.0 — Jieli in-ear detection

Добавлено прямое управление `In-ear detection` для выбранных Jieli/JL-наушников через официальный JieLi Home/RCSP SDK.

Что делает:
- подключается к уже выбранному A2DP-устройству напрямую по SPP/RCSP;
- не использует фильтр устройств PiHome, из-за которого некоторые реплики не появляются в официальном приложении;
- перед записью обязательно проверяет наличие SDP fingerprint:
  `fe010000-1234-5678-abcd-00805f9b34fb` (`JL_SPP`);
- кнопка `Jieli: ПРОЧИТАТЬ обнаружение уха` читает `ADV_TYPE_IN_EAR_CHECK`;
- кнопка `Jieli: ВЫКЛЮЧИТЬ обнаружение уха` отправляет официальное состояние `1 = OFF`;
- кнопка `Jieli: ВКЛЮЧИТЬ обнаружение уха` отправляет официальное состояние `2 = ON`;
- после записи приложение повторно читает значение и показывает подтверждённое состояние.

Защита от случайной записи:
- если `JL_SPP` UUID у выбранного устройства не найден, приложение НЕ отправляет команду;
- сначала делает повторный SDP-запрос, затем ещё раз проверяет fingerprint;
- Jieli SDK настроен на SPP, device auth OFF и auto-reconnect OFF.

Сборка:
- используются официальные `jl_bluetooth_rcsp`, `jl_bt_ota` и `jldecryption` AAR;
- `app/build.gradle` автоматически скачивает их с зафиксированного upstream commit
  `6293873b641ffd8d461773873ecedef1a9d9038d` перед `preBuild`;
- обычный GitHub Actions workflow из предыдущих версий менять не требуется.

Важно:
- это первая версия с функцией записи настройки в наушники;
- команда взята из официального JieLi Home SDK: `ADV_TYPE_IN_EAR_CHECK = 8`,
  состояние `1 = выключено`, `2 = включено`;
- если прошивка реплики использует несовместимый/урезанный RCSP, приложение покажет ошибку или таймаут и ничего не будет выдумывать.


## v1.0.1
Исправлен запуск JieLi RCSP на Android:
- добавлена зависимость `androidx.collection:collection:1.4.5`;
- устраняет `NoClassDefFoundError: androidx/collection/ArrayMap`;
- логика Jieli In-ear READ/OFF/ON не менялась.


## v1.0.2 — понятный статус обнаружения уха

Добавлена отдельная крупная строка состояния над кнопками Jieli:

- `⚪ НЕ ПРОВЕРЕНО`
- `⏳ ПРОВЕРЯЮ...`
- `✅ ОБНАРУЖЕНИЕ УХА: ВЫКЛЮЧЕНО`
- `⚠️ ОБНАРУЖЕНИЕ УХА: ВКЛЮЧЕНО`
- `❌ НЕ ОПРЕДЕЛЕНО`
- `❌ ОШИБКА`

После нажатия `ВКЛЮЧИТЬ` или `ВЫКЛЮЧИТЬ` приложение:
1. показывает, что выполняет команду;
2. ждёт подтверждение Jieli;
3. повторно читает состояние;
4. показывает конечный результат крупным текстом.

Если состояние уже OFF/ON, соответствующая кнопка меняется на
`✓ УЖЕ ВЫКЛЮЧЕНО` / `✓ УЖЕ ВКЛЮЧЕНО` и блокируется.

При переключении на другую пару статус сбрасывается в `НЕ ПРОВЕРЕНО`,
чтобы не показывать старое состояние от других наушников.


## v1.0.3
Исправлен второй runtime-сбой JieLi:
`NoClassDefFoundError: com.jieli.bluetooth.tool.DeviceAddrManager`.

Что изменено:
- приложение больше не вызывает `DeviceAddrManager` напрямую;
- официальные JieLi AAR теперь подключаются в Gradle явными `implementation files(...)`,
  а не динамическим `fileTree`;
- добавлен официальный `jl-component-lib_V1.4.0_10400-release.aar`;
- сохранена зависимость `androidx.collection`, добавленная в v1.0.1;
- экран статуса обнаружения уха из v1.0.2 сохранён без изменений.


## v1.0.4
Исправлена ошибка сборки Android resources после добавления `jl-component-lib`:

- `attr/windowNoTitle not found`
- `attr/windowActionBar not found`

Добавлена зависимость:
`androidx.appcompat:appcompat:1.7.0`

Она предоставляет AppCompat-атрибуты, которые использует официальный
`jl-component-lib` от JieLi.


## v1.0.5
Исправлена ошибка `checkDebugDuplicateClasses`:

- `kotlin-stdlib:1.8.22`
- `kotlin-stdlib-jdk7:1.6.21`
- `kotlin-stdlib-jdk8:1.6.21`

В Kotlin 1.8 функции jdk7/jdk8 уже объединены в основной `kotlin-stdlib`,
поэтому старые отдельные jdk7/jdk8-модули исключены из всех конфигураций.
Также версия Kotlin stdlib зафиксирована на `1.8.22`.


## v1.0.6 — исправлена настоящая причина падения Jieli SDK

По готовому APK проверено: класс
`com.jieli.bluetooth.tool.DeviceAddrManager` в APK **есть**.

Первичная ошибка была:
`NoClassDefFoundError: com/google/gson/GsonBuilder`.

После неудачной инициализации Android затем показывал
`NoClassDefFoundError: DeviceAddrManager` как вторичную ошибку загрузки класса.

Исправление:
- добавлен `com.google.code.gson:gson:2.13.1`;
- удалён лишний `jl-component-lib`, который для этой функции не нужен;
- удалён добавленный ради него AppCompat;
- удалён больше не нужный обход конфликта Kotlin jdk7/jdk8.

Это должно заметно уменьшить APK по сравнению с v1.0.5.
Jieli RCSP, OTA/auth AAR, AndroidX Collection и весь экран понятного статуса
обнаружения уха сохранены.


## v1.0.7
Исправлена следующая отсутствующая runtime-зависимость JieLi RCSP:

`NoClassDefFoundError: androidx/core/app/ActivityCompat`

Добавлено:
`androidx.core:core:1.13.1`

Важно:
- добавлен именно `androidx.core`, без `core-ktx`;
- это не должно возвращать конфликт Kotlin jdk7/jdk8;
- Gson, JL RCSP и понятный статус обнаружения уха сохранены.


## v1.0.8 — JL_SPP custom UUID

По логу v1.0.7:
`Jieli RCSP connection status=3` означает `CONNECTION_CONNECTING`.
То есть SDK уже запускается и начинает SPP-подключение, но остаётся в Connecting.

Причина, которую теперь проверяем:
официальный JieLi SDK по умолчанию использует стандартный SPP UUID,
а выбранная пара явно рекламирует отдельный `JL_SPP`:
`fe010000-1234-5678-abcd-00805f9b34fb`.

В v1.0.8:
- `BluetoothOption.setSppUUID(...)` принудительно установлен на этот `JL_SPP` UUID;
- в лог выводится используемый SPP UUID;
- числовые статусы RCSP теперь подписываются:
  `CONNECTING / OK / FAILED / DISCONNECT`.

Официальная документация JieLi прямо поддерживает замену SPP communication UUID
через `BluetoothOption.setSppUUID(UUID.fromString(...))`.
