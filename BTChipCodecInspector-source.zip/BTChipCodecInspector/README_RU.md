# BT Chip & Codec Inspector

Небольшое диагностическое Android-приложение для Bluetooth-наушников.

## Что умеет

- показывает реально подключённые A2DP-устройства;
- читает SDP UUID;
- сканирует BLE-рекламу и выводит raw hex, manufacturer data, service data и UUID;
- выделяет Apple Company ID `0x004C` и Airoha Company ID `0x05D6` как подсказки, но не выдаёт их за стопроцентное определение SoC;
- подключается по BLE GATT, перечисляет сервисы/характеристики и читает доступные READ-характеристики (включая Device Information);
- слушает системное событие изменения A2DP codec status и, если Android его отдаёт, показывает CURRENT / SELECTABLE / LOCAL CAPABILITIES;
- с разрешением `android.permission.DUMP` читает `dumpsys bluetooth_manager` и `dumpsys media.audio_policy`, фильтруя строки про A2DP/кодеки.

## Важное ограничение

Приложение не может «добавить» AAC в наушники. Если AAC отсутствует в `SELECTABLE`/в Bluetooth negotiation, значит удалённое устройство его не объявляет (либо прошивка отключила его). Принудительный выбор на телефоне не создаёт AAC-декодер внутри наушников.

Также точный Bluetooth SoC нельзя гарантированно узнать программно, если прошивка подменяет Apple manufacturer data и не публикует vendor-specific UUID/Device Information. Тогда окончательный способ — маркировка микросхемы на плате.

## Сборка

Открой папку проекта в Android Studio (JDK 17), дождись Gradle Sync и собери `app` (`Build > Build APK(s)`).

Минимальная версия Android: 13 (API 33).

## Расширенный Codec dump

Обычное приложение не получает `android.permission.DUMP`. Для своего телефона его можно выдать один раз через ADB:

```sh
adb shell pm grant com.example.btchipcodec android.permission.DUMP
adb shell pm grant com.example.btchipcodec android.permission.READ_LOGS
```

Либо выполнить эти же команды на телефоне через Shizuku + shell-приложение, работающее от shell UID.

После этого кнопка `Codec dump` сможет получить больше информации из Bluetooth service.

## Как проверять AirPods-копию

1. Подключи нужную пару в системном Bluetooth.
2. Запусти приложение и выдай Bluetooth permissions.
3. Нажми `Найти подключённые A2DP-наушники` и выбери пару.
4. Нажми `Инфо + SDP`.
5. Укажи фильтр `AirPods`, открой кейс рядом с телефоном и запусти `Сканировать BLE 10 секунд`.
6. Нажми `GATT выбранного BLE-устройства`.
7. Запусти музыку. Если система отправляет `CODEC_CONFIG_CHANGED`, в отчёте появятся текущий и выбираемые кодеки.
8. Для максимума данных выдай DUMP и нажми `Codec dump`.
9. Скопируй отчёт кнопкой `Копировать отчёт`.

## Безопасность

Приложение только сканирует, перечисляет сервисы и читает характеристики, которые устройство само пометило как READ. Оно не пишет во флеш наушников и не выполняет OTA/FOTA.
