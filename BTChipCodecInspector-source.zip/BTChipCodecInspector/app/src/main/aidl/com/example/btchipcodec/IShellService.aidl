package com.example.btchipcodec;

interface IShellService {
    String exec(String command);
    int uid();
    String airpodsAap(String address, int action);
}
