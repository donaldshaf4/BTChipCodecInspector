package com.example.btchipcodec;

import android.content.Context;
import android.os.Process;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ShellService extends IShellService.Stub {
    public ShellService() { }
    public ShellService(Context context) { }

    @Override
    public String exec(String command) {
        StringBuilder out = new StringBuilder();
        try {
            java.lang.Process p = new ProcessBuilder("sh", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                int lines = 0;
                while ((line = br.readLine()) != null) {
                    if (lines++ < 4000) out.append(line).append('\n');
                }
            }
            int code = p.waitFor();
            out.append("\n[exit=").append(code).append("]\n");
        } catch (Throwable t) {
            out.append("ERROR: ").append(t.getClass().getSimpleName()).append(": ")
                    .append(t.getMessage()).append('\n');
        }
        return out.toString();
    }

    @Override
    public int uid() {
        return Process.myUid();
    }
}
