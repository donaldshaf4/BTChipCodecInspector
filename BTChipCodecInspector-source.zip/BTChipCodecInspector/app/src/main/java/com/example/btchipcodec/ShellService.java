package com.example.btchipcodec;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.ParcelUuid;
import android.os.Process;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Constructor;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;

public class ShellService extends IShellService.Stub {
    private final Context serviceContext;

    private static final String AAP_UUID = "74ec2172-0bad-4d01-8f77-997b2be0722a";
    private static final int AAP_PSM = 0x1001; // 4097, classic BR/EDR L2CAP
    private static final int TYPE_L2CAP = 3;

    private static final byte[] AAP_HANDSHAKE = hexBytes(
            "00 00 04 00 01 00 02 00 00 00 00 00 00 00 00 00");
    private static final byte[] AAP_REQUEST_NOTIFICATIONS = hexBytes(
            "04 00 04 00 0F 00 FF FF FF FF");

    public ShellService() {
        this.serviceContext = null;
    }

    // Shizuku API v13 can construct UserService with a package Context.
    // v1.1.0 accepted this Context but accidentally discarded it, which made
    // BluetoothAdapter.getDefaultAdapter() return null in the shell process
    // on this HyperOS device.
    public ShellService(Context context) {
        this.serviceContext = context;
    }

    @Override
    public String exec(String command) {
        StringBuilder out = new StringBuilder();
        try {
            java.lang.Process p = new ProcessBuilder("sh", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                int lines = 0;
                while ((line = br.readLine()) != null) {
                    if (lines++ < 4000) out.append(line).append('\n');
                }
            }
            int code = p.waitFor();
            out.append("\n[exit=").append(code).append("]\n");
        } catch (Throwable t) {
            out.append("ERROR: ").append(t.getClass().getSimpleName()).append(": ")
                    .append(t.getMessage()).append('\n');
        }
        return out.toString();
    }

    @Override
    public int uid() {
        return Process.myUid();
    }

    @Override
    public String airpodsAap(String address, int action) {
        final AtomicReference<BluetoothSocket> socketRef = new AtomicReference<>();
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Future<String> future = executor.submit(() -> doAirpodsAap(address, action, socketRef));
        try {
            return future.get(14, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            BluetoothSocket socket = socketRef.get();
            if (socket != null) {
                try { socket.close(); } catch (Throwable ignored) { }
            }
            future.cancel(true);
            return "AAP_ERROR=TIMEOUT\n" +
                    "AAP_MESSAGE=Таймаут открытия/обмена AAP L2CAP PSM 0x1001\n";
        } catch (Throwable t) {
            return "AAP_ERROR=" + t.getClass().getSimpleName() + "\n" +
                    "AAP_MESSAGE=" + String.valueOf(t.getMessage()) + "\n";
        } finally {
            executor.shutdownNow();
        }
    }

    private String doAirpodsAap(String address, int action,
                                AtomicReference<BluetoothSocket> socketRef) {
        StringBuilder out = new StringBuilder();
        BluetoothSocket socket = null;
        try {
            if (address == null || address.trim().isEmpty()) {
                return "AAP_ERROR=NO_ADDRESS\n";
            }
            if (action < 0 || action > 2) {
                return "AAP_ERROR=BAD_ACTION\n";
            }

            out.append("AAP_SERVICE_UID=").append(Process.myUid()).append('\n');

            BluetoothAdapter adapter = null;
            String adapterSource = "none";

            // In a Shizuku UserService process the deprecated static
            // BluetoothAdapter.getDefaultAdapter() may return null.
            // Prefer BluetoothManager from the Context supplied by Shizuku.
            if (serviceContext != null) {
                try {
                    BluetoothManager manager =
                            (BluetoothManager) serviceContext.getSystemService(Context.BLUETOOTH_SERVICE);
                    if (manager != null) {
                        adapter = manager.getAdapter();
                        if (adapter != null) adapterSource = "Shizuku Context -> BluetoothManager";
                    }
                    out.append("AAP_CONTEXT=SHIZUKU_V13\n");
                } catch (Throwable t) {
                    out.append("AAP_CONTEXT_ERROR=")
                            .append(t.getClass().getSimpleName()).append(':')
                            .append(String.valueOf(t.getMessage())).append('\n');
                }
            } else {
                out.append("AAP_CONTEXT=NULL\n");
            }

            if (adapter == null) {
                try {
                    adapter = BluetoothAdapter.getDefaultAdapter();
                    if (adapter != null) adapterSource = "BluetoothAdapter.getDefaultAdapter";
                } catch (Throwable t) {
                    out.append("AAP_DEFAULT_ADAPTER_ERROR=")
                            .append(t.getClass().getSimpleName()).append(':')
                            .append(String.valueOf(t.getMessage())).append('\n');
                }
            }

            if (adapter == null) {
                try {
                    Class<?> at = Class.forName("android.app.ActivityThread");
                    Object app = at.getMethod("currentApplication").invoke(null);
                    if (app instanceof Context) {
                        BluetoothManager manager =
                                (BluetoothManager) ((Context) app).getSystemService(Context.BLUETOOTH_SERVICE);
                        if (manager != null) {
                            adapter = manager.getAdapter();
                            if (adapter != null) adapterSource = "ActivityThread.currentApplication -> BluetoothManager";
                        }
                    }
                } catch (Throwable t) {
                    out.append("AAP_APPLICATION_CONTEXT_ERROR=")
                            .append(t.getClass().getSimpleName()).append(':')
                            .append(String.valueOf(t.getMessage())).append('\n');
                }
            }

            out.append("AAP_ADAPTER_SOURCE=").append(adapterSource).append('\n');

            if (adapter == null) {
                out.append("AAP_ERROR=NO_ADAPTER\n");
                out.append("AAP_MESSAGE=Shizuku UserService не получил BluetoothAdapter даже через Context/BluetoothManager.\n");
                return out.toString();
            }

            try {
                out.append("AAP_ADAPTER_ENABLED=").append(adapter.isEnabled() ? "1" : "0").append('\n');
            } catch (Throwable ignored) { }

            BluetoothDevice device = adapter.getRemoteDevice(address);
            try { adapter.cancelDiscovery(); } catch (Throwable ignored) { }

            out.append("AAP_TARGET=").append(address).append('\n');
            out.append("AAP_UUID=").append(AAP_UUID).append('\n');
            out.append("AAP_PSM=0x1001 (4097)\n");
            out.append("AAP_ACTION=").append(action == 0 ? "READ" : action == 1 ? "DISABLE" : "ENABLE").append('\n');

            SocketBuildResult built = createClassicL2capSocket(adapter, device,
                    ParcelUuid.fromString(AAP_UUID), AAP_PSM);
            socket = built.socket;
            socketRef.set(socket);
            out.append("AAP_SOCKET_CONSTRUCTOR=").append(built.description).append('\n');

            socket.connect();
            out.append("AAP_CONNECTED=1\n");

            InputStream in = socket.getInputStream();
            OutputStream os = socket.getOutputStream();

            writePacket(os, AAP_HANDSHAKE, out, "HANDSHAKE");
            sleepQuiet(120);

            writePacket(os, AAP_REQUEST_NOTIFICATIONS, out, "REQUEST_NOTIFICATIONS");
            byte[] before = collectBytes(in, 850);
            if (before.length > 0) {
                out.append("AAP_RX_BEFORE=").append(toHex(before)).append('\n');
            }
            int beforeState = findLastEarConfig(before);
            appendEarState(out, "EAR_STATE_BEFORE", beforeState);

            if (action == 1 || action == 2) {
                int requested = action == 1 ? 0x02 : 0x01; // AAP: 1 enabled, 2 disabled
                byte[] command = new byte[]{
                        0x04, 0x00, 0x04, 0x00,
                        0x09, 0x00, 0x0A, (byte) requested,
                        0x00, 0x00, 0x00
                };
                writePacket(os, command, out, action == 1 ? "EAR_DISABLE" : "EAR_ENABLE");

                byte[] after = collectBytes(in, 2200);
                if (after.length > 0) {
                    out.append("AAP_RX_AFTER=").append(toHex(after)).append('\n');
                }

                int afterState = findLastEarConfig(after);
                appendEarState(out, "EAR_STATE", afterState);

                boolean confirmed = afterState == requested;
                out.append("AAP_COMMAND_SENT=1\n");
                out.append("AAP_COMMAND_CONFIRMED=").append(confirmed ? "1" : "0").append('\n');

                if (!confirmed && afterState < 0) {
                    out.append("AAP_MESSAGE=Команда отправлена, но подтверждающий пакет 0x09/0x0A не получен.\n");
                }
            } else {
                int state = beforeState;
                if (state >= 0) appendEarState(out, "EAR_STATE", state);
                else out.append("EAR_STATE=UNKNOWN\n");
            }

            return out.toString();
        } catch (Throwable t) {
            out.append("AAP_ERROR=").append(t.getClass().getSimpleName()).append('\n');
            out.append("AAP_MESSAGE=").append(String.valueOf(t.getMessage())).append('\n');
            return out.toString();
        } finally {
            if (socket != null) {
                try { socket.close(); } catch (Throwable ignored) { }
            }
            socketRef.set(null);
        }
    }

    private static void writePacket(OutputStream os, byte[] packet,
                                    StringBuilder out, String name) throws Exception {
        os.write(packet);
        os.flush();
        out.append("AAP_TX_").append(name).append('=').append(toHex(packet)).append('\n');
    }

    private static byte[] collectBytes(InputStream in, long windowMs) {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        long end = System.currentTimeMillis() + windowMs;
        byte[] buffer = new byte[1024];

        while (System.currentTimeMillis() < end && !Thread.currentThread().isInterrupted()) {
            try {
                int available = in.available();
                if (available > 0) {
                    int n = in.read(buffer, 0, Math.min(buffer.length, available));
                    if (n > 0) bos.write(buffer, 0, n);
                } else {
                    Thread.sleep(35);
                }
            } catch (Throwable t) {
                break;
            }
        }
        return bos.toByteArray();
    }

    // Control command packet:
    // 04 00 04 00 09 00 0A [01=enabled / 02=disabled] ...
    private static int findLastEarConfig(byte[] data) {
        if (data == null || data.length < 8) return -1;
        int state = -1;
        for (int i = 0; i + 7 < data.length; i++) {
            if ((data[i] & 0xFF) == 0x04 &&
                    (data[i + 1] & 0xFF) == 0x00 &&
                    (data[i + 2] & 0xFF) == 0x04 &&
                    (data[i + 3] & 0xFF) == 0x00 &&
                    (data[i + 4] & 0xFF) == 0x09 &&
                    (data[i + 5] & 0xFF) == 0x00 &&
                    (data[i + 6] & 0xFF) == 0x0A) {
                int v = data[i + 7] & 0xFF;
                if (v == 1 || v == 2) state = v;
            }
        }
        return state;
    }

    private static void appendEarState(StringBuilder out, String key, int state) {
        if (state == 1) out.append(key).append("=ON\n");
        else if (state == 2) out.append(key).append("=OFF\n");
        else out.append(key).append("=UNKNOWN\n");
    }

    private static class SocketBuildResult {
        final BluetoothSocket socket;
        final String description;
        SocketBuildResult(BluetoothSocket socket, String description) {
            this.socket = socket;
            this.description = description;
        }
    }

    /**
     * Android has no public API for classic BR/EDR L2CAP client sockets.
     * The Shizuku UserService runs as shell, so we try the known platform
     * BluetoothSocket constructor layouts and keep all use inside this process.
     */
    private static SocketBuildResult createClassicL2capSocket(
            BluetoothAdapter adapter, BluetoothDevice device,
            ParcelUuid uuid, int psm) throws Exception {

        Throwable last = null;

        // A16 QPR style: (BluetoothAdapter, BluetoothDevice, int, boolean, boolean, int, ParcelUuid)
        try {
            Constructor<BluetoothSocket> c = BluetoothSocket.class.getDeclaredConstructor(
                    BluetoothAdapter.class, BluetoothDevice.class,
                    int.class, boolean.class, boolean.class, int.class, ParcelUuid.class);
            c.setAccessible(true);
            return new SocketBuildResult(
                    c.newInstance(adapter, device, TYPE_L2CAP, true, true, psm, uuid),
                    "(BluetoothAdapter,BluetoothDevice,int,boolean,boolean,int,ParcelUuid)");
        } catch (Throwable t) { last = t; }

        // (BluetoothDevice, int, boolean, boolean, int, ParcelUuid)
        try {
            Constructor<BluetoothSocket> c = BluetoothSocket.class.getDeclaredConstructor(
                    BluetoothDevice.class, int.class,
                    boolean.class, boolean.class, int.class, ParcelUuid.class);
            c.setAccessible(true);
            return new SocketBuildResult(
                    c.newInstance(device, TYPE_L2CAP, true, true, psm, uuid),
                    "(BluetoothDevice,int,boolean,boolean,int,ParcelUuid)");
        } catch (Throwable t) { last = t; }

        // (BluetoothDevice, int, int, boolean, boolean, int, ParcelUuid)
        for (int fd : new int[]{-1, 1}) {
            try {
                Constructor<BluetoothSocket> c = BluetoothSocket.class.getDeclaredConstructor(
                        BluetoothDevice.class, int.class, int.class,
                        boolean.class, boolean.class, int.class, ParcelUuid.class);
                c.setAccessible(true);
                return new SocketBuildResult(
                        c.newInstance(device, TYPE_L2CAP, fd, true, true, psm, uuid),
                        "(BluetoothDevice,int,int,boolean,boolean,int,ParcelUuid),fd=" + fd);
            } catch (Throwable t) { last = t; }
        }

        // (int, int, boolean, boolean, BluetoothDevice, int, ParcelUuid)
        for (int fd : new int[]{-1, 1}) {
            try {
                Constructor<BluetoothSocket> c = BluetoothSocket.class.getDeclaredConstructor(
                        int.class, int.class, boolean.class, boolean.class,
                        BluetoothDevice.class, int.class, ParcelUuid.class);
                c.setAccessible(true);
                return new SocketBuildResult(
                        c.newInstance(TYPE_L2CAP, fd, true, true, device, psm, uuid),
                        "(int,int,boolean,boolean,BluetoothDevice,int,ParcelUuid),fd=" + fd);
            } catch (Throwable t) { last = t; }
        }

        // (int, boolean, boolean, BluetoothDevice, int, ParcelUuid)
        try {
            Constructor<BluetoothSocket> c = BluetoothSocket.class.getDeclaredConstructor(
                    int.class, boolean.class, boolean.class,
                    BluetoothDevice.class, int.class, ParcelUuid.class);
            c.setAccessible(true);
            return new SocketBuildResult(
                    c.newInstance(TYPE_L2CAP, true, true, device, psm, uuid),
                    "(int,boolean,boolean,BluetoothDevice,int,ParcelUuid)");
        } catch (Throwable t) { last = t; }

        StringBuilder constructors = new StringBuilder();
        for (Constructor<?> c : BluetoothSocket.class.getDeclaredConstructors()) {
            constructors.append(c.toString()).append(" | ");
        }
        throw new IllegalStateException(
                "No compatible BluetoothSocket L2CAP constructor. Last=" +
                        String.valueOf(last) + "; constructors=" + constructors);
    }

    private static byte[] hexBytes(String s) {
        String clean = s.replaceAll("[^0-9A-Fa-f]", "");
        byte[] out = new byte[clean.length() / 2];
        for (int i = 0; i < out.length; i++) {
            out[i] = (byte) Integer.parseInt(clean.substring(i * 2, i * 2 + 2), 16);
        }
        return out;
    }

    private static String toHex(byte[] data) {
        if (data == null) return "";
        StringBuilder sb = new StringBuilder(data.length * 2);
        for (byte b : data) sb.append(String.format(Locale.US, "%02X", b & 0xFF));
        return sb.toString();
    }

    private static void sleepQuiet(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }
}
