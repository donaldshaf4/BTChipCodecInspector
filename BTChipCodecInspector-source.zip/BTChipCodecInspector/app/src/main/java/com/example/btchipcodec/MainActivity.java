package com.example.btchipcodec;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothCodecConfig;
import android.bluetooth.BluetoothCodecStatus;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.util.SparseArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ_BT = 1001;
    private static final int REQ_SHIZUKU = 2001;
    private static final int REQ_SAVE_REPORT = 3001;
    private static final String ACTION_CODEC_CONFIG_CHANGED =
            "android.bluetooth.a2dp.profile.action.CODEC_CONFIG_CHANGED";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private BluetoothAdapter adapter;
    private BluetoothA2dp a2dp;
    private BluetoothLeScanner bleScanner;
    private BluetoothGatt activeGatt;
    private IShellService shellService;
    private boolean shizukuBinding;
    private boolean fullDiagnosticRunning;

    private TextView output;
    private EditText nameFilter;
    private Spinner a2dpSpinner;
    private ArrayAdapter<String> a2dpAdapter;
    private final List<BluetoothDevice> a2dpDevices = new ArrayList<>();
    private BluetoothDevice selectedA2dpDevice;
    private BluetoothDevice selectedBleDevice;

    private final Map<String, ScanResult> scanResults = new HashMap<>();
    private final ArrayDeque<BluetoothGattCharacteristic> readQueue = new ArrayDeque<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        adapter = manager != null ? manager.getAdapter() : null;

        setContentView(buildUi());
        registerReceivers();

        Shizuku.addBinderReceivedListenerSticky(shizukuBinderReceivedListener);
        Shizuku.addBinderDeadListener(shizukuBinderDeadListener);
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener);

        requestBtPermissionsIfNeeded();
        main.postDelayed(this::refreshShizukuStatus, 500);
    }

    private View buildUi() {
        int pad = dp(14);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("BT Chip & Codec Inspector");
        title.setTextSize(23);
        title.setPadding(0, 0, 0, dp(8));
        root.addView(title);

        TextView note = new TextView(this);
        note.setText("Диагностика BLE/GATT, SDP и реального A2DP-кодека. " +
                "Программа не может добавить AAC в наушники, если сами наушники его не объявляют.");
        note.setTextSize(14);
        note.setPadding(0, 0, 0, dp(12));
        root.addView(note);

        Button full = button("ПОЛНАЯ ДИАГНОСТИКА");
        full.setTextSize(18);
        full.setMinHeight(dp(58));
        full.setOnClickListener(v -> runFullDiagnostic());
        root.addView(full);

        Button shizuku = button("SHIZUKU: ПОДКЛЮЧИТЬ / РАЗРЕШИТЬ");
        shizuku.setOnClickListener(v -> requestOrBindShizuku());
        root.addView(shizuku);

        Button permissions = button("1. Разрешения Bluetooth");
        permissions.setOnClickListener(v -> requestBtPermissionsIfNeeded());
        root.addView(permissions);

        Button refreshA2dp = button("2. Найти подключённые A2DP-наушники");
        refreshA2dp.setOnClickListener(v -> loadA2dpDevices());
        root.addView(refreshA2dp);

        a2dpSpinner = new Spinner(this);
        a2dpAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new ArrayList<>());
        a2dpSpinner.setAdapter(a2dpAdapter);
        a2dpSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < a2dpDevices.size()) {
                    selectedA2dpDevice = a2dpDevices.get(position);
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        root.addView(a2dpSpinner);

        Button sdp = button("Инфо + SDP выбранного A2DP");
        sdp.setOnClickListener(v -> dumpSelectedA2dp());
        root.addView(sdp);

        Button reflection = button("Попробовать получить CodecStatus системным API");
        reflection.setOnClickListener(v -> tryHiddenCodecStatus());
        root.addView(reflection);

        nameFilter = new EditText(this);
        nameFilter.setHint("Фильтр BLE-имени");
        nameFilter.setText("AirPods");
        nameFilter.setSingleLine(true);
        root.addView(nameFilter);

        Button scan = button("3. Сканировать BLE 10 секунд");
        scan.setOnClickListener(v -> startBleScan());
        root.addView(scan);

        Button gatt = button("4. GATT выбранного BLE-устройства");
        gatt.setOnClickListener(v -> connectGattSelected());
        root.addView(gatt);

        Button dump = button("5. Codec dump через Shizuku / обычный shell");
        dump.setOnClickListener(v -> runCodecDump());
        root.addView(dump);

        Button dev = button("Открыть параметры разработчика");
        dev.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
            } catch (Exception e) {
                toast("Не удалось открыть параметры разработчика");
            }
        });
        root.addView(dev);

        Button clear = button("Очистить отчёт");
        clear.setOnClickListener(v -> output.setText(""));
        root.addView(clear);

        Button copySummary = button("КОПИРОВАТЬ КРАТКИЙ ИТОГ");
        copySummary.setOnClickListener(v -> copyShortSummary());
        root.addView(copySummary);

        Button saveFull = button("СОХРАНИТЬ ПОЛНЫЙ ОТЧЁТ .TXT");
        saveFull.setOnClickListener(v -> saveFullReport());
        root.addView(saveFull);

        Button copy = button("Копировать полный отчёт (если небольшой)");
        copy.setOnClickListener(v -> {
            String report = output.getText().toString();
            if (report.length() > 50000) {
                toast("Отчёт слишком длинный. Используй «Сохранить полный отчёт .TXT».");
                return;
            }
            android.content.ClipboardManager cm =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("BT report", report));
            toast("Полный отчёт скопирован");
        });
        root.addView(copy);

        output = new TextView(this);
        output.setTextIsSelectable(true);
        output.setTextSize(12);
        output.setTypeface(android.graphics.Typeface.MONOSPACE);
        output.setPadding(0, dp(12), 0, dp(24));
        root.addView(output, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        return scroll;
    }

    private void copyShortSummary() {
        String summary = buildShortSummary(output.getText().toString());
        android.content.ClipboardManager cm =
                (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("BT short report", summary));
        toast("Краткий итог скопирован (" + summary.length() + " символов)");
    }

    private void saveFullReport() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE,
                "BTChipCodecInspector-" +
                        new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date()) +
                        ".txt");
        startActivityForResult(i, REQ_SAVE_REPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SAVE_REPORT || resultCode != RESULT_OK ||
                data == null || data.getData() == null) {
            return;
        }
        try (OutputStream os = getContentResolver().openOutputStream(data.getData(), "w")) {
            if (os == null) throw new IllegalStateException("openOutputStream returned null");
            os.write(output.getText().toString().getBytes(StandardCharsets.UTF_8));
            os.flush();
            toast("Полный отчёт сохранён в TXT");
        } catch (Exception e) {
            toast("Ошибка сохранения: " + e.getMessage());
        }
    }

    private String buildShortSummary(String report) {
        if (report == null || report.isEmpty()) return "Отчёт пуст.";

        StringBuilder out = new StringBuilder();
        out.append("=== BT CHIP & CODEC — КРАТКИЙ ИТОГ v0.5 ===\\n");

        String[] lines = report.split("\\\\r?\\\\n");
        boolean inA2dp = false;
        boolean inCodecSummary = false;
        int codecSummaryLines = 0;

        for (String line : lines) {
            String low = line.toLowerCase(Locale.ROOT);

            if (line.contains("=== A2DP DEVICE ===")) {
                inA2dp = true;
                out.append("\\n").append(line).append("\\n");
                continue;
            }
            if (inA2dp) {
                if (line.trim().isEmpty()) {
                    inA2dp = false;
                } else if (line.startsWith("Name:") || line.startsWith("Address:") ||
                        line.startsWith("Bond:") || line.startsWith("Type:") ||
                        line.startsWith("SDP cached:")) {
                    out.append(line).append("\\n");
                }
            }

            if (line.contains("Shizuku shell UID=")) {
                out.append("\\n").append(line).append("\\n");
            }

            if (line.contains("Supports optional codec changed:")) {
                out.append(line).append("\\n");
            }

            if (low.contains("optional codec(support=") &&
                    (low.contains("72:e7") || low.contains("last_active_time"))) {
                out.append(line.trim()).append("\\n");
            }

            if (line.contains("=== CODEC SUMMARY ===")) {
                inCodecSummary = true;
                codecSummaryLines = 0;
                out.append("\\n").append(line).append("\\n");
                continue;
            }
            if (inCodecSummary) {
                if (codecSummaryLines < 8 && !line.trim().isEmpty()) {
                    out.append(line).append("\\n");
                    codecSummaryLines++;
                } else if (line.trim().isEmpty() || codecSummaryLines >= 8) {
                    inCodecSummary = false;
                }
            }

            if (line.startsWith("SELECTED BLE:") ||
                    line.contains("AirPods BLE не найден") ||
                    line.contains("Apple-format advertising 0x004C / Proximity Pairing type 0x07")) {
                out.append(line).append("\\n");
            }
        }

        String result = out.toString();
        if (result.length() > 12000) {
            result = result.substring(0, 12000) +
                    "\\n[Краткий итог обрезан до 12000 символов; полный отчёт сохрани в TXT.]\\n";
        }
        return result;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void requestBtPermissionsIfNeeded() {
        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.BLUETOOTH_SCAN);
        }
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), REQ_BT);
        } else {
            log("Bluetooth permissions: OK");
            acquireA2dpProxy();
        }
    }

    private boolean btGranted() {
        return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT && btGranted()) {
            log("Bluetooth permissions: OK");
            acquireA2dpProxy();
        }
    }

    private void acquireA2dpProxy() {
        if (adapter == null || !btGranted()) return;
        adapter.getProfileProxy(this, new BluetoothProfile.ServiceListener() {
            @Override public void onServiceConnected(int profile, BluetoothProfile proxy) {
                if (profile == BluetoothProfile.A2DP) {
                    a2dp = (BluetoothA2dp) proxy;
                    log("A2DP profile proxy: connected");
                    loadA2dpDevices();
                }
            }
            @Override public void onServiceDisconnected(int profile) {
                if (profile == BluetoothProfile.A2DP) {
                    a2dp = null;
                    log("A2DP profile proxy: disconnected");
                }
            }
        }, BluetoothProfile.A2DP);
    }

    private void loadA2dpDevices() {
        if (!ensureBt()) return;
        if (a2dp == null) {
            log("A2DP proxy ещё не готов. Повтори через секунду.");
            acquireA2dpProxy();
            return;
        }
        try {
            List<BluetoothDevice> devices = a2dp.getConnectedDevices();
            a2dpDevices.clear();
            a2dpDevices.addAll(devices);
            List<String> labels = new ArrayList<>();
            for (BluetoothDevice d : devices) {
                labels.add(safeName(d) + "  " + d.getAddress());
            }
            a2dpAdapter.clear();
            a2dpAdapter.addAll(labels);
            a2dpAdapter.notifyDataSetChanged();
            if (!devices.isEmpty()) selectedA2dpDevice = devices.get(0);
            log("Подключённых A2DP: " + devices.size());
        } catch (SecurityException e) {
            log("Нет BLUETOOTH_CONNECT: " + e);
        }
    }

    private void dumpSelectedA2dp() {
        if (!ensureBt()) return;
        BluetoothDevice d = selectedA2dpDevice;
        if (d == null) {
            log("Сначала выбери подключённое A2DP-устройство.");
            return;
        }
        log("\n=== A2DP DEVICE ===");
        log("Name: " + safeName(d));
        log("Address: " + d.getAddress());
        log("Bond: " + bondName(d.getBondState()));
        log("Type: " + deviceTypeName(d.getType()));
        ParcelUuid[] uuids = d.getUuids();
        if (uuids != null) {
            for (ParcelUuid u : uuids) log("SDP cached: " + u.getUuid());
        } else {
            log("SDP cached: none");
        }
        boolean started = d.fetchUuidsWithSdp();
        log("fetchUuidsWithSdp(): " + started + " (результат придёт отдельным событием)");
    }

    private void startBleScan() {
        if (!ensureBt()) return;
        if (adapter == null || !adapter.isEnabled()) {
            log("Bluetooth выключен.");
            return;
        }
        bleScanner = adapter.getBluetoothLeScanner();
        if (bleScanner == null) {
            log("BLE scanner недоступен.");
            return;
        }
        scanResults.clear();
        selectedBleDevice = null;
        String filter = nameFilter.getText().toString().trim();
        log("\n=== BLE SCAN 10s === filter='" + filter + "'");
        try {
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            bleScanner.startScan(null, settings, scanCallback);
            main.postDelayed(this::stopBleScanAndReport, 10_000);
        } catch (SecurityException e) {
            log("BLE scan denied: " + e);
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null) return;
            String key = result.getDevice().getAddress();
            ScanResult prev = scanResults.get(key);
            if (prev == null || result.getRssi() > prev.getRssi()) {
                scanResults.put(key, result);
            }
        }
        @Override public void onScanFailed(int errorCode) {
            log("BLE scan failed: " + errorCode);
        }
    };

    private void stopBleScanAndReport() {
        if (bleScanner != null && btGranted()) {
            try { bleScanner.stopScan(scanCallback); } catch (Exception ignored) { }
        }
        List<ScanResult> list = new ArrayList<>(scanResults.values());
        list.sort(Comparator.comparingInt(ScanResult::getRssi).reversed());
        String filter = nameFilter.getText().toString().trim().toLowerCase(Locale.ROOT);

        ScanResult bestFiltered = null;

        // 1) Самый надёжный вариант: BLE-адрес совпадает с уже подключённым A2DP-устройством.
        if (selectedA2dpDevice != null) {
            String a2dpAddress = selectedA2dpDevice.getAddress();
            for (ScanResult r : list) {
                if (r.getDevice() != null && a2dpAddress.equalsIgnoreCase(r.getDevice().getAddress())) {
                    bestFiltered = r;
                    break;
                }
            }
        }

        // 2) Если точного совпадения нет, разрешаем только реальное совпадение по имени/фильтру.
        // Никогда не подставляем просто самое сильное неизвестное BLE-устройство: так можно
        // случайно подключиться GATT к самому телефону, часам, ТВ и т.п.
        if (bestFiltered == null && !filter.isEmpty()) {
            for (ScanResult r : list) {
                String name = scanName(r);
                if (name.toLowerCase(Locale.ROOT).contains(filter)) {
                    bestFiltered = r;
                    break;
                }
            }
        }

        if (bestFiltered != null) selectedBleDevice = bestFiltered.getDevice();

        log("Найдено BLE устройств: " + list.size());
        int max = Math.min(30, list.size());
        for (int i = 0; i < max; i++) {
            ScanResult r = list.get(i);
            String name = scanName(r);
            log("\n#" + (i + 1) + " " + name + "  " + r.getDevice().getAddress() + "  RSSI " + r.getRssi());
            log(scanRecordText(r.getScanRecord()));
            log(fingerprint(r));
        }
        if (selectedBleDevice != null) {
            log("\nSELECTED BLE: " + safeName(selectedBleDevice) + " " + selectedBleDevice.getAddress());
            log("Для GATT будет использовано это устройство: найдено точное совпадение с A2DP или по фильтру имени.");
        } else {
            log("\nSELECTED BLE: NONE");
            log("AirPods BLE не найден именно как нужное устройство. GATT намеренно пропущен, чтобы не подключаться к чужому BLE-устройству.");
            log("Открой кейс рядом с телефоном или вынь один наушник, подожди 2–3 секунды и повтори полную диагностику.");
        }
    }

    private String scanName(ScanResult r) {
        ScanRecord sr = r.getScanRecord();
        if (sr != null && sr.getDeviceName() != null) return sr.getDeviceName();
        try {
            String n = r.getDevice().getName();
            return n != null ? n : "N/A";
        } catch (SecurityException e) {
            return "N/A";
        }
    }

    private String scanRecordText(ScanRecord sr) {
        if (sr == null) return "ScanRecord: null";
        StringBuilder sb = new StringBuilder();
        sb.append("raw=").append(hex(sr.getBytes())).append('\n');
        sb.append("flags=").append(sr.getAdvertiseFlags()).append(" tx=").append(sr.getTxPowerLevel()).append('\n');

        SparseArray<byte[]> mfg = sr.getManufacturerSpecificData();
        if (mfg == null || mfg.size() == 0) {
            sb.append("manufacturer: none\n");
        } else {
            for (int i = 0; i < mfg.size(); i++) {
                int id = mfg.keyAt(i);
                sb.append(String.format(Locale.US, "manufacturer 0x%04X = %s\n", id, hex(mfg.valueAt(i))));
            }
        }
        if (sr.getServiceUuids() != null) {
            for (ParcelUuid u : sr.getServiceUuids()) sb.append("serviceUuid=").append(u.getUuid()).append('\n');
        }
        if (sr.getServiceData() != null) {
            for (Map.Entry<ParcelUuid, byte[]> e : sr.getServiceData().entrySet()) {
                sb.append("serviceData ").append(e.getKey().getUuid()).append("=").append(hex(e.getValue())).append('\n');
            }
        }
        return sb.toString().trim();
    }

    private String fingerprint(ScanResult r) {
        ScanRecord sr = r.getScanRecord();
        if (sr == null) return "Fingerprint: недостаточно данных";
        SparseArray<byte[]> mfg = sr.getManufacturerSpecificData();
        boolean apple = mfg != null && mfg.get(0x004C) != null;
        boolean airoha = mfg != null && mfg.get(0x05D6) != null;

        StringBuilder s = new StringBuilder("Fingerprint: ");
        if (airoha) {
            s.append("Airoha/MediaTek вероятен: найден Bluetooth Company ID 0x05D6. ");
        }
        if (apple) {
            byte[] p = mfg.get(0x004C);
            s.append("Apple-format advertising 0x004C");
            if (p != null && p.length > 0 && (p[0] & 0xFF) == 0x07) {
                s.append(" / Proximity Pairing type 0x07");
            }
            s.append(". Это может быть и оригинал, и реплика; чип по этому ID не определяется. ");
        }
        if (!airoha && !apple) s.append("нет известных Apple/Airoha manufacturer IDs. ");
        return s.toString().trim();
    }

    private void connectGattSelected() {
        if (!ensureBt()) return;
        BluetoothDevice d = selectedBleDevice;
        if (d == null) {
            log("Сначала сделай BLE scan; будет автоматически выбрано самое сильное совпадение по фильтру.");
            return;
        }
        if (activeGatt != null) {
            try { activeGatt.close(); } catch (Exception ignored) { }
            activeGatt = null;
        }
        readQueue.clear();
        log("\n=== GATT CONNECT " + safeName(d) + " " + d.getAddress() + " ===");
        try {
            activeGatt = d.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        } catch (SecurityException e) {
            log("GATT denied: " + e);
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            log("GATT state: status=" + status + " newState=" + newState);
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                gatt.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                log("GATT disconnected");
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            log("GATT services discovered, status=" + status);
            if (status != BluetoothGatt.GATT_SUCCESS) return;

            readQueue.clear();
            for (BluetoothGattService s : gatt.getServices()) {
                log("SERVICE " + friendlyUuid(s.getUuid()) + "  " + s.getUuid());
                for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                    log("  CHAR " + friendlyUuid(c.getUuid()) + "  " + c.getUuid() +
                            " props=" + properties(c.getProperties()));
                    if ((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
                        readQueue.add(c);
                    }
                }
            }
            log(chipHintsFromGatt(gatt.getServices()));
            readNext(gatt);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         byte[] value,
                                         int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                log("READ " + friendlyUuid(characteristic.getUuid()) + " " + characteristic.getUuid() +
                        " = " + printableOrHex(value));
            } else {
                log("READ FAIL " + characteristic.getUuid() + " status=" + status);
            }
            readNext(gatt);
        }
    };

    private void readNext(BluetoothGatt gatt) {
        BluetoothGattCharacteristic c = readQueue.poll();
        if (c == null) {
            log("GATT read queue finished.");
            return;
        }
        boolean started;
        try {
            // Deprecated in API 33, but still present and convenient for a diagnostic app.
            started = gatt.readCharacteristic(c);
        } catch (Exception e) {
            started = false;
            log("readCharacteristic exception: " + e);
        }
        if (!started) {
            log("READ start failed: " + c.getUuid());
            main.post(() -> readNext(gatt));
        }
    }

    private String chipHintsFromGatt(List<BluetoothGattService> services) {
        boolean appleContinuity = false;
        boolean appleNearby = false;
        boolean deviceInfo = false;
        for (BluetoothGattService s : services) {
            String u = s.getUuid().toString().toLowerCase(Locale.ROOT);
            if (u.equals("d0611e78-bbb4-4591-a5f8-487910ae4366")) appleContinuity = true;
            if (u.equals("9fa480e0-4967-4542-9390-d343dc5d04ae")) appleNearby = true;
            if (u.equals("0000180a-0000-1000-8000-00805f9b34fb")) deviceInfo = true;
        }
        StringBuilder sb = new StringBuilder("GATT hints: ");
        if (appleContinuity || appleNearby) {
            sb.append("есть Apple-compatible Continuity/Nearby services; реплики могут их эмулировать. ");
        }
        if (deviceInfo) sb.append("есть Device Information — значения READ ниже могут выдать прошивку/шаблон. ");
        sb.append("Точный SoC нельзя гарантированно определить, если прошивка скрывает vendor UUID/ID.");
        return sb.toString();
    }

    private void tryHiddenCodecStatus() {
        if (!ensureBt()) return;
        if (a2dp == null || selectedA2dpDevice == null) {
            log("Сначала найди/выбери подключённое A2DP-устройство.");
            return;
        }
        log("\n=== HIDDEN/SYSTEM CodecStatus attempt ===");
        try {
            java.lang.reflect.Method m = BluetoothA2dp.class.getDeclaredMethod(
                    "getCodecStatus", BluetoothDevice.class);
            m.setAccessible(true);
            Object obj = m.invoke(a2dp, selectedA2dpDevice);
            if (obj instanceof BluetoothCodecStatus) {
                printCodecStatus((BluetoothCodecStatus) obj, "reflection");
            } else {
                log("getCodecStatus returned: " + obj);
            }
        } catch (Throwable e) {
            log("System API недоступен обычному приложению: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            log("Это нормально на Android/HyperOS. Используй кнопку Codec dump с DUMP permission или событие CODEC_CONFIG_CHANGED.");
        }
    }

    private void runCodecDump() {
        log("\n=== CODEC DUMP ===");
        if (shellService != null) {
            runShizukuCodecDump();
            return;
        }

        int dumpPerm = checkSelfPermission("android.permission.DUMP");
        log("android.permission.DUMP = " + (dumpPerm == PackageManager.PERMISSION_GRANTED ? "GRANTED" : "NOT GRANTED"));
        if (dumpPerm != PackageManager.PERMISSION_GRANTED) {
            log("DUMP не выдан обычному приложению. Пробую Shizuku.");
            if (requestOrBindShizuku()) {
                main.postDelayed(() -> {
                    if (shellService != null) runShizukuCodecDump();
                    else log("Shizuku UserService ещё не подключён. Нажми Codec dump ещё раз.");
                }, 1200);
                return;
            }
        }

        worker.execute(() -> {
            String bt = execAndFilter("dumpsys bluetooth_manager",
                    new String[]{"codec", "a2dp", "active device", "optional", "selectable", "capabil", "sample rate", "bits per sample"});
            String audio = execAndFilter("dumpsys media.audio_policy",
                    new String[]{"a2dp", "bluetooth", "codec", "sample rate", "format", "active"});
            log("--- bluetooth_manager ---\n" + bt);
            log("--- media.audio_policy ---\n" + audio);
        });
    }

    private void runShizukuCodecDump() {
        final IShellService svc = shellService;
        if (svc == null) {
            log("Shizuku shell service не подключён.");
            requestOrBindShizuku();
            return;
        }

        worker.execute(() -> {
            try {
                int uid = svc.uid();
                log("Shizuku shell UID=" + uid + (uid == 2000 ? " (shell)" : uid == 0 ? " (root)" : ""));
                String btRaw = svc.exec("dumpsys bluetooth_manager");
                String audioRaw = svc.exec("dumpsys media.audio_policy");
                String selectedAddress = selectedA2dpDevice != null ?
                        selectedA2dpDevice.getAddress().toLowerCase(Locale.ROOT) : "__none__";
                String selectedSuffix = selectedAddress.length() >= 5 ?
                        selectedAddress.substring(selectedAddress.length() - 5) : selectedAddress;
                String bt = filterText(btRaw, new String[]{
                        "A2dpStateMachine", "mActiveDevice", "mCodecConfig",
                        "mCodecsSelectableCapabilities", "Supports optional codec changed",
                        "selectable", "sample rate", "bits per sample",
                        selectedAddress, selectedSuffix
                });
                String audio = filterText(audioRaw, new String[]{
                        "a2dp", "bluetooth", "codec", "format", "sample rate", "active"
                });

                log("--- SHIZUKU bluetooth_manager ---\n" + bt);
                log("--- SHIZUKU media.audio_policy ---\n" + audio);
                log(codecSummary(btRaw));
            } catch (Throwable e) {
                log("Shizuku dump error: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        });
    }

    private String filterText(String text, String[] needles) {
        if (text == null) return "null";
        String[] lines = text.split("\\r?\\n");
        boolean[] keep = new boolean[lines.length];

        for (int i = 0; i < lines.length; i++) {
            String low = lines[i].toLowerCase(Locale.ROOT);
            boolean hit = false;
            for (String n : needles) {
                if (n != null && !n.isEmpty() && low.contains(n.toLowerCase(Locale.ROOT))) {
                    hit = true;
                    break;
                }
            }
            if (hit) {
                int from = Math.max(0, i - 1);
                int to = Math.min(lines.length - 1, i + 2);
                for (int j = from; j <= to; j++) keep[j] = true;
            }
        }

        StringBuilder out = new StringBuilder();
        int kept = 0;
        for (int i = 0; i < lines.length && kept < 500; i++) {
            if (keep[i]) {
                out.append(lines[i]).append('\\n');
                kept++;
            }
        }
        if (kept == 0) return "[no matching lines]";
        return out.toString();
    }

    private String codecSummary(String btDump) {
        if (btDump == null) return "=== CODEC SUMMARY ===\nНет bluetooth_manager dump.";
        String low = btDump.toLowerCase(Locale.ROOT);
        StringBuilder sb = new StringBuilder("\n=== CODEC SUMMARY ===\n");

        String current = "не удалось определить";
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?i)mCodecConfig:\\s*([^\\n\\r]+)")
                .matcher(btDump);
        if (m.find()) current = m.group(1).trim();
        sb.append("Current: ").append(current).append('\n');

        int optionalSupport = -1;
        String selectedSuffix = "";
        if (selectedA2dpDevice != null) {
            String addr = selectedA2dpDevice.getAddress().toLowerCase(Locale.ROOT);
            if (addr.length() >= 5) selectedSuffix = addr.substring(addr.length() - 5);
        }

        if (!selectedSuffix.isEmpty()) {
            String[] allLines = btDump.split("\\r?\\n");
            for (String line : allLines) {
                String ll = line.toLowerCase(Locale.ROOT);
                if (!ll.contains(selectedSuffix)) continue;
                if (ll.contains("supports optional codec changed:") && ll.matches(".*->\\s*0.*")) {
                    optionalSupport = 0;
                } else if (ll.contains("supports optional codec changed:") && ll.matches(".*->\\s*1.*")) {
                    optionalSupport = 1;
                }
                java.util.regex.Matcher om = java.util.regex.Pattern
                        .compile("optional codec\\(support=([-0-9]+)")
                        .matcher(ll);
                if (om.find()) {
                    try { optionalSupport = Integer.parseInt(om.group(1)); } catch (Exception ignored) { }
                }
            }
        }

        if (optionalSupport == 0) {
            sb.append("Optional codecs: NOT SUPPORTED by selected device (Android support=0).\n");
            sb.append("AAC: НЕДОСТУПЕН для этой пары — Android видит только обязательный SBC/без optional codec.\n");
        } else if (optionalSupport == 1) {
            sb.append("Optional codecs: SUPPORTED by selected device (Android support=1).\n");
        } else {
            sb.append("Optional codecs: статус не найден для выбранного устройства.\n");
        }

        int idx = low.indexOf("mcodecsselectablecapabilities");
        String selectableBlock = "";
        if (idx >= 0) {
            int end2 = Math.min(btDump.length(), idx + 2500);
            selectableBlock = btDump.substring(idx, end2);
        }
        String selLow = selectableBlock.toLowerCase(Locale.ROOT);
        boolean hasSbc = selLow.contains("sbc");
        boolean hasAac = selLow.contains("aac");
        sb.append("Selectable: ");
        if (idx < 0) {
            sb.append("блок не найден");
        } else {
            List<String> names = new ArrayList<>();
            if (hasSbc) names.add("SBC");
            if (hasAac) names.add("AAC");
            if (selLow.contains("aptx")) names.add("aptX");
            if (selLow.contains("ldac")) names.add("LDAC");
            if (selLow.contains("lc3")) names.add("LC3");
            sb.append(names.isEmpty() ? "не распознано" : names.toString());
        }
        sb.append('\n');

        if (optionalSupport != 0) {
            if (idx >= 0 && !hasAac) {
                sb.append("AAC: НЕ ОБНАРУЖЕН среди selectable capabilities. Телефон не сможет заставить эту пару использовать AAC.\n");
            } else if (hasAac) {
                sb.append("AAC: обнаружен среди selectable capabilities — можно разбираться, почему не выбирается.\n");
            } else {
                sb.append("AAC: недостаточно данных для окончательного вывода.\n");
            }
        }
        return sb.toString();
    }

    private String execAndFilter(String command, String[] needles) {
        StringBuilder out = new StringBuilder();
        try {
            Process p = new ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            int kept = 0;
            int all = 0;
            StringBuilder firstLines = new StringBuilder();
            while ((line = br.readLine()) != null) {
                all++;
                if (all <= 20) firstLines.append(line).append('\n');
                String low = line.toLowerCase(Locale.ROOT);
                boolean keep = false;
                for (String n : needles) {
                    if (low.contains(n)) { keep = true; break; }
                }
                if (keep && kept < 400) {
                    out.append(line).append('\n');
                    kept++;
                }
            }
            int code = p.waitFor();
            if (kept == 0) {
                out.append("[no matching lines; exit=").append(code).append("]\n");
                out.append(firstLines);
            }
        } catch (Exception e) {
            out.append("ERROR: ").append(e).append('\n');
        }
        return out.toString();
    }

    private final Shizuku.OnBinderReceivedListener shizukuBinderReceivedListener = () -> {
        log("Shizuku binder: подключён");
        refreshShizukuStatus();
        // If the service was started while this app was already open, continue automatically:
        // request authorization (if needed) and bind the shell UserService.
        main.postDelayed(this::requestOrBindShizuku, 150);
    };

    private final Shizuku.OnBinderDeadListener shizukuBinderDeadListener = () -> {
        shellService = null;
        shizukuBinding = false;
        log("Shizuku binder: отключён");
    };

    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener = (requestCode, grantResult) -> {
        if (requestCode != REQ_SHIZUKU) return;
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            log("Shizuku permission: GRANTED");
            bindShizukuShell();
        } else {
            log("Shizuku permission: DENIED");
        }
    };

    private final ServiceConnection shizukuServiceConnection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder service) {
            shizukuBinding = false;
            shellService = IShellService.Stub.asInterface(service);
            try {
                log("Shizuku UserService: connected, uid=" + shellService.uid());
            } catch (Exception e) {
                log("Shizuku UserService connected, uid read failed: " + e);
            }
        }

        @Override public void onServiceDisconnected(ComponentName name) {
            shellService = null;
            shizukuBinding = false;
            log("Shizuku UserService: disconnected");
        }
    };

    private boolean requestOrBindShizuku() {
        if (!Shizuku.pingBinder()) {
            log("Shizuku binder пока не получен. Если Shizuku уже пишет «запущен», закрой и снова открой это приложение; v0.5 также подключится автоматически после получения binder.");
            return false;
        }
        if (Shizuku.isPreV11()) {
            log("Shizuku API < 11 не поддерживается.");
            return false;
        }
        int perm = Shizuku.checkSelfPermission();
        if (perm != PackageManager.PERMISSION_GRANTED) {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                log("Разрешение Shizuku отклонено. Открой Shizuku → приложения → BT Chip & Codec Inspector и разреши.");
                return false;
            }
            log("Запрашиваю разрешение Shizuku...");
            Shizuku.requestPermission(REQ_SHIZUKU);
            return true;
        }
        bindShizukuShell();
        return true;
    }

    private void refreshShizukuStatus() {
        if (!Shizuku.pingBinder()) {
            log("Shizuku status: недоступен");
            return;
        }
        try {
            log("Shizuku status: API=" + Shizuku.getVersion() + " uid=" + Shizuku.getUid() +
                    " permission=" + (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ? "GRANTED" : "NOT GRANTED"));
        } catch (Throwable e) {
            log("Shizuku status error: " + e.getMessage());
        }
    }

    private void bindShizukuShell() {
        if (shellService != null || shizukuBinding) return;
        if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return;
        shizukuBinding = true;
        try {
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                    new ComponentName(getPackageName(), ShellService.class.getName()))
                    .daemon(false)
                    .processNameSuffix("bt_shell")
                    .debuggable(false)
                    .version(2);
            Shizuku.bindUserService(args, shizukuServiceConnection);
            log("Shizuku UserService: binding...");
        } catch (Throwable e) {
            shizukuBinding = false;
            log("Shizuku bind error: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    private void runFullDiagnostic() {
        if (fullDiagnosticRunning) {
            log("Полная диагностика уже выполняется.");
            return;
        }
        fullDiagnosticRunning = true;
        output.setText("");
        log("=== FULL DIAGNOSTIC v0.5 START ===");

        requestBtPermissionsIfNeeded();
        requestOrBindShizuku();

        main.postDelayed(() -> {
            loadA2dpDevices();
            if (selectedA2dpDevice != null) {
                dumpSelectedA2dp();
                tryHiddenCodecStatus();
            }
            startBleScan();
        }, 900);

        main.postDelayed(() -> {
            if (selectedBleDevice != null) connectGattSelected();
            runCodecDump();
        }, 11_500);

        main.postDelayed(() -> {
            log("=== FULL DIAGNOSTIC v0.5 FINISHED ===");
            log("Нажми «КОПИРОВАТЬ КРАТКИЙ ИТОГ» или сохрани полный отчёт в TXT.");
            fullDiagnosticRunning = false;
        }, 17_000);
    }

    private void registerReceivers() {
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_UUID);
        f.addAction(ACTION_CODEC_CONFIG_CHANGED);
        registerReceiver(systemReceiver, f, Context.RECEIVER_EXPORTED);
    }

    private final BroadcastReceiver systemReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (BluetoothDevice.ACTION_UUID.equals(intent.getAction())) {
                BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                ParcelUuid[] uuids = intent.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID, ParcelUuid.class);
                log("\n=== SDP RESULT " + (d != null ? safeName(d) : "") + " ===");
                if (uuids == null) log("No SDP UUIDs");
                else for (ParcelUuid u : uuids) log("SDP: " + u.getUuid());
            } else if (ACTION_CODEC_CONFIG_CHANGED.equals(intent.getAction())) {
                BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                BluetoothCodecStatus status = intent.getParcelableExtra(
                        BluetoothCodecStatus.EXTRA_CODEC_STATUS, BluetoothCodecStatus.class);
                log("\n=== CODEC_CONFIG_CHANGED " + (d != null ? safeName(d) : "") + " ===");
                if (status != null) printCodecStatus(status, "broadcast");
                else log("CodecStatus extra is null");
            }
        }
    };

    private void printCodecStatus(BluetoothCodecStatus s, String source) {
        log("CodecStatus source=" + source);
        BluetoothCodecConfig current = s.getCodecConfig();
        log("CURRENT: " + (current != null ? current.toString() : "null"));
        log("SELECTABLE:");
        for (BluetoothCodecConfig c : s.getCodecsSelectableCapabilities()) {
            log("  " + c);
        }
        log("LOCAL CAPABILITIES:");
        for (BluetoothCodecConfig c : s.getCodecsLocalCapabilities()) {
            log("  " + c);
        }
        log("Если AAC отсутствует в SELECTABLE, заставить эту пару работать по AAC со стороны телефона нельзя.");
    }

    private boolean ensureBt() {
        if (adapter == null) {
            log("На устройстве нет Bluetooth adapter.");
            return false;
        }
        if (!btGranted()) {
            requestBtPermissionsIfNeeded();
            return false;
        }
        return true;
    }

    private String safeName(BluetoothDevice d) {
        if (d == null) return "N/A";
        try {
            String n = d.getName();
            return n != null ? n : "N/A";
        } catch (SecurityException e) {
            return "N/A";
        }
    }

    private String bondName(int b) {
        if (b == BluetoothDevice.BOND_BONDED) return "BONDED";
        if (b == BluetoothDevice.BOND_BONDING) return "BONDING";
        return "NONE";
    }

    private String deviceTypeName(int t) {
        switch (t) {
            case BluetoothDevice.DEVICE_TYPE_CLASSIC: return "CLASSIC";
            case BluetoothDevice.DEVICE_TYPE_LE: return "LE";
            case BluetoothDevice.DEVICE_TYPE_DUAL: return "DUAL";
            default: return "UNKNOWN";
        }
    }

    private String properties(int p) {
        List<String> a = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) a.add("READ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) a.add("WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) a.add("WRITE_NR");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) a.add("NOTIFY");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) a.add("INDICATE");
        return a.toString();
    }

    private String friendlyUuid(UUID u) {
        String s = u.toString().toLowerCase(Locale.ROOT);
        if (s.equals("00001800-0000-1000-8000-00805f9b34fb")) return "Generic Access";
        if (s.equals("00001801-0000-1000-8000-00805f9b34fb")) return "Generic Attribute";
        if (s.equals("0000180a-0000-1000-8000-00805f9b34fb")) return "Device Information";
        if (s.equals("00002a29-0000-1000-8000-00805f9b34fb")) return "Manufacturer Name";
        if (s.equals("00002a24-0000-1000-8000-00805f9b34fb")) return "Model Number";
        if (s.equals("00002a25-0000-1000-8000-00805f9b34fb")) return "Serial Number";
        if (s.equals("00002a26-0000-1000-8000-00805f9b34fb")) return "Firmware Revision";
        if (s.equals("00002a27-0000-1000-8000-00805f9b34fb")) return "Hardware Revision";
        if (s.equals("d0611e78-bbb4-4591-a5f8-487910ae4366")) return "Apple Continuity Service";
        if (s.equals("9fa480e0-4967-4542-9390-d343dc5d04ae")) return "Apple Nearby Service";
        return "custom";
    }

    private String printableOrHex(byte[] b) {
        if (b == null) return "null";
        boolean printable = b.length > 0;
        for (byte x : b) {
            int v = x & 0xFF;
            if (v == 0) continue;
            if (v < 0x20 || v > 0x7E) { printable = false; break; }
        }
        if (printable) {
            String s = new String(b, StandardCharsets.UTF_8).replace("\u0000", "").trim();
            if (!s.isEmpty()) return '"' + s + '"' + "  [hex " + hex(b) + "]";
        }
        return hex(b);
    }

    private String hex(byte[] b) {
        if (b == null) return "null";
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) sb.append(String.format(Locale.US, "%02X", x & 0xFF));
        return sb.toString();
    }

    private void log(String s) {
        main.post(() -> {
            String stamp = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
            output.append("[" + stamp + "] " + s + "\n");
        });
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(systemReceiver); } catch (Exception ignored) { }
        if (adapter != null && a2dp != null) {
            try { adapter.closeProfileProxy(BluetoothProfile.A2DP, a2dp); } catch (Exception ignored) { }
        }
        if (activeGatt != null) {
            try { activeGatt.close(); } catch (Exception ignored) { }
        }
        try { Shizuku.removeBinderReceivedListener(shizukuBinderReceivedListener); } catch (Exception ignored) { }
        try { Shizuku.removeBinderDeadListener(shizukuBinderDeadListener); } catch (Exception ignored) { }
        try { Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener); } catch (Exception ignored) { }
        worker.shutdownNow();
    }
}
