package com.example.btchipcodec;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothCodecConfig;
import android.bluetooth.BluetoothCodecStatus;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.util.Base64;
import android.util.SparseArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ_BT = 1001;
    private static final int REQ_SHIZUKU = 2001;
    private static final int REQ_SAVE_REPORT = 3001;
    private static final String ACTION_CODEC_CONFIG_CHANGED =
            "android.bluetooth.a2dp.profile.action.CODEC_CONFIG_CHANGED";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private BluetoothAdapter adapter;
    private BluetoothA2dp a2dp;
    private BluetoothLeScanner bleScanner;
    private BluetoothGatt activeGatt;
    private IShellService shellService;
    private boolean shizukuBinding;
    private boolean fullDiagnosticRunning;
    private JieliEarDetectionHelper jieliEarHelper;

    private TextView output;
    private TextView jieliEarStatus;
    private Button jieliReadButton;
    private Button jieliOffButton;
    private Button jieliOnButton;
    private EditText nameFilter;
    private Spinner a2dpSpinner;
    private ArrayAdapter<String> a2dpAdapter;
    private final List<BluetoothDevice> a2dpDevices = new ArrayList<>();
    private BluetoothDevice selectedA2dpDevice;
    private BluetoothDevice selectedBleDevice;

    private final Map<String, ScanResult> scanResults = new HashMap<>();
    private final ArrayDeque<BluetoothGattCharacteristic> readQueue = new ArrayDeque<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        adapter = manager != null ? manager.getAdapter() : null;

        setContentView(buildUi());
        jieliEarHelper = new JieliEarDetectionHelper(
                this, main, this::log, this::updateJieliEarStatus);
        registerReceivers();

        Shizuku.addBinderReceivedListenerSticky(shizukuBinderReceivedListener);
        Shizuku.addBinderDeadListener(shizukuBinderDeadListener);
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener);

        requestBtPermissionsIfNeeded();
        main.postDelayed(this::refreshShizukuStatus, 500);
    }

    private View buildUi() {
        int pad = dp(14);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("BT Chip & Codec Inspector");
        title.setTextSize(23);
        title.setPadding(0, 0, 0, dp(8));
        root.addView(title);

        TextView note = new TextView(this);
        note.setText("Диагностика BLE/GATT, SDP и реального A2DP-кодека. " +
                "Программа не может добавить AAC в наушники, если сами наушники его не объявляют.");
        note.setTextSize(14);
        note.setPadding(0, 0, 0, dp(12));
        root.addView(note);

        Button full = button("ПОЛНАЯ ДИАГНОСТИКА");
        full.setTextSize(18);
        full.setMinHeight(dp(58));
        full.setOnClickListener(v -> runFullDiagnostic());
        root.addView(full);

        Button shizuku = button("SHIZUKU: ПОДКЛЮЧИТЬ / РАЗРЕШИТЬ");
        shizuku.setOnClickListener(v -> requestOrBindShizuku());
        root.addView(shizuku);

        Button permissions = button("1. Разрешения Bluetooth");
        permissions.setOnClickListener(v -> requestBtPermissionsIfNeeded());
        root.addView(permissions);

        Button refreshA2dp = button("2. Найти подключённые A2DP-наушники");
        refreshA2dp.setOnClickListener(v -> loadA2dpDevices());
        root.addView(refreshA2dp);

        a2dpSpinner = new Spinner(this);
        a2dpAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new ArrayList<>());
        a2dpSpinner.setAdapter(a2dpAdapter);
        a2dpSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < a2dpDevices.size()) {
                    BluetoothDevice newDevice = a2dpDevices.get(position);
                    if (selectedA2dpDevice == null ||
                            !selectedA2dpDevice.getAddress().equalsIgnoreCase(newDevice.getAddress())) {
                        selectedA2dpDevice = newDevice;
                        updateJieliEarStatus(
                                JieliEarDetectionHelper.UI_UNKNOWN,
                                "Состояние для выбранной пары ещё не проверялось.");
                    } else {
                        selectedA2dpDevice = newDevice;
                    }
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        root.addView(a2dpSpinner);

        Button sdp = button("Инфо + SDP выбранного A2DP");
        sdp.setOnClickListener(v -> dumpSelectedA2dp());
        root.addView(sdp);

        Button reflection = button("Попробовать получить CodecStatus системным API");
        reflection.setOnClickListener(v -> tryHiddenCodecStatus());
        root.addView(reflection);

        nameFilter = new EditText(this);
        nameFilter.setHint("Фильтр BLE-имени");
        nameFilter.setText("AirPods");
        nameFilter.setSingleLine(true);
        root.addView(nameFilter);

        Button scan = button("3. Сканировать BLE 10 секунд");
        scan.setOnClickListener(v -> startBleScan());
        root.addView(scan);

        Button gatt = button("4. GATT выбранного BLE-устройства");
        gatt.setOnClickListener(v -> connectGattSelected());
        root.addView(gatt);

        Button dump = button("5. Codec dump через Shizuku / обычный shell");
        dump.setOnClickListener(v -> runCodecDump());
        root.addView(dump);

        Button controller = button("6. LMP / производитель контроллера");
        controller.setOnClickListener(v -> runControllerProbe());
        root.addView(controller);

        TextView jieliTitle = new TextView(this);
        jieliTitle.setText("Jieli / JL_SPP — обнаружение уха");
        jieliTitle.setTextSize(16);
        jieliTitle.setPadding(0, dp(10), 0, dp(4));
        root.addView(jieliTitle);

        jieliEarStatus = new TextView(this);
        jieliEarStatus.setText("⚪ ОБНАРУЖЕНИЕ УХА: НЕ ПРОВЕРЕНО\n" +
                "Нажми «ПРОЧИТАТЬ состояние» — приложение покажет ВКЛЮЧЕНО или ВЫКЛЮЧЕНО.");
        jieliEarStatus.setTextSize(17);
        jieliEarStatus.setPadding(dp(10), dp(10), dp(10), dp(10));
        root.addView(jieliEarStatus);

        jieliReadButton = button("7. ПРОЧИТАТЬ состояние обнаружения уха");
        jieliReadButton.setOnClickListener(v -> {
            if (selectedA2dpDevice == null) {
                loadA2dpDevices();
                if (selectedA2dpDevice == null) {
                    log("Jieli: нет выбранного A2DP-устройства.");
                    updateJieliEarStatus(
                            JieliEarDetectionHelper.UI_ERROR,
                            "Нет выбранных подключённых наушников.");
                    return;
                }
            }
            jieliEarHelper.read(selectedA2dpDevice);
        });
        root.addView(jieliReadButton);

        jieliOffButton = button("ВЫКЛЮЧИТЬ обнаружение уха");
        jieliOffButton.setOnClickListener(v -> {
            if (selectedA2dpDevice == null) {
                loadA2dpDevices();
                if (selectedA2dpDevice == null) {
                    log("Jieli: нет выбранного A2DP-устройства.");
                    updateJieliEarStatus(
                            JieliEarDetectionHelper.UI_ERROR,
                            "Нет выбранных подключённых наушников.");
                    return;
                }
            }
            jieliEarHelper.disable(selectedA2dpDevice);
        });
        root.addView(jieliOffButton);

        jieliOnButton = button("ВКЛЮЧИТЬ обнаружение уха");
        jieliOnButton.setOnClickListener(v -> {
            if (selectedA2dpDevice == null) {
                loadA2dpDevices();
                if (selectedA2dpDevice == null) {
                    log("Jieli: нет выбранного A2DP-устройства.");
                    updateJieliEarStatus(
                            JieliEarDetectionHelper.UI_ERROR,
                            "Нет выбранных подключённых наушников.");
                    return;
                }
            }
            jieliEarHelper.enable(selectedA2dpDevice);
        });
        root.addView(jieliOnButton);

        Button dev = button("Открыть параметры разработчика");
        dev.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
            } catch (Exception e) {
                toast("Не удалось открыть параметры разработчика");
            }
        });
        root.addView(dev);

        Button clear = button("Очистить отчёт");
        clear.setOnClickListener(v -> output.setText(""));
        root.addView(clear);

        Button copySummary = button("КОПИРОВАТЬ КРАТКИЙ ИТОГ");
        copySummary.setOnClickListener(v -> copyShortSummary());
        root.addView(copySummary);

        Button saveFull = button("СОХРАНИТЬ ПОЛНЫЙ ОТЧЁТ .TXT");
        saveFull.setOnClickListener(v -> saveFullReport());
        root.addView(saveFull);

        Button copy = button("Копировать полный отчёт (если небольшой)");
        copy.setOnClickListener(v -> {
            String report = output.getText().toString();
            if (report.length() > 50000) {
                toast("Отчёт слишком длинный. Используй «Сохранить полный отчёт .TXT».");
                return;
            }
            android.content.ClipboardManager cm =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("BT report", report));
            toast("Полный отчёт скопирован");
        });
        root.addView(copy);

        output = new TextView(this);
        output.setTextIsSelectable(true);
        output.setTextSize(12);
        output.setTypeface(android.graphics.Typeface.MONOSPACE);
        output.setPadding(0, dp(12), 0, dp(24));
        root.addView(output, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        return scroll;
    }

    private void copyShortSummary() {
        String summary = buildShortSummary(output.getText().toString());
        android.content.ClipboardManager cm =
                (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("BT short report", summary));
        toast("Краткий итог скопирован (" + summary.length() + " символов)");
    }

    private void saveFullReport() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE,
                "BTChipCodecInspector-" +
                        new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date()) +
                        ".txt");
        startActivityForResult(i, REQ_SAVE_REPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SAVE_REPORT || resultCode != RESULT_OK ||
                data == null || data.getData() == null) {
            return;
        }
        try (OutputStream os = getContentResolver().openOutputStream(data.getData(), "w")) {
            if (os == null) throw new IllegalStateException("openOutputStream returned null");
            os.write(output.getText().toString().getBytes(StandardCharsets.UTF_8));
            os.flush();
            toast("Полный отчёт сохранён в TXT");
        } catch (Exception e) {
            toast("Ошибка сохранения: " + e.getMessage());
        }
    }

    private String buildShortSummary(String report) {
        if (report == null || report.isEmpty()) return "Отчёт пуст.";

        StringBuilder out = new StringBuilder();
        out.append("=== BT CHIP & CODEC — КРАТКИЙ ИТОГ v1.0.2 ===\n");

        String deviceName = "";
        String selectedAddress = "";
        String deviceType = "";
        if (selectedA2dpDevice != null) {
            deviceName = safeName(selectedA2dpDevice);
            selectedAddress = selectedA2dpDevice.getAddress();
            deviceType = deviceTypeName(selectedA2dpDevice.getType());
        }

        String[] lines = report.split("\\r?\\n");
        String shizuku = "";
        String optionalLine = "";
        String currentLine = "";
        String selectableLine = "";
        String aacLine = "";
        String chipLine = "";
        String controllerManufacturerLine = "";
        String controllerLmpLine = "";
        String controllerModelLine = "";
        String jieliInEarLine = "";

        for (String line : lines) {
            String trimmed = line.trim();

            if (deviceName.isEmpty() && trimmed.contains("Name:")) {
                int i = trimmed.indexOf("Name:");
                if (i >= 0) deviceName = trimmed.substring(i + 5).trim();
            }
            if (selectedAddress.isEmpty() && trimmed.contains("Address:")) {
                int i = trimmed.indexOf("Address:");
                if (i >= 0) selectedAddress = trimmed.substring(i + 8).trim();
            }
            if (deviceType.isEmpty() && trimmed.contains("Type:")) {
                int i = trimmed.indexOf("Type:");
                if (i >= 0) deviceType = trimmed.substring(i + 5).trim();
            }

            if (trimmed.contains("Shizuku shell UID=")) {
                shizuku = trimmed.substring(trimmed.indexOf("Shizuku shell UID="));
            }

            if (trimmed.contains("Chip/platform:")) {
                int i = trimmed.indexOf("Chip/platform:");
                String candidate = trimmed.substring(i).trim();
                if (chipLine.isEmpty() ||
                        candidate.contains("высокая уверенность") ||
                        candidate.contains("Airoha") ||
                        candidate.contains("Bestechnic") ||
                        candidate.contains("Jieli")) {
                    chipLine = candidate;
                }
            }
            if (trimmed.contains("Chip/platform BLE:")) {
                int i = trimmed.indexOf("Chip/platform BLE:");
                String candidate = trimmed.substring(i).trim();
                if (!candidate.contains("только Apple-format")) chipLine = candidate;
            }

            if (trimmed.startsWith("Current:")) currentLine = trimmed;
            if (trimmed.startsWith("Selectable:")) selectableLine = trimmed;
            if (trimmed.startsWith("Optional codecs:")) optionalLine = trimmed;
            if (trimmed.startsWith("AAC:")) aacLine = trimmed;

            if (trimmed.startsWith("Controller manufacturer:")) controllerManufacturerLine = trimmed;
            if (trimmed.startsWith("Controller LMP:")) controllerLmpLine = trimmed;
            if (trimmed.startsWith("Chip model hint:")) controllerModelLine = trimmed;
            if (trimmed.startsWith("Jieli in-ear:")) jieliInEarLine = trimmed;
        }

        out.append("\nУстройство: ").append(deviceName.isEmpty() ? "не определено" : deviceName).append("\n");
        if (!selectedAddress.isEmpty()) out.append("Адрес: ").append(selectedAddress).append("\n");
        if (!deviceType.isEmpty()) out.append("Тип: ").append(deviceType).append("\n");
        if (!shizuku.isEmpty()) out.append(shizuku).append("\n");

        if (!currentLine.isEmpty()) {
            out.append("Текущий кодек: ")
                    .append(shortCodecConfig(currentLine.substring("Current:".length()).trim()))
                    .append("\n");
        }
        if (!selectableLine.isEmpty()) out.append(selectableLine).append("\n");
        if (!optionalLine.isEmpty()) out.append(optionalLine).append("\n");
        if (!aacLine.isEmpty()) out.append(aacLine).append("\n");
        if (!jieliInEarLine.isEmpty()) out.append(jieliInEarLine).append("\n");

        if (!controllerManufacturerLine.isEmpty()) out.append(controllerManufacturerLine).append("\n");
        if (!controllerLmpLine.isEmpty()) out.append(controllerLmpLine).append("\n");
        if (!controllerModelLine.isEmpty()) {
            out.append(controllerModelLine).append("\n");
        } else if (!chipLine.isEmpty()) {
            out.append(chipLine).append("\n");
        } else {
            out.append("Chip/platform: точная модель SoC по доступным данным не определена.\n");
        }

        return out.toString().trim();
    }

    private String shortCodecConfig(String raw) {
        if (raw == null || raw.isEmpty()) return "не удалось определить";

        String name = null;
        String rate = null;
        String bits = null;
        String channels = null;

        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?i)codecName:([^,}]+)").matcher(raw);
        if (m.find()) name = m.group(1).trim();

        m = java.util.regex.Pattern.compile("(?i)mSampleRate:[^,(]*\\(([^)]+)\\)").matcher(raw);
        if (m.find()) rate = m.group(1).trim();

        m = java.util.regex.Pattern.compile("(?i)mBitsPerSample:[^,(]*\\(([^)]+)\\)").matcher(raw);
        if (m.find()) bits = m.group(1).trim();

        m = java.util.regex.Pattern.compile("(?i)mChannelMode:[^,(]*\\(([^)]+)\\)").matcher(raw);
        if (m.find()) channels = m.group(1).trim();

        if (name == null) return raw.length() > 180 ? raw.substring(0, 180) + "…" : raw;

        StringBuilder s = new StringBuilder(name);
        if (rate != null) s.append(", ").append(rate).append(" Hz");
        if (bits != null) s.append(", ").append(bits).append("-bit");
        if (channels != null) s.append(", ").append(channels);
        return s.toString();
    }

    private void updateJieliEarStatus(int state, String detail) {
        if (jieliEarStatus == null) return;

        String headline;
        switch (state) {
            case JieliEarDetectionHelper.UI_OFF:
                headline = "✅ ОБНАРУЖЕНИЕ УХА: ВЫКЛЮЧЕНО";
                break;
            case JieliEarDetectionHelper.UI_ON:
                headline = "⚠️ ОБНАРУЖЕНИЕ УХА: ВКЛЮЧЕНО";
                break;
            case JieliEarDetectionHelper.UI_UNSUPPORTED:
                headline = "❌ ОБНАРУЖЕНИЕ УХА: НЕ ОПРЕДЕЛЕНО";
                break;
            case JieliEarDetectionHelper.UI_BUSY:
                headline = "⏳ ОБНАРУЖЕНИЕ УХА: ПРОВЕРЯЮ...";
                break;
            case JieliEarDetectionHelper.UI_ERROR:
                headline = "❌ ОБНАРУЖЕНИЕ УХА: ОШИБКА";
                break;
            default:
                headline = "⚪ ОБНАРУЖЕНИЕ УХА: НЕ ПРОВЕРЕНО";
                break;
        }

        String extra = detail == null || detail.trim().isEmpty() ? "" : "\n" + detail.trim();

        if (state == JieliEarDetectionHelper.UI_OFF) {
            extra += "\nСейчас датчик уха отключён. Ложная автопауза из-за датчика не должна срабатывать.";
        } else if (state == JieliEarDetectionHelper.UI_ON) {
            extra += "\nСейчас датчик уха активен. Если он глючит — нажми «ВЫКЛЮЧИТЬ обнаружение уха».";
        } else if (state == JieliEarDetectionHelper.UI_UNSUPPORTED) {
            extra += "\nНастройка не была изменена.";
        }

        jieliEarStatus.setText(headline + extra);

        boolean busy = state == JieliEarDetectionHelper.UI_BUSY;
        if (jieliReadButton != null) jieliReadButton.setEnabled(!busy);
        if (jieliOffButton != null) {
            jieliOffButton.setEnabled(!busy && state != JieliEarDetectionHelper.UI_OFF);
            jieliOffButton.setText(state == JieliEarDetectionHelper.UI_OFF
                    ? "✓ УЖЕ ВЫКЛЮЧЕНО"
                    : "ВЫКЛЮЧИТЬ обнаружение уха");
        }
        if (jieliOnButton != null) {
            jieliOnButton.setEnabled(!busy && state != JieliEarDetectionHelper.UI_ON);
            jieliOnButton.setText(state == JieliEarDetectionHelper.UI_ON
                    ? "✓ УЖЕ ВКЛЮЧЕНО"
                    : "ВКЛЮЧИТЬ обнаружение уха");
        }
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void requestBtPermissionsIfNeeded() {
        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.BLUETOOTH_SCAN);
        }
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), REQ_BT);
        } else {
            log("Bluetooth permissions: OK");
            acquireA2dpProxy();
        }
    }

    private boolean btGranted() {
        return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT && btGranted()) {
            log("Bluetooth permissions: OK");
            acquireA2dpProxy();
        }
    }

    private void acquireA2dpProxy() {
        if (adapter == null || !btGranted()) return;
        adapter.getProfileProxy(this, new BluetoothProfile.ServiceListener() {
            @Override public void onServiceConnected(int profile, BluetoothProfile proxy) {
                if (profile == BluetoothProfile.A2DP) {
                    a2dp = (BluetoothA2dp) proxy;
                    log("A2DP profile proxy: connected");
                    loadA2dpDevices();
                }
            }
            @Override public void onServiceDisconnected(int profile) {
                if (profile == BluetoothProfile.A2DP) {
                    a2dp = null;
                    log("A2DP profile proxy: disconnected");
                }
            }
        }, BluetoothProfile.A2DP);
    }

    private void loadA2dpDevices() {
        if (!ensureBt()) return;
        if (a2dp == null) {
            log("A2DP proxy ещё не готов. Повтори через секунду.");
            acquireA2dpProxy();
            return;
        }
        try {
            List<BluetoothDevice> devices = a2dp.getConnectedDevices();
            a2dpDevices.clear();
            a2dpDevices.addAll(devices);

            List<String> labels = new ArrayList<>();
            for (BluetoothDevice d : devices) {
                labels.add(safeName(d) + "  " + d.getAddress());
            }

            a2dpAdapter.clear();
            a2dpAdapter.addAll(labels);
            a2dpAdapter.notifyDataSetChanged();

            BluetoothDevice playing = choosePlayingA2dp(devices);
            if (playing != null) {
                selectedA2dpDevice = playing;
                selectA2dpSpinner(playing);
                log("Активное A2DP выбрано по текущему воспроизведению: " +
                        safeName(playing) + " " + playing.getAddress());
            } else if (!devices.isEmpty()) {
                selectedA2dpDevice = devices.get(0);
                selectA2dpSpinner(selectedA2dpDevice);
                if (devices.size() > 1) {
                    log("Подключено несколько A2DP. Точный active device будет уточнён через Shizuku/dumpsys.");
                }
            }

            log("Подключённых A2DP: " + devices.size());
        } catch (SecurityException e) {
            log("Нет BLUETOOTH_CONNECT: " + e);
        }
    }

    private BluetoothDevice choosePlayingA2dp(List<BluetoothDevice> devices) {
        if (a2dp == null || devices == null || devices.isEmpty()) return null;
        try {
            java.lang.reflect.Method m = BluetoothA2dp.class
                    .getDeclaredMethod("isA2dpPlaying", BluetoothDevice.class);
            m.setAccessible(true);

            BluetoothDevice only = null;
            int count = 0;
            for (BluetoothDevice d : devices) {
                Object r = m.invoke(a2dp, d);
                if (Boolean.TRUE.equals(r)) {
                    only = d;
                    count++;
                }
            }
            return count == 1 ? only : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private void selectA2dpSpinner(BluetoothDevice d) {
        if (d == null) return;
        for (int i = 0; i < a2dpDevices.size(); i++) {
            BluetoothDevice x = a2dpDevices.get(i);
            if (x != null && d.getAddress().equalsIgnoreCase(x.getAddress())) {
                final int position = i;
                main.post(() -> a2dpSpinner.setSelection(position));
                return;
            }
        }
    }

    private BluetoothDevice syncSelectedA2dpFromDump(String btDump) {
        if (btDump == null || a2dpDevices.isEmpty()) return selectedA2dpDevice;

        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?im)^\\s*mActiveDevice:\\s*([^\\r\\n]+)")
                .matcher(btDump);
        if (!m.find()) return selectedA2dpDevice;

        String active = m.group(1);
        java.util.regex.Matcher sm = java.util.regex.Pattern
                .compile("(?i)([0-9a-f]{2}:[0-9a-f]{2})\\s*$")
                .matcher(active);
        if (!sm.find()) return selectedA2dpDevice;

        String suffix = sm.group(1).toLowerCase(Locale.ROOT);
        BluetoothDevice match = null;
        int matches = 0;

        for (BluetoothDevice d : a2dpDevices) {
            String a = d.getAddress().toLowerCase(Locale.ROOT);
            if (a.endsWith(suffix)) {
                match = d;
                matches++;
            }
        }

        if (matches == 1 && match != null) {
            boolean changed = selectedA2dpDevice == null ||
                    !match.getAddress().equalsIgnoreCase(selectedA2dpDevice.getAddress());
            selectedA2dpDevice = match;
            selectA2dpSpinner(match);
            if (changed) {
                log("Active A2DP уточнён по bluetooth_manager: " +
                        safeName(match) + " " + match.getAddress());
            }
        }

        return selectedA2dpDevice;
    }

    private void dumpSelectedA2dp() {
        if (!ensureBt()) return;
        BluetoothDevice d = selectedA2dpDevice;
        if (d == null) {
            log("Сначала выбери подключённое A2DP-устройство.");
            return;
        }
        log("\n=== A2DP DEVICE ===");
        log("Name: " + safeName(d));
        log("Address: " + d.getAddress());
        log("Bond: " + bondName(d.getBondState()));
        log("Type: " + deviceTypeName(d.getType()));
        ParcelUuid[] uuids = d.getUuids();
        if (uuids != null) {
            for (ParcelUuid u : uuids) log("SDP cached: " + u.getUuid());
            log(chipPlatformFromSdp(uuids));
        } else {
            log("SDP cached: none");
            log("Chip/platform: не определён — SDP UUID пока отсутствуют.");
        }
        boolean started = d.fetchUuidsWithSdp();
        log("fetchUuidsWithSdp(): " + started + " (результат придёт отдельным событием)");
    }

    private void startBleScan() {
        if (!ensureBt()) return;
        if (adapter == null || !adapter.isEnabled()) {
            log("Bluetooth выключен.");
            return;
        }
        bleScanner = adapter.getBluetoothLeScanner();
        if (bleScanner == null) {
            log("BLE scanner недоступен.");
            return;
        }
        scanResults.clear();
        selectedBleDevice = null;
        String filter = nameFilter.getText().toString().trim();
        log("\n=== BLE SCAN 10s === filter='" + filter + "'");
        try {
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            bleScanner.startScan(null, settings, scanCallback);
            main.postDelayed(this::stopBleScanAndReport, 10_000);
        } catch (SecurityException e) {
            log("BLE scan denied: " + e);
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null) return;
            String key = result.getDevice().getAddress();
            ScanResult prev = scanResults.get(key);
            if (prev == null || result.getRssi() > prev.getRssi()) {
                scanResults.put(key, result);
            }
        }
        @Override public void onScanFailed(int errorCode) {
            log("BLE scan failed: " + errorCode);
        }
    };

    private void stopBleScanAndReport() {
        if (bleScanner != null && btGranted()) {
            try { bleScanner.stopScan(scanCallback); } catch (Exception ignored) { }
        }
        List<ScanResult> list = new ArrayList<>(scanResults.values());
        list.sort(Comparator.comparingInt(ScanResult::getRssi).reversed());
        String filter = nameFilter.getText().toString().trim().toLowerCase(Locale.ROOT);

        ScanResult bestFiltered = null;

        // 1) Самый надёжный вариант: BLE-адрес совпадает с уже подключённым A2DP-устройством.
        if (selectedA2dpDevice != null) {
            String a2dpAddress = selectedA2dpDevice.getAddress();
            for (ScanResult r : list) {
                if (r.getDevice() != null && a2dpAddress.equalsIgnoreCase(r.getDevice().getAddress())) {
                    bestFiltered = r;
                    break;
                }
            }
        }

        // 2) Если точного совпадения нет, разрешаем только реальное совпадение по имени/фильтру.
        // Никогда не подставляем просто самое сильное неизвестное BLE-устройство: так можно
        // случайно подключиться GATT к самому телефону, часам, ТВ и т.п.
        if (bestFiltered == null && !filter.isEmpty()) {
            for (ScanResult r : list) {
                String name = scanName(r);
                if (name.toLowerCase(Locale.ROOT).contains(filter)) {
                    bestFiltered = r;
                    break;
                }
            }
        }

        if (bestFiltered != null) selectedBleDevice = bestFiltered.getDevice();

        log("Найдено BLE устройств: " + list.size());
        int max = Math.min(30, list.size());
        for (int i = 0; i < max; i++) {
            ScanResult r = list.get(i);
            String name = scanName(r);
            log("\n#" + (i + 1) + " " + name + "  " + r.getDevice().getAddress() + "  RSSI " + r.getRssi());
            log(scanRecordText(r.getScanRecord()));
            log(fingerprint(r));
        }
        if (selectedBleDevice != null) {
            log("\nSELECTED BLE: " + safeName(selectedBleDevice) + " " + selectedBleDevice.getAddress());
            log("Для GATT будет использовано это устройство: найдено точное совпадение с A2DP или по фильтру имени.");
            log(chipPlatformFromSelectedBle(bestFiltered));
        } else {
            log("\nSELECTED BLE: NONE");
            log("AirPods BLE не найден именно как нужное устройство. GATT намеренно пропущен, чтобы не подключаться к чужому BLE-устройству.");
            log("Открой кейс рядом с телефоном или вынь один наушник, подожди 2–3 секунды и повтори полную диагностику.");
        }
    }

    private String scanName(ScanResult r) {
        ScanRecord sr = r.getScanRecord();
        if (sr != null && sr.getDeviceName() != null) return sr.getDeviceName();
        try {
            String n = r.getDevice().getName();
            return n != null ? n : "N/A";
        } catch (SecurityException e) {
            return "N/A";
        }
    }

    private String scanRecordText(ScanRecord sr) {
        if (sr == null) return "ScanRecord: null";
        StringBuilder sb = new StringBuilder();
        sb.append("raw=").append(hex(sr.getBytes())).append('\n');
        sb.append("flags=").append(sr.getAdvertiseFlags()).append(" tx=").append(sr.getTxPowerLevel()).append('\n');

        SparseArray<byte[]> mfg = sr.getManufacturerSpecificData();
        if (mfg == null || mfg.size() == 0) {
            sb.append("manufacturer: none\n");
        } else {
            for (int i = 0; i < mfg.size(); i++) {
                int id = mfg.keyAt(i);
                String cn = companyName(id);
                if (cn != null) {
                    sb.append(String.format(Locale.US, "manufacturer 0x%04X (%s) = %s\n", id, cn, hex(mfg.valueAt(i))));
                } else {
                    sb.append(String.format(Locale.US, "manufacturer 0x%04X = %s\n", id, hex(mfg.valueAt(i))));
                }
            }
        }
        if (sr.getServiceUuids() != null) {
            for (ParcelUuid u : sr.getServiceUuids()) sb.append("serviceUuid=").append(u.getUuid()).append('\n');
        }
        if (sr.getServiceData() != null) {
            for (Map.Entry<ParcelUuid, byte[]> e : sr.getServiceData().entrySet()) {
                sb.append("serviceData ").append(e.getKey().getUuid()).append("=").append(hex(e.getValue())).append('\n');
            }
        }
        return sb.toString().trim();
    }

    private String fingerprint(ScanResult r) {
        ScanRecord sr = r.getScanRecord();
        if (sr == null) return "Fingerprint: недостаточно данных";
        SparseArray<byte[]> mfg = sr.getManufacturerSpecificData();

        boolean apple = mfg != null && mfg.get(0x004C) != null;
        boolean airohaOld = mfg != null && mfg.get(0x0094) != null;
        boolean airohaNew = mfg != null && mfg.get(0x07E3) != null;
        boolean bes = mfg != null && mfg.get(0x02B0) != null;
        boolean jieli = mfg != null && mfg.get(0x05D6) != null;
        boolean beken = mfg != null && mfg.get(0x05F0) != null;
        boolean xiaomi = mfg != null && mfg.get(0x038F) != null;

        StringBuilder s = new StringBuilder("Fingerprint: ");
        if (airohaOld || airohaNew) {
            s.append("advertised Company ID Airoha Technology Corp. ")
                    .append(airohaOld ? "0x0094" : "0x07E3")
                    .append("; Airoha family вероятна, но Company ID может быть подменён прошивкой. ");
        }
        if (bes) {
            s.append("advertised Company ID 0x02B0 = Bestechnic (BES); BES family вероятна, точная BES-модель не раскрыта. ");
        }
        if (jieli) {
            s.append("advertised Company ID 0x05D6 = Zhuhai Jieli; Jieli/JL family вероятна, точная JL-модель не раскрыта. ");
        }
        if (beken) {
            s.append("advertised Company ID 0x05F0 = Beken; Beken family вероятна. ");
        }
        if (xiaomi) {
            s.append("advertised Company ID 0x038F = Xiaomi Inc.; это идентификатор производителя рекламы, а не модели SoC. ");
        }
        if (apple) {
            byte[] p = mfg.get(0x004C);
            s.append("Apple-format advertising 0x004C");
            if (p != null && p.length > 0 && (p[0] & 0xFF) == 0x07) {
                s.append(" / Proximity Pairing type 0x07");
            }
            s.append(". Для реплик это может быть эмуляция и сам SoC по 0x004C не определяется. ");
        }
        if (!apple && !airohaOld && !airohaNew && !bes && !jieli && !beken && !xiaomi) {
            s.append("нет известных vendor Company ID из базы приложения. ");
        }
        return s.toString().trim();
    }

    private String companyName(int id) {
        switch (id) {
            case 0x004C: return "Apple, Inc.";
            case 0x000A: return "Qualcomm Technologies International, Ltd. (QTIL)";
            case 0x001D: return "Qualcomm";
            case 0x0094: return "Airoha Technology Corp.";
            case 0x07E3: return "Airoha Technology Corp.";
            case 0x02B0: return "Bestechnic (Shanghai), Ltd";
            case 0x05D6: return "Zhuhai Jieli technology Co.,Ltd";
            case 0x05F0: return "Beken";
            case 0x038F: return "Xiaomi Inc.";
            default: return null;
        }
    }

    private String chipPlatformFromSdp(ParcelUuid[] uuids) {
        if (uuids == null || uuids.length == 0) {
            return "Chip/platform: не определён — SDP UUID отсутствуют.";
        }

        boolean airohaRace = false;
        boolean appleAap = false;
        boolean serialPort = false;
        boolean jieliSpp = false;

        for (ParcelUuid p : uuids) {
            if (p == null || p.getUuid() == null) continue;
            String u = p.getUuid().toString().toLowerCase(Locale.ROOT);
            if (u.equals("00000000-0000-0000-0099-aabbccddeeff")) airohaRace = true;
            if (u.equals("74ec2172-0bad-4d01-8f77-997b2be0722a")) appleAap = true;
            if (u.equals("00001101-0000-1000-8000-00805f9b34fb")) serialPort = true;
            if (u.equals("fe010000-1234-5678-abcd-00805f9b34fb")) jieliSpp = true;
        }

        if (jieliSpp) {
            return "Chip/platform: Jieli/JL family — высокая вероятность: найден характерный JL_SPP UUID " +
                    "fe010000-1234-5678-abcd-00805f9b34fb. Точную AC/JL-модель этот UUID не раскрывает.";
        }

        if (airohaRace) {
            return "Chip/platform: Airoha/MediaTek RACE family — высокая уверенность: найден vendor RFCOMM UUID 00000000-0000-0000-0099-AABBCCDDEEFF. " +
                    "Точную модель AB15xx/AB156x стандартный Bluetooth API обычно не раскрывает.";
        }
        if (appleAap && serialPort) {
            return "Chip/platform: точная модель не определена. Есть Apple AAP + Serial Port; этого недостаточно для вывода Airoha/BES/Jieli.";
        }
        if (appleAap) {
            return "Chip/platform: точная модель не определена. Apple AAP UUID присутствует, но его эмулируют реплики и он не идентифицирует SoC.";
        }
        return "Chip/platform: точная модель не определена по SDP. Нужен vendor Company ID, vendor UUID или физическая маркировка SoC.";
    }

    private String chipPlatformFromSelectedBle(ScanResult r) {
        if (r == null || r.getScanRecord() == null) return "Chip/platform BLE: недостаточно данных.";
        SparseArray<byte[]> mfg = r.getScanRecord().getManufacturerSpecificData();
        if (mfg == null) return "Chip/platform BLE: vendor Company ID отсутствует.";

        if (mfg.get(0x0094) != null || mfg.get(0x07E3) != null) {
            return "Chip/platform BLE: Airoha Technology Corp. family вероятна (Company ID). Точная модель ABxxxx не раскрыта.";
        }
        if (mfg.get(0x02B0) != null) {
            return "Chip/platform BLE: Bestechnic/BES family вероятна (Company ID 0x02B0). Точная BES-модель не раскрыта.";
        }
        if (mfg.get(0x05D6) != null) {
            return "Chip/platform BLE: Zhuhai Jieli/JL family вероятна (Company ID 0x05D6). Точная JL-модель не раскрыта.";
        }
        if (mfg.get(0x05F0) != null) {
            return "Chip/platform BLE: Beken family вероятна (Company ID 0x05F0).";
        }
        if (mfg.get(0x004C) != null) {
            return "Chip/platform BLE: только Apple-format 0x004C; это может быть эмуляция и не позволяет определить SoC.";
        }
        return "Chip/platform BLE: известного vendor Company ID для SoC не найдено.";
    }

    private void connectGattSelected() {
        if (!ensureBt()) return;
        BluetoothDevice d = selectedBleDevice;
        if (d == null) {
            log("Сначала сделай BLE scan; будет автоматически выбрано самое сильное совпадение по фильтру.");
            return;
        }
        if (activeGatt != null) {
            try { activeGatt.close(); } catch (Exception ignored) { }
            activeGatt = null;
        }
        readQueue.clear();
        log("\n=== GATT CONNECT " + safeName(d) + " " + d.getAddress() + " ===");
        try {
            activeGatt = d.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        } catch (SecurityException e) {
            log("GATT denied: " + e);
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            log("GATT state: status=" + status + " newState=" + newState);
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                gatt.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                log("GATT disconnected");
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            log("GATT services discovered, status=" + status);
            if (status != BluetoothGatt.GATT_SUCCESS) return;

            readQueue.clear();
            for (BluetoothGattService s : gatt.getServices()) {
                log("SERVICE " + friendlyUuid(s.getUuid()) + "  " + s.getUuid());
                for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                    log("  CHAR " + friendlyUuid(c.getUuid()) + "  " + c.getUuid() +
                            " props=" + properties(c.getProperties()));
                    if ((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
                        readQueue.add(c);
                    }
                }
            }
            log(chipHintsFromGatt(gatt.getServices()));
            readNext(gatt);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         byte[] value,
                                         int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                log("READ " + friendlyUuid(characteristic.getUuid()) + " " + characteristic.getUuid() +
                        " = " + printableOrHex(value));
            } else {
                log("READ FAIL " + characteristic.getUuid() + " status=" + status);
            }
            readNext(gatt);
        }
    };

    private void readNext(BluetoothGatt gatt) {
        BluetoothGattCharacteristic c = readQueue.poll();
        if (c == null) {
            log("GATT read queue finished.");
            return;
        }
        boolean started;
        try {
            // Deprecated in API 33, but still present and convenient for a diagnostic app.
            started = gatt.readCharacteristic(c);
        } catch (Exception e) {
            started = false;
            log("readCharacteristic exception: " + e);
        }
        if (!started) {
            log("READ start failed: " + c.getUuid());
            main.post(() -> readNext(gatt));
        }
    }

    private String chipHintsFromGatt(List<BluetoothGattService> services) {
        boolean appleContinuity = false;
        boolean appleNearby = false;
        boolean deviceInfo = false;
        for (BluetoothGattService s : services) {
            String u = s.getUuid().toString().toLowerCase(Locale.ROOT);
            if (u.equals("d0611e78-bbb4-4591-a5f8-487910ae4366")) appleContinuity = true;
            if (u.equals("9fa480e0-4967-4542-9390-d343dc5d04ae")) appleNearby = true;
            if (u.equals("0000180a-0000-1000-8000-00805f9b34fb")) deviceInfo = true;
        }
        StringBuilder sb = new StringBuilder("GATT hints: ");
        if (appleContinuity || appleNearby) {
            sb.append("есть Apple-compatible Continuity/Nearby services; реплики могут их эмулировать. ");
        }
        if (deviceInfo) sb.append("есть Device Information — значения READ ниже могут выдать прошивку/шаблон. ");
        sb.append("Точную модель SoC приложение показывает только при сильном vendor-признаке (Company ID/RACE UUID); иначе не гадает.");
        return sb.toString();
    }

    private void tryHiddenCodecStatus() {
        if (!ensureBt()) return;
        if (a2dp == null || selectedA2dpDevice == null) {
            log("Сначала найди/выбери подключённое A2DP-устройство.");
            return;
        }
        log("\n=== HIDDEN/SYSTEM CodecStatus attempt ===");
        try {
            java.lang.reflect.Method m = BluetoothA2dp.class.getDeclaredMethod(
                    "getCodecStatus", BluetoothDevice.class);
            m.setAccessible(true);
            Object obj = m.invoke(a2dp, selectedA2dpDevice);
            if (obj instanceof BluetoothCodecStatus) {
                printCodecStatus((BluetoothCodecStatus) obj, "reflection");
            } else {
                log("getCodecStatus returned: " + obj);
            }
        } catch (Throwable e) {
            log("System API недоступен обычному приложению: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            log("Это нормально на Android/HyperOS. Используй кнопку Codec dump с DUMP permission или событие CODEC_CONFIG_CHANGED.");
        }
    }

    private void waitForShizukuThen(Runnable onReady, Runnable onTimeout) {
        waitForShizukuThen(onReady, onTimeout, 0, 12);
    }

    private void waitForShizukuThen(Runnable onReady, Runnable onTimeout, int attempt, int maxAttempts) {
        if (shellService != null) {
            onReady.run();
            return;
        }

        if (attempt == 0) {
            log("Жду Shizuku UserService до ~5 секунд...");
            requestOrBindShizuku();
        } else {
            try {
                if (Shizuku.pingBinder() &&
                        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                    bindShizukuShell();
                }
            } catch (Throwable ignored) { }
        }

        if (attempt >= maxAttempts) {
            log("Shizuku UserService не подключился за время ожидания.");
            if (onTimeout != null) onTimeout.run();
            return;
        }

        main.postDelayed(() ->
                waitForShizukuThen(onReady, onTimeout, attempt + 1, maxAttempts), 400);
    }

    private void runCodecDump() {
        log("\n=== CODEC DUMP ===");

        if (shellService != null) {
            runShizukuCodecDump();
            return;
        }

        int dumpPerm = checkSelfPermission("android.permission.DUMP");
        log("android.permission.DUMP = " +
                (dumpPerm == PackageManager.PERMISSION_GRANTED ? "GRANTED" : "NOT GRANTED"));

        if (dumpPerm == PackageManager.PERMISSION_GRANTED) {
            worker.execute(() -> {
                String btRaw = execRaw("dumpsys bluetooth_manager");
                String audioRaw = execRaw("dumpsys media.audio_policy");
                syncSelectedA2dpFromDump(btRaw);

                log("--- bluetooth_manager ---\n" +
                        filterText(btRaw, new String[]{
                                "codec", "a2dp", "active device", "mActiveDevice",
                                "optional", "selectable", "capabil", "sample rate", "bits per sample"
                        }));
                log("--- media.audio_policy ---\n" +
                        filterText(audioRaw, new String[]{
                                "a2dp", "bluetooth", "codec", "sample rate", "format", "active"
                        }));
                log(codecSummary(btRaw));
            });
            return;
        }

        log("DUMP не выдан обычному приложению. Жду Shizuku вместо запуска бесполезного обычного dumpsys.");
        waitForShizukuThen(
                this::runShizukuCodecDump,
                () -> {
                    log("CODEC/LMP: пропущено — Shizuku не подключился.");
                    log("Открой Shizuku и убедись, что статус «запущен», затем диагностику можно повторить без перезапуска этого приложения.");
                }
        );
    }

    private void runShizukuCodecDump() {
        final IShellService svc = shellService;
        if (svc == null) {
            log("Shizuku shell service не подключён.");
            requestOrBindShizuku();
            return;
        }

        worker.execute(() -> {
            try {
                int uid = svc.uid();
                log("Shizuku shell UID=" + uid + (uid == 2000 ? " (shell)" : uid == 0 ? " (root)" : ""));
                String btRaw = svc.exec("dumpsys bluetooth_manager");
                syncSelectedA2dpFromDump(btRaw);

                String audioRaw = svc.exec("dumpsys media.audio_policy");
                String remoteVersionLog = svc.exec(
                        "logcat -d -b all -v brief -t 12000 2>/dev/null " +
                        "| grep -i 'Remote version info' | tail -n 100");
                String configRaw = readSelectedBtConfig(svc);
                String snoopRaw = readHciSnoopTail(svc);

                String selectedAddress = selectedA2dpDevice != null ?
                        selectedA2dpDevice.getAddress().toLowerCase(Locale.ROOT) : "__none__";
                String selectedSuffix = selectedAddress.length() >= 5 ?
                        selectedAddress.substring(selectedAddress.length() - 5) : selectedAddress;
                String bt = filterText(btRaw, new String[]{
                        "A2dpStateMachine", "mActiveDevice", "mCodecConfig",
                        "mCodecsSelectableCapabilities", "Supports optional codec changed",
                        "selectable", "sample rate", "bits per sample",
                        "remote version info", "lmp", "subversion",
                        selectedAddress, selectedSuffix
                });
                String audio = filterText(audioRaw, new String[]{
                        "a2dp", "bluetooth", "codec", "format", "sample rate", "active"
                });

                log("--- SHIZUKU bluetooth_manager ---\n" + bt);
                log("--- SHIZUKU media.audio_policy ---\n" + audio);
                log(codecSummary(btRaw));
                log(controllerSummary(btRaw, remoteVersionLog, configRaw, snoopRaw));
            } catch (Throwable e) {
                log("Shizuku dump error: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        });
    }

    private void runControllerProbe() {
        log("\n=== CONTROLLER / LMP PROBE ===");

        if (shellService == null) {
            waitForShizukuThen(
                    this::runControllerProbe,
                    () -> log("Controller/LMP probe пропущен — Shizuku не подключился.")
            );
            return;
        }

        final IShellService svc = shellService;
        worker.execute(() -> {
            try {
                String btRaw = svc.exec("dumpsys bluetooth_manager");
                syncSelectedA2dpFromDump(btRaw);
                String remoteVersionLog = svc.exec(
                        "logcat -d -b all -v brief -t 12000 2>/dev/null " +
                        "| grep -i 'Remote version info' | tail -n 100");
                String configRaw = readSelectedBtConfig(svc);
                String snoopRaw = readHciSnoopTail(svc);
                log(controllerSummary(btRaw, remoteVersionLog, configRaw, snoopRaw));
            } catch (Throwable e) {
                log("Controller/LMP probe error: " +
                        e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        });
    }

    private String readSelectedBtConfig(IShellService svc) {
        if (svc == null || selectedA2dpDevice == null) return "";
        String addr = selectedA2dpDevice.getAddress();
        if (addr == null || addr.isEmpty()) return "";

        String safe = addr.replace("'", "").replace("\"", "");
        String cmd =
                "ADDR='" + safe + "'; " +
                "for f in " +
                "/data/misc/bluedroid/bt_config.conf " +
                "/data/misc/bluetooth/bt_config.conf " +
                "/data/misc/apexdata/com.android.btservices/bt_config.conf " +
                "/data/misc/apexdata/com.android.btservices/db/bt_config.conf; do " +
                "if [ -r \"$f\" ]; then " +
                "echo FILE:$f; grep -i -F -A 40 \"[$ADDR]\" \"$f\" | head -n 41; " +
                "fi; done";
        try {
            return svc.exec(cmd);
        } catch (Throwable e) {
            return "";
        }
    }

    private String readHciSnoopTail(IShellService svc) {
        if (svc == null) return "";

        // Shizuku runs as shell. On some Xiaomi/HyperOS builds the developer HCI
        // snoop log is mirrored to shared storage; on others it stays under /data
        // and shell cannot read it. We only read a small tail to stay under Binder limits.
        String cmd =
                "for f in " +
                "/sdcard/btsnoop_hci.log " +
                "/storage/emulated/0/btsnoop_hci.log " +
                "/sdcard/MIUI/debug_log/common/com.android.bluetooth/btsnoop_hci.log " +
                "/storage/emulated/0/MIUI/debug_log/common/com.android.bluetooth/btsnoop_hci.log " +
                "/data/misc/bluetooth/logs/btsnoop_hci.log " +
                "/data/misc/bluedroid/btsnoop_hci.log; do " +
                "if [ -r \"$f\" ]; then " +
                "echo __BTSNOOP_PATH__:$f; " +
                "tail -c 196608 \"$f\" 2>/dev/null | base64 2>/dev/null | tr -d '\\n'; " +
                "exit 0; fi; done; " +
                "echo __BTSNOOP_NONE__";

        try {
            return svc.exec(cmd);
        } catch (Throwable e) {
            return "__BTSNOOP_ERROR__:" + e.getClass().getSimpleName() + ":" + e.getMessage();
        }
    }

    private int selectedConnectionHandle(String btRaw) {
        if (selectedA2dpDevice == null || btRaw == null) return -1;
        String addr = selectedA2dpDevice.getAddress().toLowerCase(Locale.ROOT);
        if (addr.length() < 5) return -1;
        String suffix = java.util.regex.Pattern.quote(addr.substring(addr.length() - 5));

        // Current ACL entries use "remote_addr:... handle:0x....".
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?im)remote_addr:[^\\r\\n]*" + suffix +
                        "\\s+handle:0x([0-9a-f]+)")
                .matcher(btRaw);
        if (m.find()) return parseHex(m.group(1)) & 0x0FFF;

        return -1;
    }

    private ControllerInfo parseControllerFromSnoop(String raw, String btRaw) {
        ControllerInfo none = new ControllerInfo();
        if (raw == null || !raw.startsWith("__BTSNOOP_PATH__:")) return none;

        int nl = raw.indexOf('\n');
        if (nl < 0) return none;

        String path = raw.substring("__BTSNOOP_PATH__:".length(), nl).trim();
        String b64 = raw.substring(nl + 1).replaceAll("\\s+", "");
        if (b64.isEmpty()) return none;

        byte[] data;
        try {
            data = Base64.decode(b64, Base64.DEFAULT);
        } catch (Throwable e) {
            return none;
        }

        int wantedHandle = selectedConnectionHandle(btRaw);
        ControllerInfo lastMatching = new ControllerInfo();
        int validEvents = 0;
        ControllerInfo lastAny = new ControllerInfo();

        // H4 HCI Event packet:
        // 04 0C 08 status handle_lo handle_hi lmp_ver manufacturer_lo
        // manufacturer_hi subver_lo subver_hi
        for (int i = 0; i + 10 < data.length; i++) {
            if ((data[i] & 0xFF) != 0x04) continue;
            if ((data[i + 1] & 0xFF) != 0x0C) continue;
            if ((data[i + 2] & 0xFF) != 0x08) continue;

            int status = data[i + 3] & 0xFF;
            if (status != 0) continue;

            int handle = ((data[i + 5] & 0xFF) << 8) | (data[i + 4] & 0xFF);
            handle &= 0x0FFF;

            ControllerInfo c = new ControllerInfo();
            c.lmpVersion = data[i + 6] & 0xFF;
            c.manufacturer = ((data[i + 8] & 0xFF) << 8) | (data[i + 7] & 0xFF);
            c.lmpSubversion = ((data[i + 10] & 0xFF) << 8) | (data[i + 9] & 0xFF);
            c.source = "Bluetooth HCI snoop: " + path;
            c.evidence = String.format(Locale.US,
                    "handle=0x%04X, LMP=0x%02X, manufacturer=0x%04X, subversion=0x%04X",
                    handle, c.lmpVersion, c.manufacturer, c.lmpSubversion);
            c.exactAddressMatch = wantedHandle >= 0 && handle == wantedHandle;

            validEvents++;
            lastAny = c;
            if (c.exactAddressMatch) lastMatching = c;
        }

        if (lastMatching.complete()) return lastMatching;

        // If the dump did not reveal the current handle, only use the snoop result
        // when there is exactly one valid Remote Version event in the captured tail.
        if (wantedHandle < 0 && validEvents == 1 && lastAny.complete()) {
            lastAny.source += " (единственное событие в хвосте лога)";
            lastAny.exactAddressMatch = false;
            return lastAny;
        }

        return none;
    }

    private static class ControllerInfo {
        int lmpVersion = -1;
        int manufacturer = -1;
        int lmpSubversion = -1;
        String source = "";
        String evidence = "";
        boolean exactAddressMatch = false;

        boolean complete() {
            return lmpVersion >= 0 && manufacturer >= 0 && lmpSubversion >= 0;
        }
    }

    private String controllerSummary(String btRaw, String logRaw, String configRaw, String snoopRaw) {
        ControllerInfo info = parseControllerFromSnoop(snoopRaw, btRaw);
        if (!info.complete()) {
            ControllerInfo fromConfig = parseControllerFromConfig(configRaw);
            if (fromConfig.complete()) info = fromConfig;
        }
        if (!info.complete()) {
            ControllerInfo fromLog = parseControllerFromRemoteVersionLog(logRaw);
            if (fromLog.complete()) info = fromLog;
        }
        if (!info.complete()) {
            ControllerInfo fromDump = parseControllerFromRemoteVersionLog(btRaw);
            if (fromDump.complete()) info = fromDump;
        }

        StringBuilder sb = new StringBuilder("\n=== CONTROLLER / LMP ===\n");
        if (!info.complete()) {
            sb.append("Controller manufacturer: не удалось извлечь.\n");
            sb.append("Controller LMP: не удалось извлечь LMP version/subversion.\n");
            sb.append("Chip model hint: точную модель пока определить нельзя.\n");
            if (snoopRaw != null && snoopRaw.startsWith("__BTSNOOP_NONE__")) {
                sb.append("HCI snoop: читаемый btsnoop_hci.log не найден. ");
                sb.append("Включи «Bluetooth HCI snoop log» в параметрах разработчика, ");
                sb.append("перезапусти Bluetooth и переподключи проверяемые наушники.\n");
            } else if (snoopRaw != null && snoopRaw.startsWith("__BTSNOOP_PATH__:")) {
                sb.append("HCI snoop: файл найден, но событие Read Remote Version для выбранного устройства не удалось уверенно сопоставить.\n");
            }
            sb.append("Также проверены Bluetooth logcat и доступный bt_config.conf.\n");
            return sb.toString();
        }

        String company = companyName(info.manufacturer);
        if (company == null) company = "Bluetooth Company ID " + info.manufacturer;

        sb.append(String.format(Locale.US,
                "Controller manufacturer: %s (0x%04X / %d)%s\n",
                company, info.manufacturer, info.manufacturer,
                info.exactAddressMatch ? "" : " [MAC не удалось подтвердить полностью]"));

        sb.append(String.format(Locale.US,
                "Controller LMP: %s (0x%02X), subversion 0x%04X (%d)\n",
                lmpVersionName(info.lmpVersion), info.lmpVersion,
                info.lmpSubversion & 0xFFFF, info.lmpSubversion));

        sb.append("Chip model hint: ")
                .append(controllerModelHint(info.manufacturer, info.lmpSubversion))
                .append("\n");
        sb.append("Controller source: ").append(info.source).append("\n");
        if (!info.evidence.isEmpty()) {
            sb.append("Controller evidence: ").append(info.evidence).append("\n");
        }
        return sb.toString();
    }

    private ControllerInfo parseControllerFromConfig(String raw) {
        ControllerInfo out = new ControllerInfo();
        if (raw == null || raw.trim().isEmpty() || selectedA2dpDevice == null) return out;

        String address = selectedA2dpDevice.getAddress();
        if (address == null || address.isEmpty()) return out;
        if (!raw.toLowerCase(Locale.ROOT).contains(address.toLowerCase(Locale.ROOT))) return out;

        Integer manufacturer = findConfigInt(raw, "Manufacturer");
        Integer lmpVer = findConfigInt(raw, "LmpVer");
        Integer sub = findConfigInt(raw, "LmpSubVer");

        if (manufacturer != null && lmpVer != null && sub != null) {
            out.manufacturer = manufacturer;
            out.lmpVersion = lmpVer;
            out.lmpSubversion = sub;
            out.source = "bt_config.conf (точный MAC)";
            out.exactAddressMatch = true;
            out.evidence = "Manufacturer=" + manufacturer +
                    ", LmpVer=" + lmpVer + ", LmpSubVer=" + sub;
        }
        return out;
    }

    private Integer findConfigInt(String raw, String key) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?im)^\\s*" + java.util.regex.Pattern.quote(key) +
                        "\\s*=\\s*(0x[0-9a-f]+|[0-9]+)\\s*$")
                .matcher(raw);
        if (!m.find()) return null;
        return parseNumberAuto(m.group(1));
    }

    private ControllerInfo parseControllerFromRemoteVersionLog(String raw) {
        ControllerInfo best = new ControllerInfo();
        if (raw == null || raw.trim().isEmpty()) return best;

        String suffix = "";
        if (selectedA2dpDevice != null && selectedA2dpDevice.getAddress() != null) {
            String a = selectedA2dpDevice.getAddress().toLowerCase(Locale.ROOT);
            if (a.length() >= 5) suffix = a.substring(a.length() - 5);
        }

        java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                "(?i)remote version info valid:\\s*(true|false)\\s*\\[([^\\]]+)\\]\\s*:\\s*" +
                "(?:0x)?([0-9a-f]+)\\s*,\\s*(?:0x)?([0-9a-f]+)\\s*,\\s*(?:0x)?([0-9a-f]+)");
        java.util.regex.Matcher m = p.matcher(raw);

        ControllerInfo lastAny = new ControllerInfo();
        int matches = 0;
        while (m.find()) {
            if (!"true".equalsIgnoreCase(m.group(1))) continue;

            ControllerInfo candidate = new ControllerInfo();
            candidate.lmpVersion = parseHex(m.group(3));
            candidate.manufacturer = parseHex(m.group(4));
            candidate.lmpSubversion = parseHex(m.group(5));
            candidate.source = "Bluetooth stack Remote version info";
            candidate.evidence = "address=[" + m.group(2) + "], raw=" +
                    m.group(3) + "," + m.group(4) + "," + m.group(5);

            String loggedAddr = m.group(2).toLowerCase(Locale.ROOT);
            candidate.exactAddressMatch = !suffix.isEmpty() && loggedAddr.contains(suffix);

            matches++;
            lastAny = candidate;
            if (candidate.exactAddressMatch) best = candidate;
        }

        if (best.complete()) return best;

        if (matches == 1 && lastAny.complete()) {
            lastAny.exactAddressMatch = false;
            lastAny.source += " (единственная запись; MAC скрыт/не совпал)";
            return lastAny;
        }

        java.util.regex.Matcher lmp = java.util.regex.Pattern.compile(
                "(?i)LMP\\s+Version:\\s*[^\\n\\r]*?\\(0x([0-9a-f]+)\\)[^\\n\\r]*?" +
                "LMP\\s+Subversion:\\s*0x([0-9a-f]+)")
                .matcher(raw);

        if (lmp.find()) {
            int start = lmp.start();
            int end = Math.min(raw.length(), lmp.end() + 300);
            String around = raw.substring(start, end);

            java.util.regex.Matcher mf = java.util.regex.Pattern.compile(
                    "(?i)Manufacturer:\\s*.*?\\((\\d+)\\)").matcher(around);

            if (mf.find()) {
                ControllerInfo c = new ControllerInfo();
                c.lmpVersion = parseHex(lmp.group(1));
                c.lmpSubversion = parseHex(lmp.group(2));
                c.manufacturer = parseDecimal(mf.group(1));
                c.source = "Bluetooth dump LMP block";
                c.exactAddressMatch = !suffix.isEmpty() &&
                        raw.substring(Math.max(0, start - 500), Math.min(raw.length(), end + 500))
                                .toLowerCase(Locale.ROOT).contains(suffix);
                c.evidence = around.replace('\n', ' ').replace('\r', ' ').trim();
                return c;
            }
        }

        return best;
    }

    private int parseHex(String s) {
        try {
            return Integer.parseInt(s.replace("0x", "").replace("0X", "").trim(), 16);
        } catch (Exception e) {
            return -1;
        }
    }

    private int parseDecimal(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return -1;
        }
    }

    private Integer parseNumberAuto(String s) {
        try {
            String v = s.trim();
            if (v.startsWith("0x") || v.startsWith("0X")) {
                return Integer.parseInt(v.substring(2), 16);
            }
            return Integer.parseInt(v, 10);
        } catch (Exception e) {
            return null;
        }
    }

    private String lmpVersionName(int v) {
        switch (v) {
            case 0: return "Bluetooth 1.0b";
            case 1: return "Bluetooth 1.1";
            case 2: return "Bluetooth 1.2";
            case 3: return "Bluetooth 2.0 + EDR";
            case 4: return "Bluetooth 2.1 + EDR";
            case 5: return "Bluetooth 3.0 + HS";
            case 6: return "Bluetooth 4.0";
            case 7: return "Bluetooth 4.1";
            case 8: return "Bluetooth 4.2";
            case 9: return "Bluetooth 5.0";
            case 10: return "Bluetooth 5.1";
            case 11: return "Bluetooth 5.2";
            case 12: return "Bluetooth 5.3";
            case 13: return "Bluetooth 5.4";
            default: return "LMP version " + v;
        }
    }

    private String controllerModelHint(int manufacturer, int subversion) {
        String sub = String.format(Locale.US, "0x%04X", subversion & 0xFFFF);

        if (manufacturer == 0x0094 || manufacturer == 0x07E3) {
            boolean race = false;
            if (selectedA2dpDevice != null) {
                ParcelUuid[] uuids = selectedA2dpDevice.getUuids();
                if (uuids != null) {
                    for (ParcelUuid p : uuids) {
                        if (p != null && p.getUuid() != null &&
                                "00000000-0000-0000-0099-aabbccddeeff"
                                        .equalsIgnoreCase(p.getUuid().toString())) {
                            race = true;
                            break;
                        }
                    }
                }
            }
            return "Airoha/MediaTek" + (race ? " RACE" : "") +
                    " family; LMP subversion " + sub +
                    ". Точную AB15xx/AB156x-модель нельзя честно вывести только из стандартного LMP subversion.";
        }

        if (manufacturer == 0x02B0) {
            return "Bestechnic/BES family; LMP subversion " + sub +
                    ". Точная BES23xx/25xx/26xx/27xx-модель требует vendor-specific идентификатора.";
        }

        if (manufacturer == 0x05D6) {
            return "Zhuhai Jieli/JL family; LMP subversion " + sub +
                    ". Точная AC/JL-модель по одному LMP subversion не гарантируется.";
        }

        if (manufacturer == 0x05F0) {
            return "Beken family; LMP subversion " + sub +
                    ". Точная модель требует vendor-specific данных.";
        }

        if (manufacturer == 0x004C) {
            return "Устройство сообщает Apple Company ID; у реплики это может быть эмуляция. " +
                    "LMP subversion " + sub + " не считаем доказательством конкретного Apple/clone SoC.";
        }

        String company = companyName(manufacturer);
        if (company != null) {
            return company + ", LMP subversion " + sub +
                    "; точной модели в локальной базе соответствий нет.";
        }

        return "Неизвестный/не внесённый Company ID 0x" +
                String.format(Locale.US, "%04X", manufacturer) +
                ", LMP subversion " + sub + ".";
    }

    private String filterText(String text, String[] needles) {
        if (text == null) return "null";
        String[] lines = text.split("\\r?\\n");
        boolean[] keep = new boolean[lines.length];

        for (int i = 0; i < lines.length; i++) {
            String low = lines[i].toLowerCase(Locale.ROOT);
            boolean hit = false;
            for (String n : needles) {
                if (n != null && !n.isEmpty() && low.contains(n.toLowerCase(Locale.ROOT))) {
                    hit = true;
                    break;
                }
            }
            if (hit) {
                int from = Math.max(0, i - 1);
                int to = Math.min(lines.length - 1, i + 2);
                for (int j = from; j <= to; j++) keep[j] = true;
            }
        }

        StringBuilder out = new StringBuilder();
        int kept = 0;
        for (int i = 0; i < lines.length && kept < 500; i++) {
            if (keep[i]) {
                out.append(lines[i]).append('\n');
                kept++;
            }
        }
        if (kept == 0) return "[no matching lines]";
        return out.toString();
    }

    private String extractSelectedA2dpBlock(String btDump) {
        if (btDump == null) return "";

        String suffix = "";
        if (selectedA2dpDevice != null && selectedA2dpDevice.getAddress() != null) {
            String a = selectedA2dpDevice.getAddress().toLowerCase(Locale.ROOT);
            if (a.length() >= 5) suffix = a.substring(a.length() - 5);
        }

        String[] lines = btDump.split("\\r?\\n");
        int start = -1;

        // First choice: exact selected device suffix.
        if (!suffix.isEmpty()) {
            for (int i = 0; i < lines.length; i++) {
                String low = lines[i].toLowerCase(Locale.ROOT);
                if (low.contains("=== a2dpstatemachine for") && low.contains(suffix)) {
                    start = i;
                    break;
                }
            }
        }

        // Fallback: Android explicitly marks the active state machine.
        if (start < 0) {
            for (int i = 0; i < lines.length; i++) {
                String low = lines[i].toLowerCase(Locale.ROOT);
                if (low.contains("=== a2dpstatemachine for") && low.contains("(active)")) {
                    start = i;
                    break;
                }
            }
        }

        if (start < 0) return "";

        StringBuilder out = new StringBuilder();
        for (int i = start; i < lines.length; i++) {
            if (i > start && lines[i].toLowerCase(Locale.ROOT)
                    .contains("=== a2dpstatemachine for")) {
                break;
            }
            out.append(lines[i]).append('\n');
        }
        return out.toString();
    }

    private String codecSummary(String btDump) {
        if (btDump == null) return "=== CODEC SUMMARY ===\nНет bluetooth_manager dump.";

        syncSelectedA2dpFromDump(btDump);
        String block = extractSelectedA2dpBlock(btDump);
        String source = block.isEmpty() ? btDump : block;

        StringBuilder sb = new StringBuilder("\n=== CODEC SUMMARY ===\n");

        String current = "не удалось определить";
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?i)mCodecConfig:\\s*([^\\n\\r]+)")
                .matcher(source);
        if (m.find()) current = m.group(1).trim();
        sb.append("Current: ").append(current).append('\n');

        int optionalSupport = -1;
        java.util.regex.Matcher os = java.util.regex.Pattern
                .compile("(?i)getSupportsOptionalCodecs:\\s*(-?\\d+)")
                .matcher(source);
        if (os.find()) {
            try { optionalSupport = Integer.parseInt(os.group(1)); } catch (Exception ignored) { }
        }

        if (optionalSupport < 0 && selectedA2dpDevice != null) {
            String addr = selectedA2dpDevice.getAddress().toLowerCase(Locale.ROOT);
            String suffix = addr.length() >= 5 ? addr.substring(addr.length() - 5) : addr;
            for (String line : btDump.split("\\r?\\n")) {
                String ll = line.toLowerCase(Locale.ROOT);
                if (!ll.contains(suffix)) continue;

                java.util.regex.Matcher om = java.util.regex.Pattern
                        .compile("optional codec\\(support=([-0-9]+)")
                        .matcher(ll);
                if (om.find()) {
                    try { optionalSupport = Integer.parseInt(om.group(1)); } catch (Exception ignored) { }
                }

                if (ll.contains("supports optional codec changed:")) {
                    if (ll.matches(".*->\\s*0.*")) optionalSupport = 0;
                    if (ll.matches(".*->\\s*1.*")) optionalSupport = 1;
                }
            }
        }

        if (optionalSupport == 0) {
            sb.append("Optional codecs: NOT SUPPORTED by selected device (Android support=0).\n");
        } else if (optionalSupport == 1) {
            sb.append("Optional codecs: SUPPORTED by selected device (Android support=1).\n");
        } else {
            sb.append("Optional codecs: статус не найден для выбранного устройства.\n");
        }

        // Parse only the selectable-capability section of THIS device.
        String selectableSection = "";
        java.util.regex.Matcher sec = java.util.regex.Pattern
                .compile("(?is)mCodecsSelectableCapabilities:\\s*(.*?)(?:\\n\\s*StateMachine:|\\n\\s*StateMachineLog:|\\z)")
                .matcher(source);
        if (sec.find()) selectableSection = sec.group(1);

        List<String> names = new ArrayList<>();
        java.util.regex.Matcher cm = java.util.regex.Pattern
                .compile("(?i)codecName:([^,}\\]]+)")
                .matcher(selectableSection);
        while (cm.find()) {
            String n = cm.group(1).trim();
            boolean seen = false;
            for (String old : names) {
                if (old.equalsIgnoreCase(n)) {
                    seen = true;
                    break;
                }
            }
            if (!seen) names.add(n);
        }

        sb.append("Selectable: ")
                .append(names.isEmpty() ? "не удалось определить" : names.toString())
                .append('\n');

        String currentLow = current.toLowerCase(Locale.ROOT);
        boolean currentAac = currentLow.contains("codecname:aac");
        boolean currentSbc = currentLow.contains("codecname:sbc");
        boolean selectableAac = false;
        for (String n : names) {
            if ("aac".equalsIgnoreCase(n)) selectableAac = true;
        }

        if (currentAac) {
            sb.append("AAC: АКТИВЕН СЕЙЧАС — соединение реально использует AAC.\n");
        } else if (optionalSupport == 0) {
            sb.append("AAC: НЕДОСТУПЕН для этой пары — Android видит только обязательный SBC/без optional codec.\n");
        } else if (selectableAac) {
            sb.append("AAC: поддерживается и доступен, но сейчас активен другой кодек");
            if (currentSbc) sb.append(" (SBC)");
            sb.append(".\n");
        } else if (!names.isEmpty()) {
            sb.append("AAC: не найден среди selectable capabilities именно выбранного устройства.\n");
        } else {
            sb.append("AAC: недостаточно данных для окончательного вывода.\n");
        }

        return sb.toString();
    }

    private String execRaw(String command) {
        StringBuilder out = new StringBuilder();
        try {
            Process p = new ProcessBuilder("sh", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            int lines = 0;
            while ((line = br.readLine()) != null && lines < 12000) {
                out.append(line).append('\n');
                lines++;
            }
            p.waitFor();
        } catch (Exception e) {
            out.append("ERROR: ").append(e).append('\n');
        }
        return out.toString();
    }

    private String execAndFilter(String command, String[] needles) {
        StringBuilder out = new StringBuilder();
        try {
            Process p = new ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            int kept = 0;
            int all = 0;
            StringBuilder firstLines = new StringBuilder();
            while ((line = br.readLine()) != null) {
                all++;
                if (all <= 20) firstLines.append(line).append('\n');
                String low = line.toLowerCase(Locale.ROOT);
                boolean keep = false;
                for (String n : needles) {
                    if (low.contains(n)) { keep = true; break; }
                }
                if (keep && kept < 400) {
                    out.append(line).append('\n');
                    kept++;
                }
            }
            int code = p.waitFor();
            if (kept == 0) {
                out.append("[no matching lines; exit=").append(code).append("]\n");
                out.append(firstLines);
            }
        } catch (Exception e) {
            out.append("ERROR: ").append(e).append('\n');
        }
        return out.toString();
    }

    private final Shizuku.OnBinderReceivedListener shizukuBinderReceivedListener = () -> {
        log("Shizuku binder: подключён");
        refreshShizukuStatus();
        // If the service was started while this app was already open, continue automatically:
        // request authorization (if needed) and bind the shell UserService.
        main.postDelayed(this::requestOrBindShizuku, 150);
    };

    private final Shizuku.OnBinderDeadListener shizukuBinderDeadListener = () -> {
        shellService = null;
        shizukuBinding = false;
        log("Shizuku binder: отключён");
    };

    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener = (requestCode, grantResult) -> {
        if (requestCode != REQ_SHIZUKU) return;
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            log("Shizuku permission: GRANTED");
            bindShizukuShell();
        } else {
            log("Shizuku permission: DENIED");
        }
    };

    private final ServiceConnection shizukuServiceConnection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder service) {
            shizukuBinding = false;
            shellService = IShellService.Stub.asInterface(service);
            try {
                log("Shizuku UserService: connected, uid=" + shellService.uid());
            } catch (Exception e) {
                log("Shizuku UserService connected, uid read failed: " + e);
            }
        }

        @Override public void onServiceDisconnected(ComponentName name) {
            shellService = null;
            shizukuBinding = false;
            log("Shizuku UserService: disconnected");
        }
    };

    private boolean requestOrBindShizuku() {
        if (!Shizuku.pingBinder()) {
            log("Shizuku binder ещё не доступен. Приложение подождёт и повторит подключение автоматически.");
            return false;
        }
        if (Shizuku.isPreV11()) {
            log("Shizuku API < 11 не поддерживается.");
            return false;
        }
        int perm = Shizuku.checkSelfPermission();
        if (perm != PackageManager.PERMISSION_GRANTED) {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                log("Разрешение Shizuku отклонено. Открой Shizuku → приложения → BT Chip & Codec Inspector и разреши.");
                return false;
            }
            log("Запрашиваю разрешение Shizuku...");
            Shizuku.requestPermission(REQ_SHIZUKU);
            return true;
        }
        bindShizukuShell();
        return true;
    }

    private void refreshShizukuStatus() {
        if (!Shizuku.pingBinder()) {
            log("Shizuku status: недоступен");
            return;
        }
        try {
            log("Shizuku status: API=" + Shizuku.getVersion() + " uid=" + Shizuku.getUid() +
                    " permission=" + (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ? "GRANTED" : "NOT GRANTED"));
        } catch (Throwable e) {
            log("Shizuku status error: " + e.getMessage());
        }
    }

    private void bindShizukuShell() {
        if (shellService != null || shizukuBinding) return;
        if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return;
        shizukuBinding = true;
        try {
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                    new ComponentName(getPackageName(), ShellService.class.getName()))
                    .daemon(false)
                    .processNameSuffix("bt_shell")
                    .debuggable(false)
                    .version(2);
            Shizuku.bindUserService(args, shizukuServiceConnection);
            log("Shizuku UserService: binding...");
        } catch (Throwable e) {
            shizukuBinding = false;
            log("Shizuku bind error: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    private void runFullDiagnostic() {
        if (fullDiagnosticRunning) {
            log("Полная диагностика уже выполняется.");
            return;
        }
        fullDiagnosticRunning = true;
        output.setText("");
        log("=== FULL DIAGNOSTIC v1.0.2 START ===");

        requestBtPermissionsIfNeeded();
        requestOrBindShizuku();

        main.postDelayed(() -> {
            loadA2dpDevices();
            if (selectedA2dpDevice != null) {
                dumpSelectedA2dp();
                tryHiddenCodecStatus();
            }
            startBleScan();
        }, 900);

        main.postDelayed(() -> {
            if (selectedBleDevice != null) connectGattSelected();
            runCodecDump();
        }, 11_500);

        main.postDelayed(() -> {
            log("=== FULL DIAGNOSTIC v1.0.2 FINISHED ===");
            log("Нажми «КОПИРОВАТЬ КРАТКИЙ ИТОГ» или сохрани полный отчёт в TXT.");
            fullDiagnosticRunning = false;
        }, 21_000);
    }

    private void registerReceivers() {
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_UUID);
        f.addAction(ACTION_CODEC_CONFIG_CHANGED);
        registerReceiver(systemReceiver, f, Context.RECEIVER_EXPORTED);
    }

    private final BroadcastReceiver systemReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (BluetoothDevice.ACTION_UUID.equals(intent.getAction())) {
                BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                ParcelUuid[] uuids = intent.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID, ParcelUuid.class);
                log("\n=== SDP RESULT " + (d != null ? safeName(d) : "") + " ===");
                if (uuids == null) {
                    log("No SDP UUIDs");
                } else {
                    for (ParcelUuid u : uuids) log("SDP: " + u.getUuid());
                    log(chipPlatformFromSdp(uuids));
                }
            } else if (ACTION_CODEC_CONFIG_CHANGED.equals(intent.getAction())) {
                BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                BluetoothCodecStatus status = intent.getParcelableExtra(
                        BluetoothCodecStatus.EXTRA_CODEC_STATUS, BluetoothCodecStatus.class);
                log("\n=== CODEC_CONFIG_CHANGED " + (d != null ? safeName(d) : "") + " ===");
                if (status != null) printCodecStatus(status, "broadcast");
                else log("CodecStatus extra is null");
            }
        }
    };

    private void printCodecStatus(BluetoothCodecStatus s, String source) {
        log("CodecStatus source=" + source);
        BluetoothCodecConfig current = s.getCodecConfig();
        log("CURRENT: " + (current != null ? current.toString() : "null"));
        log("SELECTABLE:");
        for (BluetoothCodecConfig c : s.getCodecsSelectableCapabilities()) {
            log("  " + c);
        }
        log("LOCAL CAPABILITIES:");
        for (BluetoothCodecConfig c : s.getCodecsLocalCapabilities()) {
            log("  " + c);
        }
        log("Если AAC отсутствует в SELECTABLE, заставить эту пару работать по AAC со стороны телефона нельзя.");
    }

    private boolean ensureBt() {
        if (adapter == null) {
            log("На устройстве нет Bluetooth adapter.");
            return false;
        }
        if (!btGranted()) {
            requestBtPermissionsIfNeeded();
            return false;
        }
        return true;
    }

    private String safeName(BluetoothDevice d) {
        if (d == null) return "N/A";
        try {
            String n = d.getName();
            return n != null ? n : "N/A";
        } catch (SecurityException e) {
            return "N/A";
        }
    }

    private String bondName(int b) {
        if (b == BluetoothDevice.BOND_BONDED) return "BONDED";
        if (b == BluetoothDevice.BOND_BONDING) return "BONDING";
        return "NONE";
    }

    private String deviceTypeName(int t) {
        switch (t) {
            case BluetoothDevice.DEVICE_TYPE_CLASSIC: return "CLASSIC";
            case BluetoothDevice.DEVICE_TYPE_LE: return "LE";
            case BluetoothDevice.DEVICE_TYPE_DUAL: return "DUAL";
            default: return "UNKNOWN";
        }
    }

    private String properties(int p) {
        List<String> a = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) a.add("READ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) a.add("WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) a.add("WRITE_NR");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) a.add("NOTIFY");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) a.add("INDICATE");
        return a.toString();
    }

    private String friendlyUuid(UUID u) {
        String s = u.toString().toLowerCase(Locale.ROOT);
        if (s.equals("00001800-0000-1000-8000-00805f9b34fb")) return "Generic Access";
        if (s.equals("00001801-0000-1000-8000-00805f9b34fb")) return "Generic Attribute";
        if (s.equals("0000180a-0000-1000-8000-00805f9b34fb")) return "Device Information";
        if (s.equals("00002a29-0000-1000-8000-00805f9b34fb")) return "Manufacturer Name";
        if (s.equals("00002a24-0000-1000-8000-00805f9b34fb")) return "Model Number";
        if (s.equals("00002a25-0000-1000-8000-00805f9b34fb")) return "Serial Number";
        if (s.equals("00002a26-0000-1000-8000-00805f9b34fb")) return "Firmware Revision";
        if (s.equals("00002a27-0000-1000-8000-00805f9b34fb")) return "Hardware Revision";
        if (s.equals("d0611e78-bbb4-4591-a5f8-487910ae4366")) return "Apple Continuity Service";
        if (s.equals("9fa480e0-4967-4542-9390-d343dc5d04ae")) return "Apple Nearby Service";
        return "custom";
    }

    private String printableOrHex(byte[] b) {
        if (b == null) return "null";
        boolean printable = b.length > 0;
        for (byte x : b) {
            int v = x & 0xFF;
            if (v == 0) continue;
            if (v < 0x20 || v > 0x7E) { printable = false; break; }
        }
        if (printable) {
            String s = new String(b, StandardCharsets.UTF_8).replace("\u0000", "").trim();
            if (!s.isEmpty()) return '"' + s + '"' + "  [hex " + hex(b) + "]";
        }
        return hex(b);
    }

    private String hex(byte[] b) {
        if (b == null) return "null";
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) sb.append(String.format(Locale.US, "%02X", x & 0xFF));
        return sb.toString();
    }

    private void log(String s) {
        main.post(() -> {
            String stamp = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
            output.append("[" + stamp + "] " + s + "\n");
        });
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        if (jieliEarHelper != null) jieliEarHelper.destroy();
        super.onDestroy();
        try { unregisterReceiver(systemReceiver); } catch (Exception ignored) { }
        if (adapter != null && a2dp != null) {
            try { adapter.closeProfileProxy(BluetoothProfile.A2DP, a2dp); } catch (Exception ignored) { }
        }
        if (activeGatt != null) {
            try { activeGatt.close(); } catch (Exception ignored) { }
        }
        try { Shizuku.removeBinderReceivedListener(shizukuBinderReceivedListener); } catch (Exception ignored) { }
        try { Shizuku.removeBinderDeadListener(shizukuBinderDeadListener); } catch (Exception ignored) { }
        try { Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener); } catch (Exception ignored) { }
        worker.shutdownNow();
    }
}
