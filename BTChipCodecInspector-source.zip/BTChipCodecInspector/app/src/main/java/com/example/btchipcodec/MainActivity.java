package com.example.btchipcodec;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothCodecConfig;
import android.bluetooth.BluetoothCodecStatus;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.util.SparseArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int REQ_BT = 1001;
    private static final String ACTION_CODEC_CONFIG_CHANGED =
            "android.bluetooth.a2dp.profile.action.CODEC_CONFIG_CHANGED";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private BluetoothAdapter adapter;
    private BluetoothA2dp a2dp;
    private BluetoothLeScanner bleScanner;
    private BluetoothGatt activeGatt;

    private TextView output;
    private EditText nameFilter;
    private Spinner a2dpSpinner;
    private ArrayAdapter<String> a2dpAdapter;
    private final List<BluetoothDevice> a2dpDevices = new ArrayList<>();
    private BluetoothDevice selectedA2dpDevice;
    private BluetoothDevice selectedBleDevice;

    private final Map<String, ScanResult> scanResults = new HashMap<>();
    private final ArrayDeque<BluetoothGattCharacteristic> readQueue = new ArrayDeque<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        adapter = manager != null ? manager.getAdapter() : null;

        setContentView(buildUi());
        registerReceivers();
        requestBtPermissionsIfNeeded();
    }

    private View buildUi() {
        int pad = dp(14);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("BT Chip & Codec Inspector");
        title.setTextSize(23);
        title.setPadding(0, 0, 0, dp(8));
        root.addView(title);

        TextView note = new TextView(this);
        note.setText("Диагностика BLE/GATT, SDP и реального A2DP-кодека. " +
                "Программа не может добавить AAC в наушники, если сами наушники его не объявляют.");
        note.setTextSize(14);
        note.setPadding(0, 0, 0, dp(12));
        root.addView(note);

        Button permissions = button("1. Разрешения Bluetooth");
        permissions.setOnClickListener(v -> requestBtPermissionsIfNeeded());
        root.addView(permissions);

        Button refreshA2dp = button("2. Найти подключённые A2DP-наушники");
        refreshA2dp.setOnClickListener(v -> loadA2dpDevices());
        root.addView(refreshA2dp);

        a2dpSpinner = new Spinner(this);
        a2dpAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new ArrayList<>());
        a2dpSpinner.setAdapter(a2dpAdapter);
        a2dpSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < a2dpDevices.size()) {
                    selectedA2dpDevice = a2dpDevices.get(position);
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        root.addView(a2dpSpinner);

        Button sdp = button("Инфо + SDP выбранного A2DP");
        sdp.setOnClickListener(v -> dumpSelectedA2dp());
        root.addView(sdp);

        Button reflection = button("Попробовать получить CodecStatus системным API");
        reflection.setOnClickListener(v -> tryHiddenCodecStatus());
        root.addView(reflection);

        nameFilter = new EditText(this);
        nameFilter.setHint("Фильтр BLE-имени");
        nameFilter.setText("AirPods");
        nameFilter.setSingleLine(true);
        root.addView(nameFilter);

        Button scan = button("3. Сканировать BLE 10 секунд");
        scan.setOnClickListener(v -> startBleScan());
        root.addView(scan);

        Button gatt = button("4. GATT выбранного BLE-устройства");
        gatt.setOnClickListener(v -> connectGattSelected());
        root.addView(gatt);

        Button dump = button("5. Codec dump (нужен DUMP через ADB/Shizuku)");
        dump.setOnClickListener(v -> runCodecDump());
        root.addView(dump);

        Button dev = button("Открыть параметры разработчика");
        dev.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
            } catch (Exception e) {
                toast("Не удалось открыть параметры разработчика");
            }
        });
        root.addView(dev);

        Button clear = button("Очистить отчёт");
        clear.setOnClickListener(v -> output.setText(""));
        root.addView(clear);

        Button copy = button("Копировать отчёт");
        copy.setOnClickListener(v -> {
            android.content.ClipboardManager cm =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("BT report", output.getText()));
            toast("Отчёт скопирован");
        });
        root.addView(copy);

        output = new TextView(this);
        output.setTextIsSelectable(true);
        output.setTextSize(12);
        output.setTypeface(android.graphics.Typeface.MONOSPACE);
        output.setPadding(0, dp(12), 0, dp(24));
        root.addView(output, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        return scroll;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void requestBtPermissionsIfNeeded() {
        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.BLUETOOTH_SCAN);
        }
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), REQ_BT);
        } else {
            log("Bluetooth permissions: OK");
            acquireA2dpProxy();
        }
    }

    private boolean btGranted() {
        return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT && btGranted()) {
            log("Bluetooth permissions: OK");
            acquireA2dpProxy();
        }
    }

    private void acquireA2dpProxy() {
        if (adapter == null || !btGranted()) return;
        adapter.getProfileProxy(this, new BluetoothProfile.ServiceListener() {
            @Override public void onServiceConnected(int profile, BluetoothProfile proxy) {
                if (profile == BluetoothProfile.A2DP) {
                    a2dp = (BluetoothA2dp) proxy;
                    log("A2DP profile proxy: connected");
                    loadA2dpDevices();
                }
            }
            @Override public void onServiceDisconnected(int profile) {
                if (profile == BluetoothProfile.A2DP) {
                    a2dp = null;
                    log("A2DP profile proxy: disconnected");
                }
            }
        }, BluetoothProfile.A2DP);
    }

    private void loadA2dpDevices() {
        if (!ensureBt()) return;
        if (a2dp == null) {
            log("A2DP proxy ещё не готов. Повтори через секунду.");
            acquireA2dpProxy();
            return;
        }
        try {
            List<BluetoothDevice> devices = a2dp.getConnectedDevices();
            a2dpDevices.clear();
            a2dpDevices.addAll(devices);
            List<String> labels = new ArrayList<>();
            for (BluetoothDevice d : devices) {
                labels.add(safeName(d) + "  " + d.getAddress());
            }
            a2dpAdapter.clear();
            a2dpAdapter.addAll(labels);
            a2dpAdapter.notifyDataSetChanged();
            if (!devices.isEmpty()) selectedA2dpDevice = devices.get(0);
            log("Подключённых A2DP: " + devices.size());
        } catch (SecurityException e) {
            log("Нет BLUETOOTH_CONNECT: " + e);
        }
    }

    private void dumpSelectedA2dp() {
        if (!ensureBt()) return;
        BluetoothDevice d = selectedA2dpDevice;
        if (d == null) {
            log("Сначала выбери подключённое A2DP-устройство.");
            return;
        }
        log("\n=== A2DP DEVICE ===");
        log("Name: " + safeName(d));
        log("Address: " + d.getAddress());
        log("Bond: " + bondName(d.getBondState()));
        log("Type: " + deviceTypeName(d.getType()));
        ParcelUuid[] uuids = d.getUuids();
        if (uuids != null) {
            for (ParcelUuid u : uuids) log("SDP cached: " + u.getUuid());
        } else {
            log("SDP cached: none");
        }
        boolean started = d.fetchUuidsWithSdp();
        log("fetchUuidsWithSdp(): " + started + " (результат придёт отдельным событием)");
    }

    private void startBleScan() {
        if (!ensureBt()) return;
        if (adapter == null || !adapter.isEnabled()) {
            log("Bluetooth выключен.");
            return;
        }
        bleScanner = adapter.getBluetoothLeScanner();
        if (bleScanner == null) {
            log("BLE scanner недоступен.");
            return;
        }
        scanResults.clear();
        selectedBleDevice = null;
        String filter = nameFilter.getText().toString().trim();
        log("\n=== BLE SCAN 10s === filter='" + filter + "'");
        try {
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            bleScanner.startScan(null, settings, scanCallback);
            main.postDelayed(this::stopBleScanAndReport, 10_000);
        } catch (SecurityException e) {
            log("BLE scan denied: " + e);
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null) return;
            String key = result.getDevice().getAddress();
            ScanResult prev = scanResults.get(key);
            if (prev == null || result.getRssi() > prev.getRssi()) {
                scanResults.put(key, result);
            }
        }
        @Override public void onScanFailed(int errorCode) {
            log("BLE scan failed: " + errorCode);
        }
    };

    private void stopBleScanAndReport() {
        if (bleScanner != null && btGranted()) {
            try { bleScanner.stopScan(scanCallback); } catch (Exception ignored) { }
        }
        List<ScanResult> list = new ArrayList<>(scanResults.values());
        list.sort(Comparator.comparingInt(ScanResult::getRssi).reversed());
        String filter = nameFilter.getText().toString().trim().toLowerCase(Locale.ROOT);

        ScanResult bestFiltered = null;
        for (ScanResult r : list) {
            String name = scanName(r);
            if (bestFiltered == null && (filter.isEmpty() || name.toLowerCase(Locale.ROOT).contains(filter))) {
                bestFiltered = r;
            }
        }
        if (bestFiltered == null && !list.isEmpty()) bestFiltered = list.get(0);
        if (bestFiltered != null) selectedBleDevice = bestFiltered.getDevice();

        log("Найдено BLE устройств: " + list.size());
        int max = Math.min(30, list.size());
        for (int i = 0; i < max; i++) {
            ScanResult r = list.get(i);
            String name = scanName(r);
            log("\n#" + (i + 1) + " " + name + "  " + r.getDevice().getAddress() + "  RSSI " + r.getRssi());
            log(scanRecordText(r.getScanRecord()));
            log(fingerprint(r));
        }
        if (selectedBleDevice != null) {
            log("\nSELECTED BLE: " + safeName(selectedBleDevice) + " " + selectedBleDevice.getAddress());
            log("Для GATT будет использовано это устройство. Если выбрано не то — сузь фильтр имени и повтори скан.");
        }
    }

    private String scanName(ScanResult r) {
        ScanRecord sr = r.getScanRecord();
        if (sr != null && sr.getDeviceName() != null) return sr.getDeviceName();
        try {
            String n = r.getDevice().getName();
            return n != null ? n : "N/A";
        } catch (SecurityException e) {
            return "N/A";
        }
    }

    private String scanRecordText(ScanRecord sr) {
        if (sr == null) return "ScanRecord: null";
        StringBuilder sb = new StringBuilder();
        sb.append("raw=").append(hex(sr.getBytes())).append('\n');
        sb.append("flags=").append(sr.getAdvertiseFlags()).append(" tx=").append(sr.getTxPowerLevel()).append('\n');

        SparseArray<byte[]> mfg = sr.getManufacturerSpecificData();
        if (mfg == null || mfg.size() == 0) {
            sb.append("manufacturer: none\n");
        } else {
            for (int i = 0; i < mfg.size(); i++) {
                int id = mfg.keyAt(i);
                sb.append(String.format(Locale.US, "manufacturer 0x%04X = %s\n", id, hex(mfg.valueAt(i))));
            }
        }
        if (sr.getServiceUuids() != null) {
            for (ParcelUuid u : sr.getServiceUuids()) sb.append("serviceUuid=").append(u.getUuid()).append('\n');
        }
        if (sr.getServiceData() != null) {
            for (Map.Entry<ParcelUuid, byte[]> e : sr.getServiceData().entrySet()) {
                sb.append("serviceData ").append(e.getKey().getUuid()).append("=").append(hex(e.getValue())).append('\n');
            }
        }
        return sb.toString().trim();
    }

    private String fingerprint(ScanResult r) {
        ScanRecord sr = r.getScanRecord();
        if (sr == null) return "Fingerprint: недостаточно данных";
        SparseArray<byte[]> mfg = sr.getManufacturerSpecificData();
        boolean apple = mfg != null && mfg.get(0x004C) != null;
        boolean airoha = mfg != null && mfg.get(0x05D6) != null;

        StringBuilder s = new StringBuilder("Fingerprint: ");
        if (airoha) {
            s.append("Airoha/MediaTek вероятен: найден Bluetooth Company ID 0x05D6. ");
        }
        if (apple) {
            byte[] p = mfg.get(0x004C);
            s.append("Apple-format advertising 0x004C");
            if (p != null && p.length > 0 && (p[0] & 0xFF) == 0x07) {
                s.append(" / Proximity Pairing type 0x07");
            }
            s.append(". Это может быть и оригинал, и реплика; чип по этому ID не определяется. ");
        }
        if (!airoha && !apple) s.append("нет известных Apple/Airoha manufacturer IDs. ");
        return s.toString().trim();
    }

    private void connectGattSelected() {
        if (!ensureBt()) return;
        BluetoothDevice d = selectedBleDevice;
        if (d == null) {
            log("Сначала сделай BLE scan; будет автоматически выбрано самое сильное совпадение по фильтру.");
            return;
        }
        if (activeGatt != null) {
            try { activeGatt.close(); } catch (Exception ignored) { }
            activeGatt = null;
        }
        readQueue.clear();
        log("\n=== GATT CONNECT " + safeName(d) + " " + d.getAddress() + " ===");
        try {
            activeGatt = d.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        } catch (SecurityException e) {
            log("GATT denied: " + e);
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            log("GATT state: status=" + status + " newState=" + newState);
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                gatt.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                log("GATT disconnected");
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            log("GATT services discovered, status=" + status);
            if (status != BluetoothGatt.GATT_SUCCESS) return;

            readQueue.clear();
            for (BluetoothGattService s : gatt.getServices()) {
                log("SERVICE " + friendlyUuid(s.getUuid()) + "  " + s.getUuid());
                for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                    log("  CHAR " + friendlyUuid(c.getUuid()) + "  " + c.getUuid() +
                            " props=" + properties(c.getProperties()));
                    if ((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
                        readQueue.add(c);
                    }
                }
            }
            log(chipHintsFromGatt(gatt.getServices()));
            readNext(gatt);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         byte[] value,
                                         int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                log("READ " + friendlyUuid(characteristic.getUuid()) + " " + characteristic.getUuid() +
                        " = " + printableOrHex(value));
            } else {
                log("READ FAIL " + characteristic.getUuid() + " status=" + status);
            }
            readNext(gatt);
        }
    };

    private void readNext(BluetoothGatt gatt) {
        BluetoothGattCharacteristic c = readQueue.poll();
        if (c == null) {
            log("GATT read queue finished.");
            return;
        }
        boolean started;
        try {
            // Deprecated in API 33, but still present and convenient for a diagnostic app.
            started = gatt.readCharacteristic(c);
        } catch (Exception e) {
            started = false;
            log("readCharacteristic exception: " + e);
        }
        if (!started) {
            log("READ start failed: " + c.getUuid());
            main.post(() -> readNext(gatt));
        }
    }

    private String chipHintsFromGatt(List<BluetoothGattService> services) {
        boolean appleContinuity = false;
        boolean appleNearby = false;
        boolean deviceInfo = false;
        for (BluetoothGattService s : services) {
            String u = s.getUuid().toString().toLowerCase(Locale.ROOT);
            if (u.equals("d0611e78-bbb4-4591-a5f8-487910ae4366")) appleContinuity = true;
            if (u.equals("9fa480e0-4967-4542-9390-d343dc5d04ae")) appleNearby = true;
            if (u.equals("0000180a-0000-1000-8000-00805f9b34fb")) deviceInfo = true;
        }
        StringBuilder sb = new StringBuilder("GATT hints: ");
        if (appleContinuity || appleNearby) {
            sb.append("есть Apple-compatible Continuity/Nearby services; реплики могут их эмулировать. ");
        }
        if (deviceInfo) sb.append("есть Device Information — значения READ ниже могут выдать прошивку/шаблон. ");
        sb.append("Точный SoC нельзя гарантированно определить, если прошивка скрывает vendor UUID/ID.");
        return sb.toString();
    }

    private void tryHiddenCodecStatus() {
        if (!ensureBt()) return;
        if (a2dp == null || selectedA2dpDevice == null) {
            log("Сначала найди/выбери подключённое A2DP-устройство.");
            return;
        }
        log("\n=== HIDDEN/SYSTEM CodecStatus attempt ===");
        try {
            java.lang.reflect.Method m = BluetoothA2dp.class.getDeclaredMethod(
                    "getCodecStatus", BluetoothDevice.class);
            m.setAccessible(true);
            Object obj = m.invoke(a2dp, selectedA2dpDevice);
            if (obj instanceof BluetoothCodecStatus) {
                printCodecStatus((BluetoothCodecStatus) obj, "reflection");
            } else {
                log("getCodecStatus returned: " + obj);
            }
        } catch (Throwable e) {
            log("System API недоступен обычному приложению: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            log("Это нормально на Android/HyperOS. Используй кнопку Codec dump с DUMP permission или событие CODEC_CONFIG_CHANGED.");
        }
    }

    private void runCodecDump() {
        log("\n=== CODEC DUMP ===");
        int dumpPerm = checkSelfPermission("android.permission.DUMP");
        log("android.permission.DUMP = " + (dumpPerm == PackageManager.PERMISSION_GRANTED ? "GRANTED" : "NOT GRANTED"));
        if (dumpPerm != PackageManager.PERMISSION_GRANTED) {
            log("Для расширенного dump один раз выполни через ADB/Shizuku:");
            log("pm grant " + getPackageName() + " android.permission.DUMP");
            log("Опционально для системного logcat:");
            log("pm grant " + getPackageName() + " android.permission.READ_LOGS");
        }

        worker.execute(() -> {
            String bt = execAndFilter("dumpsys bluetooth_manager",
                    new String[]{"codec", "a2dp", "active device", "optional", "selectable", "capabil", "sample rate", "bits per sample"});
            String audio = execAndFilter("dumpsys media.audio_policy",
                    new String[]{"a2dp", "bluetooth", "codec", "sample rate", "format", "active"});
            log("--- bluetooth_manager ---\n" + bt);
            log("--- media.audio_policy ---\n" + audio);
        });
    }

    private String execAndFilter(String command, String[] needles) {
        StringBuilder out = new StringBuilder();
        try {
            Process p = new ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            int kept = 0;
            int all = 0;
            StringBuilder firstLines = new StringBuilder();
            while ((line = br.readLine()) != null) {
                all++;
                if (all <= 20) firstLines.append(line).append('\n');
                String low = line.toLowerCase(Locale.ROOT);
                boolean keep = false;
                for (String n : needles) {
                    if (low.contains(n)) { keep = true; break; }
                }
                if (keep && kept < 400) {
                    out.append(line).append('\n');
                    kept++;
                }
            }
            int code = p.waitFor();
            if (kept == 0) {
                out.append("[no matching lines; exit=").append(code).append("]\n");
                out.append(firstLines);
            }
        } catch (Exception e) {
            out.append("ERROR: ").append(e).append('\n');
        }
        return out.toString();
    }

    private void registerReceivers() {
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_UUID);
        f.addAction(ACTION_CODEC_CONFIG_CHANGED);
        registerReceiver(systemReceiver, f, Context.RECEIVER_EXPORTED);
    }

    private final BroadcastReceiver systemReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (BluetoothDevice.ACTION_UUID.equals(intent.getAction())) {
                BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                ParcelUuid[] uuids = intent.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID, ParcelUuid.class);
                log("\n=== SDP RESULT " + (d != null ? safeName(d) : "") + " ===");
                if (uuids == null) log("No SDP UUIDs");
                else for (ParcelUuid u : uuids) log("SDP: " + u.getUuid());
            } else if (ACTION_CODEC_CONFIG_CHANGED.equals(intent.getAction())) {
                BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                BluetoothCodecStatus status = intent.getParcelableExtra(
                        BluetoothCodecStatus.EXTRA_CODEC_STATUS, BluetoothCodecStatus.class);
                log("\n=== CODEC_CONFIG_CHANGED " + (d != null ? safeName(d) : "") + " ===");
                if (status != null) printCodecStatus(status, "broadcast");
                else log("CodecStatus extra is null");
            }
        }
    };

    private void printCodecStatus(BluetoothCodecStatus s, String source) {
        log("CodecStatus source=" + source);
        BluetoothCodecConfig current = s.getCodecConfig();
        log("CURRENT: " + (current != null ? current.toString() : "null"));
        log("SELECTABLE:");
        for (BluetoothCodecConfig c : s.getCodecsSelectableCapabilities()) {
            log("  " + c);
        }
        log("LOCAL CAPABILITIES:");
        for (BluetoothCodecConfig c : s.getCodecsLocalCapabilities()) {
            log("  " + c);
        }
        log("Если AAC отсутствует в SELECTABLE, заставить эту пару работать по AAC со стороны телефона нельзя.");
    }

    private boolean ensureBt() {
        if (adapter == null) {
            log("На устройстве нет Bluetooth adapter.");
            return false;
        }
        if (!btGranted()) {
            requestBtPermissionsIfNeeded();
            return false;
        }
        return true;
    }

    private String safeName(BluetoothDevice d) {
        if (d == null) return "N/A";
        try {
            String n = d.getName();
            return n != null ? n : "N/A";
        } catch (SecurityException e) {
            return "N/A";
        }
    }

    private String bondName(int b) {
        if (b == BluetoothDevice.BOND_BONDED) return "BONDED";
        if (b == BluetoothDevice.BOND_BONDING) return "BONDING";
        return "NONE";
    }

    private String deviceTypeName(int t) {
        switch (t) {
            case BluetoothDevice.DEVICE_TYPE_CLASSIC: return "CLASSIC";
            case BluetoothDevice.DEVICE_TYPE_LE: return "LE";
            case BluetoothDevice.DEVICE_TYPE_DUAL: return "DUAL";
            default: return "UNKNOWN";
        }
    }

    private String properties(int p) {
        List<String> a = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) a.add("READ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) a.add("WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) a.add("WRITE_NR");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) a.add("NOTIFY");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) a.add("INDICATE");
        return a.toString();
    }

    private String friendlyUuid(UUID u) {
        String s = u.toString().toLowerCase(Locale.ROOT);
        if (s.equals("00001800-0000-1000-8000-00805f9b34fb")) return "Generic Access";
        if (s.equals("00001801-0000-1000-8000-00805f9b34fb")) return "Generic Attribute";
        if (s.equals("0000180a-0000-1000-8000-00805f9b34fb")) return "Device Information";
        if (s.equals("00002a29-0000-1000-8000-00805f9b34fb")) return "Manufacturer Name";
        if (s.equals("00002a24-0000-1000-8000-00805f9b34fb")) return "Model Number";
        if (s.equals("00002a25-0000-1000-8000-00805f9b34fb")) return "Serial Number";
        if (s.equals("00002a26-0000-1000-8000-00805f9b34fb")) return "Firmware Revision";
        if (s.equals("00002a27-0000-1000-8000-00805f9b34fb")) return "Hardware Revision";
        if (s.equals("d0611e78-bbb4-4591-a5f8-487910ae4366")) return "Apple Continuity Service";
        if (s.equals("9fa480e0-4967-4542-9390-d343dc5d04ae")) return "Apple Nearby Service";
        return "custom";
    }

    private String printableOrHex(byte[] b) {
        if (b == null) return "null";
        boolean printable = b.length > 0;
        for (byte x : b) {
            int v = x & 0xFF;
            if (v == 0) continue;
            if (v < 0x20 || v > 0x7E) { printable = false; break; }
        }
        if (printable) {
            String s = new String(b, StandardCharsets.UTF_8).replace("\u0000", "").trim();
            if (!s.isEmpty()) return '"' + s + '"' + "  [hex " + hex(b) + "]";
        }
        return hex(b);
    }

    private String hex(byte[] b) {
        if (b == null) return "null";
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) sb.append(String.format(Locale.US, "%02X", x & 0xFF));
        return sb.toString();
    }

    private void log(String s) {
        main.post(() -> {
            String stamp = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
            output.append("[" + stamp + "] " + s + "\n");
        });
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(systemReceiver); } catch (Exception ignored) { }
        if (adapter != null && a2dp != null) {
            try { adapter.closeProfileProxy(BluetoothProfile.A2DP, a2dp); } catch (Exception ignored) { }
        }
        if (activeGatt != null) {
            try { activeGatt.close(); } catch (Exception ignored) { }
        }
        worker.shutdownNow();
    }
}
