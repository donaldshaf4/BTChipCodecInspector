package com.example.btchipcodec;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Handler;
import android.os.ParcelUuid;

import com.jieli.bluetooth.bean.BluetoothOption;
import com.jieli.bluetooth.bean.base.BaseError;
import com.jieli.bluetooth.bean.response.ADVInfoResponse;
import com.jieli.bluetooth.constant.AttrAndFunCode;
import com.jieli.bluetooth.constant.BluetoothConstant;
import com.jieli.bluetooth.constant.StateCode;
import com.jieli.bluetooth.impl.rcsp.RCSPController;
import com.jieli.bluetooth.interfaces.rcsp.callback.BTRcspEventCallback;
import com.jieli.bluetooth.interfaces.rcsp.callback.OnRcspActionCallback;
import com.jieli.bluetooth.tool.DeviceAddrManager;
import com.jieli.bluetooth.utils.CommonUtil;

import java.util.Locale;

/**
 * Minimal, targeted JieLi RCSP helper for the in-ear detection setting.
 *
 * Uses only APIs documented by JieLi:
 *  - SPP connection through RCSPController
 *  - getDeviceSettingsInfo(mask)
 *  - modifyDeviceSettingsInfo(type, payload)
 *
 * ADV_TYPE_IN_EAR_CHECK = 8
 * payload/state: 1 = OFF, 2 = ON
 *
 * This helper deliberately refuses to write unless the selected Bluetooth
 * device exposes the JL_SPP fingerprint UUID seen on the user's earbuds.
 */
public final class JieliEarDetectionHelper {

    public interface Logger {
        void log(String text);
    }

    private static final String JL_SPP_UUID =
            "fe010000-1234-5678-abcd-00805f9b34fb";
    private static final int IN_EAR_MASK =
            1 << AttrAndFunCode.ADV_TYPE_IN_EAR_CHECK;

    private final Context appContext;
    private final Handler main;
    private final Logger logger;

    private RCSPController controller;
    private BTRcspEventCallback pendingConnectionCallback;
    private Runnable pendingTimeout;

    public JieliEarDetectionHelper(Context context, Handler main, Logger logger) {
        this.appContext = context.getApplicationContext();
        this.main = main;
        this.logger = logger;
    }

    public void read(BluetoothDevice device) {
        withConnectedTarget(device, () -> readConnected(device));
    }

    public void disable(BluetoothDevice device) {
        setEnabled(device, false);
    }

    public void enable(BluetoothDevice device) {
        setEnabled(device, true);
    }

    private void setEnabled(BluetoothDevice device, boolean enabled) {
        withConnectedTarget(device, () -> {
            int state = enabled ? 2 : 1;
            log("\n=== JIELI IN-EAR WRITE ===");
            log("Target: " + safeDevice(device));
            log("ADV_TYPE_IN_EAR_CHECK=" + AttrAndFunCode.ADV_TYPE_IN_EAR_CHECK +
                    ", payload state=" + state + (enabled ? " (ON)" : " (OFF)"));

            controller.modifyDeviceSettingsInfo(
                    device,
                    AttrAndFunCode.ADV_TYPE_IN_EAR_CHECK,
                    new byte[]{(byte) state},
                    new OnRcspActionCallback<Integer>() {
                        @Override
                        public void onSuccess(BluetoothDevice d, Integer message) {
                            if (message != null && message == 0) {
                                log("Jieli in-ear: запись принята устройством.");
                                main.postDelayed(() -> readConnected(device), 350);
                            } else {
                                log("Jieli in-ear: устройство вернуло код результата " + message +
                                        "; настройка не подтверждена.");
                            }
                        }

                        @Override
                        public void onError(BluetoothDevice d, BaseError error) {
                            log("Jieli in-ear WRITE error: " + formatError(error));
                        }
                    });
        });
    }

    private void readConnected(BluetoothDevice device) {
        log("\n=== JIELI IN-EAR READ ===");
        log("Target: " + safeDevice(device));
        controller.getDeviceSettingsInfo(
                device,
                IN_EAR_MASK,
                new OnRcspActionCallback<ADVInfoResponse>() {
                    @Override
                    public void onSuccess(BluetoothDevice d, ADVInfoResponse info) {
                        if (info == null) {
                            log("Jieli in-ear: пустой ответ.");
                            return;
                        }
                        int state = info.getInEarSettings();
                        String meaning;
                        if (state == 1) meaning = "OFF / выключено";
                        else if (state == 2) meaning = "ON / включено";
                        else if (state == 0) meaning = "NOT ENABLED / функция не объявлена";
                        else meaning = "неизвестное значение";
                        log("Jieli in-ear: state=" + state + " -> " + meaning);
                    }

                    @Override
                    public void onError(BluetoothDevice d, BaseError error) {
                        log("Jieli in-ear READ error: " + formatError(error));
                    }
                });
    }

    private void withConnectedTarget(BluetoothDevice device, Runnable action) {
        if (device == null) {
            log("Jieli: сначала выбери подключённые A2DP-наушники.");
            return;
        }

        if (!hasJlSppFingerprint(device)) {
            log("Jieli: JL_SPP UUID пока не найден в SDP-кэше выбранного устройства.");
            log("Запрашиваю SDP ещё раз; повторю Jieli-проверку через ~2 секунды.");
            try {
                boolean started = device.fetchUuidsWithSdp();
                log("Jieli: fetchUuidsWithSdp()=" + started);
            } catch (Throwable e) {
                log("Jieli: SDP refresh error: " + e.getClass().getSimpleName() +
                        ": " + e.getMessage());
            }
            main.postDelayed(() -> {
                if (!hasJlSppFingerprint(device)) {
                    log("Jieli: JL_SPP fingerprint всё ещё отсутствует. Запись НЕ выполнялась.");
                    log("Эта кнопка специально не пишет настройки в устройство без JL_SPP.");
                    return;
                }
                ensureSdkAndConnect(device, action);
            }, 1800);
            return;
        }

        ensureSdkAndConnect(device, action);
    }

    private void ensureSdkAndConnect(BluetoothDevice device, Runnable action) {
        try {
            initSdkIfNeeded();
            controller = RCSPController.getInstance();
        } catch (Throwable e) {
            log("Jieli SDK init error: " + e.getClass().getSimpleName() +
                    ": " + e.getMessage());
            return;
        }

        try {
            BluetoothDevice using = controller.getUsingDevice();
            if (controller.isDeviceConnected() && sameDevice(using, device)) {
                log("Jieli RCSP/SPP: уже подключено к " + safeDevice(device));
                action.run();
                return;
            }
        } catch (Throwable ignored) {
        }

        clearPendingConnectionCallback();

        log("\n=== JIELI RCSP/SPP CONNECT ===");
        log("Target: " + safeDevice(device));
        log("Подключаю прямой SPP/RCSP-канал, обходя фильтр устройств PiHome...");

        pendingConnectionCallback = new BTRcspEventCallback() {
            @Override
            public void onConnection(BluetoothDevice d, int status) {
                if (!sameDevice(d, device)) return;
                log("Jieli RCSP connection status=" + status);

                if (status == StateCode.CONNECTION_OK) {
                    clearPendingConnectionCallback();
                    action.run();
                } else if (status == StateCode.CONNECTION_FAILED ||
                        status == StateCode.CONNECTION_DISCONNECT) {
                    clearPendingConnectionCallback();
                    log("Jieli RCSP/SPP: подключение не удалось. " +
                            "Возможна нестандартная/урезанная прошивка реплики.");
                }
            }
        };

        controller.addBTRcspEventCallback(pendingConnectionCallback);

        pendingTimeout = () -> {
            if (pendingConnectionCallback != null) {
                log("Jieli RCSP/SPP: таймаут подключения (10 секунд).");
                clearPendingConnectionCallback();
            }
        };
        main.postDelayed(pendingTimeout, 10_000);

        try {
            controller.connectDevice(device, BluetoothConstant.PROTOCOL_TYPE_SPP);
        } catch (Throwable e) {
            clearPendingConnectionCallback();
            log("Jieli connectDevice(SPP) error: " + e.getClass().getSimpleName() +
                    ": " + e.getMessage());
        }
    }

    private void initSdkIfNeeded() {
        if (RCSPController.isInit()) return;

        try {
            CommonUtil.setMainContext(appContext);
        } catch (Throwable ignored) {
        }

        try {
            if (!DeviceAddrManager.isInit()) {
                DeviceAddrManager.init(appContext);
            }
        } catch (Throwable ignored) {
        }

        BluetoothOption option = BluetoothOption.createDefaultOption()
                .setPriority(BluetoothOption.PREFER_SPP)
                .setReconnect(false)
                .setUseMultiDevice(true)
                .setMandatoryUseBLE(false)
                .setUseDeviceAuth(false)
                .setTimeoutMs(3000);

        RCSPController.init(appContext, option);
        log("Jieli SDK: инициализировано, transport=SPP, auth=OFF, reconnect=OFF.");
    }

    private boolean hasJlSppFingerprint(BluetoothDevice device) {
        try {
            ParcelUuid[] uuids = device.getUuids();
            if (uuids == null) return false;
            for (ParcelUuid uuid : uuids) {
                if (uuid == null || uuid.getUuid() == null) continue;
                if (JL_SPP_UUID.equals(uuid.getUuid().toString().toLowerCase(Locale.ROOT))) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static boolean sameDevice(BluetoothDevice a, BluetoothDevice b) {
        if (a == null || b == null) return false;
        try {
            return a.getAddress().equalsIgnoreCase(b.getAddress());
        } catch (Throwable e) {
            return a.equals(b);
        }
    }

    private String safeDevice(BluetoothDevice d) {
        if (d == null) return "null";
        String name = "N/A";
        try {
            if (d.getName() != null) name = d.getName();
        } catch (Throwable ignored) {
        }
        String addr = "?";
        try {
            addr = d.getAddress();
        } catch (Throwable ignored) {
        }
        return name + " " + addr;
    }

    private String formatError(BaseError error) {
        if (error == null) return "null";
        try {
            return "code=" + error.getSubCode() + ", " + error.getMessage();
        } catch (Throwable e) {
            return String.valueOf(error);
        }
    }

    private void clearPendingConnectionCallback() {
        if (pendingTimeout != null) {
            main.removeCallbacks(pendingTimeout);
            pendingTimeout = null;
        }
        if (pendingConnectionCallback != null && controller != null) {
            try {
                controller.removeBTRcspEventCallback(pendingConnectionCallback);
            } catch (Throwable ignored) {
            }
        }
        pendingConnectionCallback = null;
    }

    public void destroy() {
        clearPendingConnectionCallback();
    }

    private void log(String text) {
        main.post(() -> logger.log(text));
    }
}
