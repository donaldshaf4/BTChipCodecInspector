package com.example.btchipcodec;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Handler;
import android.os.ParcelUuid;

import com.jieli.bluetooth.bean.BluetoothOption;
import com.jieli.bluetooth.bean.base.BaseError;
import com.jieli.bluetooth.bean.response.ADVInfoResponse;
import com.jieli.bluetooth.constant.AttrAndFunCode;
import com.jieli.bluetooth.constant.BluetoothConstant;
import com.jieli.bluetooth.constant.StateCode;
import com.jieli.bluetooth.impl.rcsp.RCSPController;
import com.jieli.bluetooth.interfaces.rcsp.callback.BTRcspEventCallback;
import com.jieli.bluetooth.interfaces.rcsp.callback.OnRcspActionCallback;
import com.jieli.bluetooth.utils.CommonUtil;

import java.util.Locale;
import java.util.UUID;

/**
 * Minimal, targeted JieLi RCSP helper for the in-ear detection setting.
 *
 * Uses only APIs documented by JieLi:
 *  - SPP connection through RCSPController
 *  - getDeviceSettingsInfo(mask)
 *  - modifyDeviceSettingsInfo(type, payload)
 *
 * ADV_TYPE_IN_EAR_CHECK = 8
 * payload/state: 1 = OFF, 2 = ON
 *
 * This helper deliberately refuses to write unless the selected Bluetooth
 * device exposes the JL_SPP fingerprint UUID seen on the user's earbuds.
 */
public final class JieliEarDetectionHelper {

    public interface Logger {
        void log(String text);
    }

    public interface StatusListener {
        void onStatus(int state, String detail);
    }

    public static final int UI_UNKNOWN = -1;
    public static final int UI_UNSUPPORTED = 0;
    public static final int UI_OFF = 1;
    public static final int UI_ON = 2;
    public static final int UI_BUSY = 3;
    public static final int UI_ERROR = 4;

    private static final String JL_SPP_UUID =
            "fe010000-1234-5678-abcd-00805f9b34fb";
    private static final int IN_EAR_MASK =
            1 << AttrAndFunCode.ADV_TYPE_IN_EAR_CHECK;

    private final Context appContext;
    private final Handler main;
    private final Logger logger;
    private final StatusListener statusListener;

    private RCSPController controller;
    private BTRcspEventCallback pendingConnectionCallback;
    private Runnable pendingTimeout;

    public JieliEarDetectionHelper(Context context, Handler main, Logger logger,
                                   StatusListener statusListener) {
        this.appContext = context.getApplicationContext();
        this.main = main;
        this.logger = logger;
        this.statusListener = statusListener;
    }

    public void read(BluetoothDevice device) {
        status(UI_BUSY, "Проверяю состояние обнаружения уха...");
        withConnectedTarget(device, () -> readConnected(device));
    }

    public void disable(BluetoothDevice device) {
        setEnabled(device, false);
    }

    public void enable(BluetoothDevice device) {
        setEnabled(device, true);
    }

    private void setEnabled(BluetoothDevice device, boolean enabled) {
        status(UI_BUSY, enabled
                ? "Включаю обнаружение уха..."
                : "Выключаю обнаружение уха...");
        withConnectedTarget(device, () -> {
            int state = enabled ? 2 : 1;
            log("\n=== JIELI IN-EAR WRITE ===");
            log("Target: " + safeDevice(device));
            log("ADV_TYPE_IN_EAR_CHECK=" + AttrAndFunCode.ADV_TYPE_IN_EAR_CHECK +
                    ", payload state=" + state + (enabled ? " (ON)" : " (OFF)"));

            controller.modifyDeviceSettingsInfo(
                    device,
                    AttrAndFunCode.ADV_TYPE_IN_EAR_CHECK,
                    new byte[]{(byte) state},
                    new OnRcspActionCallback<Integer>() {
                        @Override
                        public void onSuccess(BluetoothDevice d, Integer message) {
                            if (message != null && message == 0) {
                                log("Jieli in-ear: запись принята устройством.");
                                status(UI_BUSY, "Команда принята. Проверяю фактическое состояние...");
                                main.postDelayed(() -> readConnected(device), 350);
                            } else {
                                log("Jieli in-ear: устройство вернуло код результата " + message +
                                        "; настройка не подтверждена.");
                                status(UI_ERROR, "Настройка не подтверждена устройством. Код: " + message);
                            }
                        }

                        @Override
                        public void onError(BluetoothDevice d, BaseError error) {
                            String err = formatError(error);
                            log("Jieli in-ear WRITE error: " + err);
                            status(UI_ERROR, "Ошибка записи настройки: " + err);
                        }
                    });
        });
    }

    private void readConnected(BluetoothDevice device) {
        log("\n=== JIELI IN-EAR READ ===");
        log("Target: " + safeDevice(device));
        controller.getDeviceSettingsInfo(
                device,
                IN_EAR_MASK,
                new OnRcspActionCallback<ADVInfoResponse>() {
                    @Override
                    public void onSuccess(BluetoothDevice d, ADVInfoResponse info) {
                        if (info == null) {
                            log("Jieli in-ear: пустой ответ.");
                            status(UI_ERROR, "Устройство ответило, но состояние не пришло.");
                            return;
                        }
                        int state = info.getInEarSettings();
                        String meaning;
                        if (state == 1) {
                            meaning = "OFF / выключено";
                            log("Jieli in-ear: ОБНАРУЖЕНИЕ УХА ВЫКЛЮЧЕНО (state=1)");
                            status(UI_OFF, "Обнаружение уха ВЫКЛЮЧЕНО.");
                        } else if (state == 2) {
                            meaning = "ON / включено";
                            log("Jieli in-ear: ОБНАРУЖЕНИЕ УХА ВКЛЮЧЕНО (state=2)");
                            status(UI_ON, "Обнаружение уха ВКЛЮЧЕНО.");
                        } else if (state == 0) {
                            meaning = "NOT ENABLED / функция не объявлена";
                            log("Jieli in-ear: функция не объявлена устройством (state=0)");
                            status(UI_UNSUPPORTED, "Функция не объявлена устройством / не поддерживается этой прошивкой.");
                        } else {
                            meaning = "неизвестное значение";
                            log("Jieli in-ear: неизвестное состояние=" + state);
                            status(UI_ERROR, "Пришло неизвестное состояние: " + state);
                        }
                        log("Jieli in-ear raw: state=" + state + " -> " + meaning);
                    }

                    @Override
                    public void onError(BluetoothDevice d, BaseError error) {
                        String err = formatError(error);
                        log("Jieli in-ear READ error: " + err);
                        status(UI_ERROR, "Не удалось прочитать состояние: " + err);
                    }
                });
    }

    private void withConnectedTarget(BluetoothDevice device, Runnable action) {
        if (device == null) {
            log("Jieli: сначала выбери подключённые A2DP-наушники.");
            status(UI_ERROR, "Нет выбранных подключённых A2DP-наушников.");
            return;
        }

        if (!hasJlSppFingerprint(device)) {
            log("Jieli: JL_SPP UUID пока не найден в SDP-кэше выбранного устройства.");
            log("Запрашиваю SDP ещё раз; повторю Jieli-проверку через ~2 секунды.");
            try {
                boolean started = device.fetchUuidsWithSdp();
                log("Jieli: fetchUuidsWithSdp()=" + started);
            } catch (Throwable e) {
                log("Jieli: SDP refresh error: " + e.getClass().getSimpleName() +
                        ": " + e.getMessage());
            }
            main.postDelayed(() -> {
                if (!hasJlSppFingerprint(device)) {
                    log("Jieli: JL_SPP fingerprint всё ещё отсутствует. Запись НЕ выполнялась.");
                    log("Эта кнопка специально не пишет настройки в устройство без JL_SPP.");
                    status(UI_UNSUPPORTED, "JL_SPP не найден. Jieli-управление для этой пары не подтверждено.");
                    return;
                }
                ensureSdkAndConnect(device, action);
            }, 1800);
            return;
        }

        ensureSdkAndConnect(device, action);
    }

    private void ensureSdkAndConnect(BluetoothDevice device, Runnable action) {
        try {
            initSdkIfNeeded();
            controller = RCSPController.getInstance();
        } catch (Throwable e) {
            String err = e.getClass().getSimpleName() + ": " + e.getMessage();
            log("Jieli SDK init error: " + err);
            status(UI_ERROR, "Jieli SDK не запустился: " + err);
            return;
        }

        try {
            BluetoothDevice using = controller.getUsingDevice();
            if (controller.isDeviceConnected() && sameDevice(using, device)) {
                log("Jieli RCSP: уже подключено к " + safeDevice(device));
                action.run();
                return;
            }
        } catch (Throwable ignored) {
        }

        // PiHome may filter this replica out during scanning, but JieLi's own
        // documentation notes that an SPP-oriented connection can first be
        // established through BLE and then move to SPP.  Therefore try the
        // native RCSP BLE channel first (AE00/AE01/AE02), then fall back to
        // the custom JL_SPP UUID from this headset's SDP record.
        startConnectAttempt(device, action, BluetoothConstant.PROTOCOL_TYPE_BLE, false);
    }

    private void startConnectAttempt(BluetoothDevice device, Runnable action,
                                     int protocol, boolean sppFallbackAlreadyUsed) {
        clearPendingConnectionCallback();

        final boolean isBle = protocol == BluetoothConstant.PROTOCOL_TYPE_BLE;
        final String transport = isBle ? "BLE/RCSP (AE00)" : "SPP/RCSP (JL_SPP)";

        log("\n=== JIELI " + transport + " CONNECT ===");
        log("Target: " + safeDevice(device));
        if (isBle) {
            log("Сначала пробую прямой BLE RCSP. PiHome может не показывать реплику из-за своего scan filter.");
            status(UI_BUSY, "Пробую Jieli через BLE/RCSP...");
        } else {
            log("BLE не дал RCSP-соединение. Пробую SPP по JL_SPP UUID: " + JL_SPP_UUID);
            status(UI_BUSY, "BLE не подключился. Пробую Jieli через JL_SPP...");
        }

        pendingConnectionCallback = new BTRcspEventCallback() {
            @Override
            public void onConnection(BluetoothDevice d, int connectionStatus) {
                if (!sameDevice(d, device)) return;

                String statusName;
                if (connectionStatus == StateCode.CONNECTION_DISCONNECT) statusName = "DISCONNECT";
                else if (connectionStatus == StateCode.CONNECTION_OK) statusName = "OK";
                else if (connectionStatus == StateCode.CONNECTION_FAILED) statusName = "FAILED";
                else if (connectionStatus == StateCode.CONNECTION_CONNECTING) statusName = "CONNECTING";
                else if (connectionStatus == StateCode.CONNECTION_CONNECTED) statusName = "CONNECTED(deprecated)";
                else statusName = "UNKNOWN";

                log("Jieli " + transport + " status=" + connectionStatus + " (" + statusName + ")");

                if (connectionStatus == StateCode.CONNECTION_OK) {
                    clearPendingConnectionCallback();
                    log("Jieli " + transport + ": CONNECTED OK.");
                    status(UI_BUSY, "Jieli подключён через " + transport + ". Читаю настройку...");
                    action.run();
                    return;
                }

                if (connectionStatus == StateCode.CONNECTION_FAILED ||
                        connectionStatus == StateCode.CONNECTION_DISCONNECT) {
                    clearPendingConnectionCallback();
                    if (isBle && !sppFallbackAlreadyUsed) {
                        log("Jieli BLE/RCSP не подключился — автоматически перехожу к JL_SPP.");
                        main.postDelayed(() ->
                                startConnectAttempt(device, action,
                                        BluetoothConstant.PROTOCOL_TYPE_SPP, true), 300);
                    } else {
                        log("Jieli RCSP: оба транспорта не дали рабочее соединение.");
                        status(UI_ERROR,
                                "Jieli RCSP не подключился ни через BLE, ни через JL_SPP.");
                    }
                }
            }
        };

        controller.addBTRcspEventCallback(pendingConnectionCallback);

        pendingTimeout = () -> {
            if (pendingConnectionCallback == null) return;
            log("Jieli " + transport + ": таймаут подключения (10 секунд).");
            clearPendingConnectionCallback();

            if (isBle && !sppFallbackAlreadyUsed) {
                log("Автоматически пробую второй путь: JL_SPP.");
                startConnectAttempt(device, action,
                        BluetoothConstant.PROTOCOL_TYPE_SPP, true);
            } else {
                status(UI_ERROR,
                        "Не удалось открыть RCSP: BLE и JL_SPP не ответили.");
            }
        };
        main.postDelayed(pendingTimeout, 10_000);

        try {
            controller.connectDevice(device, protocol);
        } catch (Throwable e) {
            clearPendingConnectionCallback();
            String err = e.getClass().getSimpleName() + ": " + e.getMessage();
            log("Jieli " + transport + " connect error: " + err);

            if (isBle && !sppFallbackAlreadyUsed) {
                log("После ошибки BLE автоматически пробую JL_SPP.");
                main.postDelayed(() ->
                        startConnectAttempt(device, action,
                                BluetoothConstant.PROTOCOL_TYPE_SPP, true), 300);
            } else {
                status(UI_ERROR, "Ошибка подключения Jieli: " + err);
            }
        }
    }

    private void initSdkIfNeeded() {
        if (RCSPController.isInit()) return;

        try {
            CommonUtil.setMainContext(appContext);
        } catch (Throwable ignored) {
        }

        BluetoothOption option = BluetoothOption.createDefaultOption()
                .setPriority(BluetoothOption.PREFER_BLE)
                .setSppUUID(UUID.fromString(JL_SPP_UUID))
                .setReconnect(false)
                .setUseMultiDevice(true)
                .setMandatoryUseBLE(false)
                .setUseDeviceAuth(false)
                .setTimeoutMs(3000);

        RCSPController.init(appContext, option);
        log("Jieli SDK: инициализировано, priority=BLE, auth=OFF, reconnect=OFF.");
        log("Jieli transport plan: BLE RCSP first; fallback SPP UUID=" + JL_SPP_UUID);
    }

    private boolean hasJlSppFingerprint(BluetoothDevice device) {
        try {
            ParcelUuid[] uuids = device.getUuids();
            if (uuids == null) return false;
            for (ParcelUuid uuid : uuids) {
                if (uuid == null || uuid.getUuid() == null) continue;
                if (JL_SPP_UUID.equals(uuid.getUuid().toString().toLowerCase(Locale.ROOT))) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static boolean sameDevice(BluetoothDevice a, BluetoothDevice b) {
        if (a == null || b == null) return false;
        try {
            return a.getAddress().equalsIgnoreCase(b.getAddress());
        } catch (Throwable e) {
            return a.equals(b);
        }
    }

    private String safeDevice(BluetoothDevice d) {
        if (d == null) return "null";
        String name = "N/A";
        try {
            if (d.getName() != null) name = d.getName();
        } catch (Throwable ignored) {
        }
        String addr = "?";
        try {
            addr = d.getAddress();
        } catch (Throwable ignored) {
        }
        return name + " " + addr;
    }

    private String formatError(BaseError error) {
        if (error == null) return "null";
        try {
            return "code=" + error.getSubCode() + ", " + error.getMessage();
        } catch (Throwable e) {
            return String.valueOf(error);
        }
    }

    private void clearPendingConnectionCallback() {
        if (pendingTimeout != null) {
            main.removeCallbacks(pendingTimeout);
            pendingTimeout = null;
        }
        if (pendingConnectionCallback != null && controller != null) {
            try {
                controller.removeBTRcspEventCallback(pendingConnectionCallback);
            } catch (Throwable ignored) {
            }
        }
        pendingConnectionCallback = null;
    }

    public void destroy() {
        clearPendingConnectionCallback();
    }

    private void status(int state, String detail) {
        if (statusListener == null) return;
        main.post(() -> statusListener.onStatus(state, detail));
    }

    private void log(String text) {
        main.post(() -> logger.log(text));
    }
}
